import { KonfiContact } from '@/types';

export const initialContacts: KonfiContact[] = [
  {
    id: '1',
    username: 'tim.heiligentag',
    firstName: 'Tim',
    lastName: 'Heiligentag',
    birthDate: '2008-03-15',
    address: {
      street: 'Kirchgasse 12',
      postalCode: '12345',
      city: 'Musterstadt'
    },
    phone: '0123 456789',
    email: 'tim.heiligentag@email.com',
    parentName: 'Maria Heiligentag',
    parentPhone: '0123 987654',
    notes: 'Sehr engagiert im Gottesdienst',
    konfiRole: 'KU8'
  }
];