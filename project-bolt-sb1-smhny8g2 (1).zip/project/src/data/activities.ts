import { ActivityRequirement } from '@/types';

export const activityRequirements: ActivityRequirement[] = [
  {
    type: 'konfirmationsunterricht',
    title: 'Konfirmationsunterricht',
    required: 20,
    description: 'Regelmäßige Teilnahme am Konfirmationsunterricht'
  },
  {
    type: 'gottesdienst',
    title: 'Gottesdienstbesuche',
    required: 15,
    description: 'Teilnahme an Gottesdiensten und kirchlichen Feiern'
  },
  {
    type: 'kirchliche_aktivitaet',
    title: 'Kirchliche Aktivitäten',
    required: 5,
    description: 'Teilnahme an besonderen kirchlichen Veranstaltungen und Projekten'
  }
];