import { User } from '@/types';

export const users: User[] = [
  { 
    id: "1", 
    username: "Marvin.Heiligentag", 
    password: "Mubuva09", 
    role: "admin",
    firstName: "Marvin",
    lastName: "Heiligentag",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 95,
    attendanceScore: 100,
    participationScore: 90,
    totalScore: 95,
    rank: 1,
    lastActive: new Date().toISOString(),
    // Teamer-Funktionen für Admin
    isAvailableForEmergency: true,
    specializations: ["Systemadministration", "Krisenintervention", "Jugendarbeit", "Seelsorge", "Konfliktlösung"],
    emergencyContactInfo: {
      phone: "+49 123 456789",
      email: "marvin.heiligentag@gemeinde.de",
      availableHours: "24/7 für Notfälle und Systemverwaltung"
    }
  },
  { 
    id: "2", 
    username: "tim.heiligentag", 
    password: "Mubuva09", 
    role: "konfi",
    konfiRole: "KU8",
    firstName: "Tim",
    lastName: "Heiligentag",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 88,
    attendanceScore: 95,
    participationScore: 85,
    totalScore: 89,
    rank: 2,
    lastActive: new Date().toISOString()
  },
  { 
    id: "3", 
    username: "Nena", 
    password: "1234", 
    role: "teamer",
    firstName: "Nena",
    lastName: "Schmidt",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 92,
    attendanceScore: 88,
    participationScore: 95,
    totalScore: 92,
    rank: 3,
    lastActive: new Date().toISOString(),
    isAvailableForEmergency: true,
    specializations: ["Jugendarbeit", "Konfliktlösung", "Peer-Beratung"],
    emergencyContactInfo: {
      phone: "+49 123 456789",
      email: "nena.schmidt@gemeinde.de",
      availableHours: "Mo-Fr 14:00-18:00, Sa 10:00-16:00"
    }
  },
  {
    id: "4",
    username: "anna.mueller",
    password: "password123",
    role: "konfi",
    konfiRole: "KU8",
    firstName: "Anna",
    lastName: "Müller",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 85,
    attendanceScore: 90,
    participationScore: 80,
    totalScore: 85,
    rank: 4,
    lastActive: new Date().toISOString()
  },
  {
    id: "5",
    username: "max.schmidt",
    password: "password123",
    role: "konfi",
    konfiRole: "KUZ",
    firstName: "Max",
    lastName: "Schmidt",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 78,
    attendanceScore: 85,
    participationScore: 75,
    totalScore: 79,
    rank: 5,
    lastActive: new Date().toISOString()
  },
  {
    id: "6",
    username: "lisa.weber",
    password: "password123",
    role: "konfi",
    konfiRole: "KU4",
    firstName: "Lisa",
    lastName: "Weber",
    // Entfernt: profileImage - wird automatisch grau generiert
    quizScore: 82,
    attendanceScore: 80,
    participationScore: 88,
    totalScore: 83,
    rank: 6,
    lastActive: new Date().toISOString()
  },
  // Neue Pastor-Benutzer
  {
    id: "7",
    username: "pastor.mueller",
    password: "pastor123",
    role: "pastor",
    firstName: "Dr. Thomas",
    lastName: "Müller",
    // Entfernt: profileImage - wird automatisch grau generiert
    lastActive: new Date().toISOString(),
    isAvailableForEmergency: true,
    specializations: ["Seelsorge", "Krisenintervention", "Familienberatung", "Trauerbegleitung"],
    emergencyContactInfo: {
      phone: "+49 123 987654",
      email: "pastor.mueller@gemeinde.de",
      availableHours: "24/7 für Notfälle, regulär Mo-Fr 9:00-17:00"
    }
  },
  {
    id: "8",
    username: "pastor.weber",
    password: "pastor456",
    role: "pastor",
    firstName: "Sarah",
    lastName: "Weber",
    // Entfernt: profileImage - wird automatisch grau generiert
    lastActive: new Date().toISOString(),
    isAvailableForEmergency: true,
    specializations: ["Jugendseelsorge", "Suchtberatung", "Gewaltprävention", "Spirituelle Begleitung"],
    emergencyContactInfo: {
      phone: "+49 123 555666",
      email: "pastor.weber@gemeinde.de",
      availableHours: "Mo-Do 10:00-18:00, Fr 10:00-15:00, Notfälle jederzeit"
    }
  },
  // Zusätzlicher Teamer
  {
    id: "9",
    username: "teamer.jonas",
    password: "teamer789",
    role: "teamer",
    firstName: "Jonas",
    lastName: "Fischer",
    // Entfernt: profileImage - wird automatisch grau generiert
    lastActive: new Date().toISOString(),
    isAvailableForEmergency: true,
    specializations: ["Mobbing-Prävention", "Peer-Mediation", "Gruppenleitung"],
    emergencyContactInfo: {
      phone: "+49 123 777888",
      email: "jonas.fischer@gemeinde.de",
      availableHours: "Di-Do 15:00-19:00, Sa 9:00-13:00"
    }
  },
  // Neue Eltern-Benutzer
  {
    id: "10",
    username: "eltern.heiligentag",
    password: "eltern123",
    role: "parent",
    firstName: "Maria",
    lastName: "Heiligentag",
    lastActive: new Date().toISOString(),
    childrenIds: ["2"] // Tim Heiligentag
  },
  {
    id: "11",
    username: "eltern.mueller",
    password: "eltern456",
    role: "parent",
    firstName: "Stefan",
    lastName: "Müller",
    lastActive: new Date().toISOString(),
    childrenIds: ["4"] // Anna Müller
  },
  {
    id: "12",
    username: "eltern.schmidt",
    password: "eltern789",
    role: "parent",
    firstName: "Julia",
    lastName: "Schmidt",
    lastActive: new Date().toISOString(),
    childrenIds: ["5"] // Max Schmidt
  },
  {
    id: "13",
    username: "eltern.weber",
    password: "eltern101",
    role: "parent",
    firstName: "Michael",
    lastName: "Weber",
    lastActive: new Date().toISOString(),
    childrenIds: ["6"] // Lisa Weber
  },
  // Eltern mit mehreren Kindern
  {
    id: "14",
    username: "eltern.mehrfach",
    password: "eltern202",
    role: "parent",
    firstName: "Claudia",
    lastName: "Mehrfach",
    lastActive: new Date().toISOString(),
    childrenIds: ["5", "6"] // Max Schmidt und Lisa Weber (Beispiel für Patchwork-Familie)
  }
];