import { KonfiPass } from '@/types';

export const initialPasses: KonfiPass[] = [
  {
    id: '1',
    konfiUsername: 'tim.heiligentag',
    qrCode: 'KONFI_TIM_2025_001',
    signatures: [
      {
        id: '1',
        konfiUsername: 'tim.heiligentag',
        activityType: 'konfirmationsunterricht',
        activityTitle: 'Die Zehn Gebote',
        date: '2025-01-15',
        time: '16:00',
        adminSignature: 'Marvin.Heiligentag',
        comments: 'Sehr aufmerksam und engagiert',
        location: 'Gemeindehaus'
      },
      {
        id: '2',
        konfiUsername: 'tim.heiligentag',
        activityType: 'gottesdienst',
        activityTitle: 'Sonntagsgottesdienst',
        date: '2025-01-12',
        time: '10:00',
        adminSignature: 'Marvin.Heiligentag',
        location: 'Hauptkirche'
      }
    ],
    createdAt: '2025-01-01',
    isActive: true
  }
];