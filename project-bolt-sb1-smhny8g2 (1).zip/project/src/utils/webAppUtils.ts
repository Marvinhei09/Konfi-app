/**
 * Utility functions for web app specific features
 */
export const webAppUtils = {
  /**
   * Check if the app is running as a PWA (Progressive Web App)
   */
  isPwa: (): boolean => {
    return window.matchMedia('(display-mode: standalone)').matches || 
           (window.navigator as any).standalone === true;
  },

  /**
   * Check if the app can be installed as a PWA
   */
  canInstallPwa: (): boolean => {
    return 'BeforeInstallPromptEvent' in window;
  },

  /**
   * Check if the browser supports push notifications
   */
  supportsPushNotifications: (): boolean => {
    return 'PushManager' in window && 'Notification' in window;
  },

  /**
   * Request permission for push notifications
   */
  requestNotificationPermission: async (): Promise<NotificationPermission> => {
    if (!('Notification' in window)) {
      throw new Error('This browser does not support notifications');
    }
    
    return await Notification.requestPermission();
  },

  /**
   * Check if the app is online
   */
  isOnline: (): boolean => {
    return navigator.onLine;
  },

  /**
   * Add an online/offline event listener
   */
  addConnectivityListener: (callback: (isOnline: boolean) => void): (() => void) => {
    const handleOnline = () => callback(true);
    const handleOffline = () => callback(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Return a function to remove the listeners
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  },

  /**
   * Get browser and device information
   */
  getBrowserInfo: () => {
    const userAgent = navigator.userAgent;
    const browserInfo = {
      isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent),
      isIOS: /iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream,
      isAndroid: /Android/i.test(userAgent),
      isSafari: /^((?!chrome|android).)*safari/i.test(userAgent),
      isChrome: /Chrome/.test(userAgent) && /Google Inc/.test(navigator.vendor),
      isFirefox: /Firefox/.test(userAgent),
      isEdge: /Edg/.test(userAgent),
      userAgent: userAgent
    };
    
    return browserInfo;
  },

  /**
   * Share content using the Web Share API if available
   */
  shareContent: async (data: { title?: string; text?: string; url?: string }): Promise<boolean> => {
    if (!navigator.share) {
      return false;
    }
    
    try {
      await navigator.share(data);
      return true;
    } catch (error) {
      console.error('Error sharing content:', error);
      return false;
    }
  },

  /**
   * Save data to localStorage with error handling
   */
  saveToLocalStorage: (key: string, data: any): boolean => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Error saving to localStorage:', error);
      return false;
    }
  },

  /**
   * Load data from localStorage with error handling
   */
  loadFromLocalStorage: <T>(key: string, defaultValue: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error('Error loading from localStorage:', error);
      return defaultValue;
    }
  }
};