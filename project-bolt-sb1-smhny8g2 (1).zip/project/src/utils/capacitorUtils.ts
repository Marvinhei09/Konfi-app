import { Capacitor } from '@capacitor/core';

/**
 * Utility functions for Capacitor integration
 */
export const capacitorUtils = {
  /**
   * Check if the app is running on a native platform (Android/iOS)
   */
  isNativePlatform: (): boolean => {
    return Capacitor.isNativePlatform();
  },

  /**
   * Get the current platform (web, android, ios)
   */
  getPlatform: (): string => {
    return Capacitor.getPlatform();
  },

  /**
   * Check if the app is running on Android
   */
  isAndroid: (): boolean => {
    return Capacitor.getPlatform() === 'android';
  },

  /**
   * Check if the app is running on iOS
   */
  isIOS: (): boolean => {
    return Capacitor.getPlatform() === 'ios';
  },

  /**
   * Check if the app is running in a web browser
   */
  isWeb: (): boolean => {
    return Capacitor.getPlatform() === 'web';
  },

  /**
   * Get app info
   */
  getAppInfo: () => {
    return {
      name: 'Konfi Quiz App',
      version: '1.0.0',
      build: '1',
      platform: Capacitor.getPlatform(),
      isNative: Capacitor.isNativePlatform()
    };
  }
};