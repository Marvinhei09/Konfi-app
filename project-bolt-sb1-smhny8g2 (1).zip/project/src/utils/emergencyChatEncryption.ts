export class EmergencyChatEncryption {
  private encoder = new TextEncoder();
  private decoder = new TextDecoder();

  // Generiere einen sicheren Verschlüsselungsschlüssel
  generateKey(): string {
    const array = new Uint8Array(32); // 256-bit key
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  // Konvertiere Hex-String zu ArrayBuffer
  private hexToArrayBuffer(hex: string): ArrayBuffer {
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
      bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
    }
    return bytes.buffer;
  }

  // Konvertiere ArrayBuffer zu Hex-String
  private arrayBufferToHex(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  // Verschlüssele eine Nachricht
  async encryptMessage(message: string, keyHex: string): Promise<{ encryptedContent: string; iv: string }> {
    try {
      // Importiere den Schlüssel
      const keyBuffer = this.hexToArrayBuffer(keyHex);
      const cryptoKey = await crypto.subtle.importKey(
        'raw',
        keyBuffer,
        { name: 'AES-GCM' },
        false,
        ['encrypt']
      );

      // Generiere einen zufälligen Initialization Vector
      const iv = crypto.getRandomValues(new Uint8Array(12)); // 96-bit IV für AES-GCM
      
      // Verschlüssele die Nachricht
      const encodedMessage = this.encoder.encode(message);
      const encryptedBuffer = await crypto.subtle.encrypt(
        {
          name: 'AES-GCM',
          iv: iv
        },
        cryptoKey,
        encodedMessage
      );

      return {
        encryptedContent: this.arrayBufferToHex(encryptedBuffer),
        iv: this.arrayBufferToHex(iv.buffer)
      };
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Verschlüsselung fehlgeschlagen');
    }
  }

  // Entschlüssele eine Nachricht
  async decryptMessage(encryptedContent: string, keyHex: string, ivHex: string): Promise<string> {
    try {
      // Importiere den Schlüssel
      const keyBuffer = this.hexToArrayBuffer(keyHex);
      const cryptoKey = await crypto.subtle.importKey(
        'raw',
        keyBuffer,
        { name: 'AES-GCM' },
        false,
        ['decrypt']
      );

      // Konvertiere verschlüsselte Daten und IV
      const encryptedBuffer = this.hexToArrayBuffer(encryptedContent);
      const ivBuffer = this.hexToArrayBuffer(ivHex);

      // Entschlüssele die Nachricht
      const decryptedBuffer = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: ivBuffer
        },
        cryptoKey,
        encryptedBuffer
      );

      return this.decoder.decode(decryptedBuffer);
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Entschlüsselung fehlgeschlagen');
    }
  }

  // Generiere einen sicheren Hash für Audit-Zwecke
  async generateHash(data: string): Promise<string> {
    const encodedData = this.encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', encodedData);
    return this.arrayBufferToHex(hashBuffer);
  }

  // Sichere Schlüssel-Ableitung mit PBKDF2
  async deriveKey(password: string, salt: string, iterations: number = 100000): Promise<string> {
    const passwordBuffer = this.encoder.encode(password);
    const saltBuffer = this.hexToArrayBuffer(salt);

    // Importiere das Passwort als Schlüssel
    const baseKey = await crypto.subtle.importKey(
      'raw',
      passwordBuffer,
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );

    // Leite den Schlüssel ab
    const derivedKey = await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: saltBuffer,
        iterations: iterations,
        hash: 'SHA-256'
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );

    // Exportiere den Schlüssel
    const exportedKey = await crypto.subtle.exportKey('raw', derivedKey);
    return this.arrayBufferToHex(exportedKey);
  }

  // Generiere einen sicheren Salt
  generateSalt(): string {
    const array = new Uint8Array(16); // 128-bit salt
    crypto.getRandomValues(array);
    return this.arrayBufferToHex(array.buffer);
  }

  // Validiere Schlüssel-Format
  validateKey(keyHex: string): boolean {
    return /^[0-9a-f]{64}$/i.test(keyHex); // 256-bit key = 64 hex characters
  }

  // Sichere Schlüssel-Löschung (überschreibe Speicher)
  secureKeyDeletion(keyHex: string): void {
    // In JavaScript können wir den Speicher nicht direkt überschreiben,
    // aber wir können sicherstellen, dass der Schlüssel nicht mehr referenziert wird
    keyHex = '0'.repeat(keyHex.length);
  }
}