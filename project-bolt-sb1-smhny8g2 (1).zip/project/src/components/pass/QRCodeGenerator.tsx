import { QrCode } from 'lucide-react';

interface QRCodeGeneratorProps {
  value: string;
  size?: number;
}

export function QRCodeGenerator({ value, size = 200 }: QRCodeGeneratorProps) {
  // Simple QR code representation - in production, use a proper QR code library
  const generateQRPattern = (text: string) => {
    const hash = text.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    const pattern = [];
    for (let i = 0; i < 25; i++) {
      pattern.push((hash + i) % 2 === 0);
    }
    return pattern;
  };

  const pattern = generateQRPattern(value);

  return (
    <div className="flex flex-col items-center gap-4">
      <div 
        className="bg-white p-4 rounded-lg shadow-lg border-2 border-gray-200"
        style={{ width: size, height: size }}
      >
        <div className="w-full h-full grid grid-cols-5 gap-1">
          {pattern.map((filled, index) => (
            <div
              key={index}
              className={`rounded-sm ${filled ? 'bg-black' : 'bg-white'}`}
            />
          ))}
        </div>
      </div>
      <div className="text-center">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <QrCode className="w-4 h-4" />
          <span>QR-Code: {value}</span>
        </div>
      </div>
    </div>
  );
}