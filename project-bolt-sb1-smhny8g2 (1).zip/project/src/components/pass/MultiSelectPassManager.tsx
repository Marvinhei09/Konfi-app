import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Users, CheckCircle, Clock, MapPin, User, Calendar, 
  Check, X, Search, Filter, Crown, Medal, Award
} from 'lucide-react';
import type { KonfiPass, ActivitySignature, KonfiContact } from '@/types';

interface MultiSelectPassManagerProps {
  passes: KonfiPass[];
  onPassesChange: (passes: KonfiPass[]) => void;
  contacts: KonfiContact[];
}

export function MultiSelectPassManager({ passes, onPassesChange, contacts }: MultiSelectPassManagerProps) {
  const [selectedPasses, setSelectedPasses] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [showSignatureForm, setShowSignatureForm] = useState(false);
  
  // Signature form state
  const [signatureForm, setSignatureForm] = useState({
    activityType: '' as 'konfirmationsunterricht' | 'gottesdienst' | 'kirchliche_aktivitaet' | '',
    activityTitle: '',
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().slice(0, 5),
    comments: '',
    location: ''
  });

  // Filter passes based on search and role
  const filteredPasses = passes.filter(pass => {
    const contact = contacts.find(c => c.username === pass.konfiUsername);
    if (!contact) return false;

    const matchesSearch = 
      contact.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.username.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRole = filterRole === 'all' || contact.konfiRole === filterRole;

    return matchesSearch && matchesRole;
  });

  const handleSelectAll = () => {
    if (selectedPasses.length === filteredPasses.length) {
      setSelectedPasses([]);
    } else {
      setSelectedPasses(filteredPasses.map(p => p.id));
    }
  };

  const handleSelectPass = (passId: string) => {
    setSelectedPasses(prev => 
      prev.includes(passId) 
        ? prev.filter(id => id !== passId)
        : [...prev, passId]
    );
  };

  const addSignatureToSelected = () => {
    if (!signatureForm.activityType || !signatureForm.activityTitle || selectedPasses.length === 0) {
      return;
    }

    const updatedPasses = passes.map(pass => {
      if (selectedPasses.includes(pass.id)) {
        const newSignature: ActivitySignature = {
          id: `${Date.now()}_${pass.id}`,
          konfiUsername: pass.konfiUsername,
          activityType: signatureForm.activityType,
          activityTitle: signatureForm.activityTitle,
          date: signatureForm.date,
          time: signatureForm.time,
          adminSignature: 'Marvin.Heiligentag',
          comments: signatureForm.comments || undefined,
          location: signatureForm.location || undefined
        };

        return {
          ...pass,
          signatures: [...pass.signatures, newSignature]
        };
      }
      return pass;
    });

    onPassesChange(updatedPasses);
    
    // Reset form and selection
    setSignatureForm({
      activityType: '',
      activityTitle: '',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().slice(0, 5),
      comments: '',
      location: ''
    });
    setSelectedPasses([]);
    setShowSignatureForm(false);
  };

  const getActivityTypeLabel = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'Konfirmationsunterricht';
      case 'gottesdienst': return 'Gottesdienst';
      case 'kirchliche_aktivitaet': return 'Kirchliche Aktivität';
      default: return type;
    }
  };

  const getActivityTypeColor = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'bg-blue-500';
      case 'gottesdienst': return 'bg-green-500';
      case 'kirchliche_aktivitaet': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoleBadgeColor = (role?: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Mehrfachauswahl - Pässe verwalten</h2>
          <p className="text-gray-600 text-sm mt-1">
            Wählen Sie mehrere Konfirmanden aus und fügen Sie Unterschriften für alle gleichzeitig hinzu
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowSignatureForm(true)}
            disabled={selectedPasses.length === 0}
            className="gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            Unterschrift für {selectedPasses.length} Pässe hinzufügen
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Konfirmanden suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger>
                <SelectValue placeholder="Rolle filtern" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Rollen</SelectItem>
                <SelectItem value="KU4">KU4 - 4. Klasse</SelectItem>
                <SelectItem value="KUZ">KUZ - Zwischenjahr</SelectItem>
                <SelectItem value="KU8">KU8 - 8. Klasse</SelectItem>
              </SelectContent>
            </Select>

            <Button 
              variant="outline" 
              onClick={handleSelectAll}
              className="gap-2"
            >
              {selectedPasses.length === filteredPasses.length ? (
                <>
                  <X className="w-4 h-4" />
                  Alle abwählen
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Alle auswählen
                </>
              )}
            </Button>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {selectedPasses.length} von {filteredPasses.length} ausgewählt
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selected Passes Summary */}
      {selectedPasses.length > 0 && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>{selectedPasses.length} Konfirmanden ausgewählt:</strong>
            <div className="mt-2 flex flex-wrap gap-1">
              {selectedPasses.map(passId => {
                const pass = passes.find(p => p.id === passId);
                const contact = contacts.find(c => c.username === pass?.konfiUsername);
                return contact ? (
                  <Badge key={passId} variant="secondary" className="text-xs">
                    {contact.firstName} {contact.lastName}
                  </Badge>
                ) : null;
              })}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Signature Form Modal */}
      {showSignatureForm && (
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle>Unterschrift für {selectedPasses.length} Konfirmanden hinzufügen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="activityType">Art der Aktivität</Label>
                <Select 
                  value={signatureForm.activityType} 
                  onValueChange={(value: any) => setSignatureForm({...signatureForm, activityType: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Aktivität auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="konfirmationsunterricht">Konfirmationsunterricht</SelectItem>
                    <SelectItem value="gottesdienst">Gottesdienst</SelectItem>
                    <SelectItem value="kirchliche_aktivitaet">Kirchliche Aktivität</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="activityTitle">Titel der Aktivität</Label>
                <Input
                  id="activityTitle"
                  value={signatureForm.activityTitle}
                  onChange={(e) => setSignatureForm({...signatureForm, activityTitle: e.target.value})}
                  placeholder="z.B. Die Zehn Gebote, Sonntagsgottesdienst"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div>
                <Label htmlFor="date">Datum</Label>
                <Input
                  id="date"
                  type="date"
                  value={signatureForm.date}
                  onChange={(e) => setSignatureForm({...signatureForm, date: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="time">Uhrzeit</Label>
                <Input
                  id="time"
                  type="time"
                  value={signatureForm.time}
                  onChange={(e) => setSignatureForm({...signatureForm, time: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="location">Ort (optional)</Label>
                <Input
                  id="location"
                  value={signatureForm.location}
                  onChange={(e) => setSignatureForm({...signatureForm, location: e.target.value})}
                  placeholder="z.B. Gemeindehaus, Hauptkirche"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="comments">Kommentar (optional)</Label>
              <Textarea
                id="comments"
                value={signatureForm.comments}
                onChange={(e) => setSignatureForm({...signatureForm, comments: e.target.value})}
                placeholder="Zusätzliche Bemerkungen..."
                rows={3}
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button 
                onClick={addSignatureToSelected}
                className="gap-2"
                disabled={!signatureForm.activityType || !signatureForm.activityTitle}
              >
                <CheckCircle className="w-4 h-4" />
                Unterschrift für alle {selectedPasses.length} Pässe hinzufügen
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowSignatureForm(false)}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Passes Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredPasses.map((pass) => {
          const contact = contacts.find(c => c.username === pass.konfiUsername);
          const isSelected = selectedPasses.includes(pass.id);
          
          if (!contact) return null;

          return (
            <Card 
              key={pass.id} 
              className={`transition-all cursor-pointer border-2 ${
                isSelected 
                  ? 'border-blue-500 bg-blue-50 shadow-lg' 
                  : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
              }`}
              onClick={() => handleSelectPass(pass.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={isSelected}
                      onChange={() => handleSelectPass(pass.id)}
                      className="mt-1"
                    />
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{contact.firstName} {contact.lastName}</h3>
                      <p className="text-sm text-gray-600">@{contact.username}</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Badge variant={getRoleBadgeColor(contact.konfiRole)}>
                      {contact.konfiRole}
                    </Badge>
                    <Badge variant={pass.isActive ? "default" : "secondary"} className="text-xs">
                      {pass.isActive ? "Aktiv" : "Inaktiv"}
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Unterschriften:</span>
                    <span className="font-semibold">{pass.signatures.length}</span>
                  </div>
                  
                  {pass.signatures.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs text-gray-600">Letzte Aktivitäten:</p>
                      {pass.signatures.slice(-2).map((signature) => (
                        <div key={signature.id} className="flex items-center gap-1 text-xs">
                          <div className={`w-2 h-2 rounded-full ${getActivityTypeColor(signature.activityType)}`} />
                          <span className="truncate">{signature.activityTitle}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {isSelected && (
                  <div className="mt-3 pt-3 border-t border-blue-200">
                    <div className="flex items-center gap-2 text-blue-600">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm font-medium">Ausgewählt für Gruppenaktion</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredPasses.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Keine Pässe entsprechen den Filterkriterien.</p>
            <p className="text-sm text-gray-500">Passen Sie Ihre Suchkriterien an.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}