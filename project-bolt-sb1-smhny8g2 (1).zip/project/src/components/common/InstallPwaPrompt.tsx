import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, X } from 'lucide-react';
import { webAppUtils } from '@/utils/webAppUtils';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function InstallPwaPrompt() {
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if already installed as PWA
    if (webAppUtils.isPwa()) {
      return;
    }

    // Check if iOS
    const browserInfo = webAppUtils.getBrowserInfo();
    setIsIOS(browserInfo.isIOS);

    // For non-iOS devices, listen for the beforeinstallprompt event
    if (!browserInfo.isIOS) {
      const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        setInstallPrompt(e as BeforeInstallPromptEvent);
        setShowPrompt(true);
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

      // Check if we should show the prompt (not shown in last 7 days)
      const lastPrompt = localStorage.getItem('pwaPromptLastShown');
      if (lastPrompt) {
        const daysSinceLastPrompt = (Date.now() - parseInt(lastPrompt)) / (1000 * 60 * 60 * 24);
        if (daysSinceLastPrompt < 7) {
          setShowPrompt(false);
        }
      }

      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      };
    } else {
      // For iOS, check if we've shown the prompt recently
      const lastPrompt = localStorage.getItem('pwaPromptLastShown');
      if (lastPrompt) {
        const daysSinceLastPrompt = (Date.now() - parseInt(lastPrompt)) / (1000 * 60 * 60 * 24);
        if (daysSinceLastPrompt < 7) {
          setShowPrompt(false);
          return;
        }
      }
      
      // Show iOS prompt after 3 seconds
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) return;
    
    await installPrompt.prompt();
    const choiceResult = await installPrompt.userChoice;
    
    if (choiceResult.outcome === 'accepted') {
      console.log('User accepted the install prompt');
    } else {
      console.log('User dismissed the install prompt');
    }
    
    setInstallPrompt(null);
    setShowPrompt(false);
    localStorage.setItem('pwaPromptLastShown', Date.now().toString());
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwaPromptLastShown', Date.now().toString());
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-4 left-0 right-0 mx-auto w-full max-w-md px-4 z-40 animate-in fade-in slide-in-from-bottom-5 duration-300">
      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Download className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-blue-800">
                App installieren
              </h3>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleDismiss}
              className="h-8 w-8 p-0 text-gray-500"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          {isIOS ? (
            <div className="space-y-2">
              <p className="text-sm text-blue-700">
                Installieren Sie diese App auf Ihrem iPhone:
              </p>
              <ol className="text-xs text-blue-700 space-y-1 pl-5 list-decimal">
                <li>Tippen Sie auf <span className="inline-flex items-center"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.25 12H12m0 0h3.75M12 12v3.75m0-3.75V8.25" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg> Teilen</span></li>
                <li>Scrollen Sie nach unten und tippen Sie auf <strong>Zum Home-Bildschirm</strong></li>
              </ol>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-blue-700">
                Installieren Sie diese App auf Ihrem Gerät für schnelleren Zugriff und bessere Funktionalität.
              </p>
              <Button 
                onClick={handleInstall} 
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                <Download className="mr-2 h-4 w-4" />
                App installieren
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}