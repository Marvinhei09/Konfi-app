import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { webAppUtils } from '@/utils/webAppUtils';

export function OfflineIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showIndicator, setShowIndicator] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Keep showing for a moment so user can see we're back online
      setTimeout(() => setShowIndicator(false), 3000);
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      setShowIndicator(true);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Hide after 5 seconds if we're online
  useEffect(() => {
    let timer: number;
    if (isOnline && showIndicator) {
      timer = window.setTimeout(() => {
        setShowIndicator(false);
      }, 5000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isOnline, showIndicator]);

  if (!showIndicator) return null;

  return (
    <div className="fixed bottom-4 left-0 right-0 mx-auto w-full max-w-md px-4 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
      <Alert variant={isOnline ? "default" : "destructive"} className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isOnline ? (
            <Wifi className="h-4 w-4" />
          ) : (
            <WifiOff className="h-4 w-4" />
          )}
          <AlertDescription>
            {isOnline 
              ? 'Verbindung wiederhergestellt. Daten werden synchronisiert...' 
              : 'Sie sind offline. Einige Funktionen sind möglicherweise eingeschränkt.'}
          </AlertDescription>
        </div>
        {!isOnline && (
          <Button 
            size="sm" 
            variant="outline" 
            className="ml-2 h-8 px-2"
            onClick={() => window.location.reload()}
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Neu laden
          </Button>
        )}
      </Alert>
    </div>
  );
}