import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Settings, Save, RotateCcw, ArrowLeft } from 'lucide-react';

interface ScannerSettingsProps {
  settings: {
    enableBeep: boolean;
    enableVibration: boolean;
    enableFlashlight: boolean;
    scanContinuously: boolean;
    preferredCamera: 'environment' | 'user';
    scanTimeout: number;
  };
  onSettingsChange: (settings: any) => void;
  onBack: () => void;
}

export function ScannerSettings({ 
  settings, 
  onSettingsChange, 
  onBack 
}: ScannerSettingsProps) {
  const handleReset = () => {
    onSettingsChange({
      enableBeep: true,
      enableVibration: true,
      enableFlashlight: true,
      scanContinuously: false,
      preferredCamera: 'environment',
      scanTimeout: 30
    });
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Scanner-Einstellungen
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="beep">Ton-Feedback</Label>
              <p className="text-sm text-gray-500">
                Akustisches Signal bei erfolgreichem Scan
              </p>
            </div>
            <Switch
              id="beep"
              checked={settings.enableBeep}
              onCheckedChange={(checked) => 
                onSettingsChange({ ...settings, enableBeep: checked })
              }
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="vibration">Vibration</Label>
              <p className="text-sm text-gray-500">
                Haptisches Feedback bei erfolgreichem Scan
              </p>
            </div>
            <Switch
              id="vibration"
              checked={settings.enableVibration}
              onCheckedChange={(checked) => 
                onSettingsChange({ ...settings, enableVibration: checked })
              }
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="flashlight">Taschenlampe</Label>
              <p className="text-sm text-gray-500">
                Taschenlampen-Steuerung aktivieren
              </p>
            </div>
            <Switch
              id="flashlight"
              checked={settings.enableFlashlight}
              onCheckedChange={(checked) => 
                onSettingsChange({ ...settings, enableFlashlight: checked })
              }
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="continuous">Kontinuierliches Scannen</Label>
              <p className="text-sm text-gray-500">
                Mehrere Codes nacheinander scannen
              </p>
            </div>
            <Switch
              id="continuous"
              checked={settings.scanContinuously}
              onCheckedChange={(checked) => 
                onSettingsChange({ ...settings, scanContinuously: checked })
              }
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="camera">Bevorzugte Kamera</Label>
            <Select
              value={settings.preferredCamera}
              onValueChange={(value: 'environment' | 'user') => 
                onSettingsChange({ ...settings, preferredCamera: value })
              }
            >
              <SelectTrigger id="camera">
                <SelectValue placeholder="Kamera wählen" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="environment">Rückkamera (Standard)</SelectItem>
                <SelectItem value="user">Frontkamera (Selfie)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500">
              Die Rückkamera bietet in der Regel bessere Scan-Ergebnisse
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="timeout">
              Scan-Timeout (Sekunden): {settings.scanTimeout}
            </Label>
            <Input
              id="timeout"
              type="range"
              min="0"
              max="60"
              step="5"
              value={settings.scanTimeout}
              onChange={(e) => 
                onSettingsChange({ 
                  ...settings, 
                  scanTimeout: parseInt(e.target.value) 
                })
              }
            />
            <p className="text-xs text-gray-500">
              0 = Kein Timeout, Scanner läuft unbegrenzt
            </p>
          </div>
        </div>
        
        <div className="flex gap-2 pt-4 border-t">
          <Button
            variant="outline"
            onClick={onBack}
            className="flex-1 gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Zurück
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            className="gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Zurücksetzen
          </Button>
          <Button
            onClick={onBack}
            className="flex-1 gap-2"
          >
            <Save className="w-4 h-4" />
            Speichern
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}