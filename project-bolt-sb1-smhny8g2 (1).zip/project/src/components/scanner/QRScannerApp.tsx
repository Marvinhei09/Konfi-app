import React, { useState, useRef, useEffect } from 'react';
import { Camera, QrCode, Settings, Info } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

interface ScanResult {
  data: string;
  timestamp: Date;
}

export function QRScannerApp() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);
  const [hasCamera, setHasCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    checkCameraAvailability();
    return () => {
      stopCamera();
    };
  }, []);

  const checkCameraAvailability = async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(device => device.kind === 'videoinput');
      setHasCamera(videoDevices.length > 0);
    } catch (error) {
      console.error('Error checking camera availability:', error);
      setHasCamera(false);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsScanning(true);
      }
    } catch (error) {
      console.error('Error starting camera:', error);
      alert('Unable to access camera. Please check permissions.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const handleManualEntry = (code: string) => {
    if (code.trim()) {
      const result: ScanResult = {
        data: code.trim(),
        timestamp: new Date()
      };
      setScanResults(prev => [result, ...prev]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <QrCode className="h-8 w-8 text-indigo-600" />
            <h1 className="text-3xl font-bold text-gray-900">QR Scanner</h1>
          </div>
          <p className="text-gray-600">Scan QR codes or enter codes manually</p>
        </div>

        <Tabs defaultValue="scanner" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="scanner" className="flex items-center gap-2">
              <Camera className="h-4 w-4" />
              Scanner
            </TabsTrigger>
            <TabsTrigger value="manual" className="flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              Manual
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center gap-2">
              <Info className="h-4 w-4" />
              Results
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scanner">
            <Card>
              <CardHeader>
                <CardTitle>Camera Scanner</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!hasCamera ? (
                  <div className="text-center py-8">
                    <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No camera detected</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      {!isScanning && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
                          <div className="text-center text-white">
                            <Camera className="h-16 w-16 mx-auto mb-4" />
                            <p>Camera ready to scan</p>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 justify-center">
                      {!isScanning ? (
                        <Button onClick={startCamera} className="flex items-center gap-2">
                          <Camera className="h-4 w-4" />
                          Start Scanning
                        </Button>
                      ) : (
                        <Button onClick={stopCamera} variant="destructive" className="flex items-center gap-2">
                          <Camera className="h-4 w-4" />
                          Stop Scanning
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manual">
            <Card>
              <CardHeader>
                <CardTitle>Manual Code Entry</CardTitle>
              </CardHeader>
              <CardContent>
                <ManualCodeEntry onCodeSubmit={handleManualEntry} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            <Card>
              <CardHeader>
                <CardTitle>Scan Results ({scanResults.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <ScanResult results={scanResults} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Scanner Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <ScannerSettings />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Simple fallback components for missing imports
function ManualCodeEntry({ onCodeSubmit }: { onCodeSubmit: (code: string) => void }) {
  const [code, setCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCodeSubmit(code);
    setCode('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="code" className="block text-sm font-medium text-gray-700 mb-2">
          Enter QR Code Data
        </label>
        <input
          type="text"
          id="code"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Enter code manually..."
        />
      </div>
      <Button type="submit" disabled={!code.trim()}>
        Add Code
      </Button>
    </form>
  );
}

function ScanResult({ results }: { results: ScanResult[] }) {
  if (results.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <QrCode className="h-16 w-16 mx-auto mb-4 text-gray-300" />
        <p>No scan results yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {results.map((result, index) => (
        <div key={index} className="p-4 bg-gray-50 rounded-lg">
          <div className="font-mono text-sm break-all mb-2">{result.data}</div>
          <div className="text-xs text-gray-500">
            {result.timestamp.toLocaleString()}
          </div>
        </div>
      ))}
    </div>
  );
}

function ScannerSettings() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Auto-save results</span>
        <input type="checkbox" defaultChecked className="rounded" />
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Sound on scan</span>
        <input type="checkbox" className="rounded" />
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Vibrate on scan</span>
        <input type="checkbox" className="rounded" />
      </div>
    </div>
  );
}