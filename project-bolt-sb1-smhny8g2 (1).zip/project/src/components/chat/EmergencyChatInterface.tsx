import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  MessageSquare, Send, Shield, Clock, User as UserIcon, ArrowUp, 
  CheckCircle, AlertTriangle, X, Phone, Mail, Heart,
  Lock, Eye, EyeOff, UserCheck, Crown
} from 'lucide-react';
import { EmergencyEscalationInterface } from './EmergencyEscalationInterface';
import { EmergencyChatEncryption } from '@/utils/emergencyChatEncryption';
import type { 
  EmergencyChat, 
  EmergencyMessage, 
  User, 
  EmergencySupervisor,
  EmergencyEscalation 
} from '@/types';

interface EmergencyChatInterfaceProps {
  chat: EmergencyChat;
  messages: EmergencyMessage[];
  currentUser: User;
  otherParticipant: User;
  supervisors: EmergencySupervisor[];
  onSendMessage: (content: string) => void;
  onEscalateChat: (escalation: Omit<EmergencyEscalation, 'id'>) => void;
  onCloseChat: () => void;
  onBack: () => void;
}

export function EmergencyChatInterface({
  chat,
  messages,
  currentUser,
  otherParticipant,
  supervisors,
  onSendMessage,
  onEscalateChat,
  onCloseChat,
  onBack
}: EmergencyChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState('');
  const [showEscalation, setShowEscalation] = useState(false);
  const [isEncryptionVisible, setIsEncryptionVisible] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const encryption = new EmergencyChatEncryption();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    onSendMessage(newMessage);
    setNewMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'mobbing': return 'Mobbing/Konflikte';
      case 'family': return 'Familie/Zuhause';
      case 'health': return 'Gesundheit/Wohlbefinden';
      case 'safety': return 'Sicherheit/Gefahr';
      case 'spiritual': return 'Glaube/Spiritualität';
      default: return 'Sonstiges';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600';
      case 'escalated': return 'text-orange-600';
      case 'resolved': return 'text-blue-600';
      case 'closed': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  const canEscalate = currentUser.role === 'teamer' && chat.status === 'active' && !chat.escalatedTo;
  const availablePastors = supervisors.filter(s => s.role === 'pastor' && s.isAvailable);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('de-DE', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getParticipantRole = (user: User) => {
    switch (user.role) {
      case 'konfi': return 'Konfirmand';
      case 'teamer': return 'Teamer';
      case 'pastor': return 'Pastor';
      case 'admin': return 'Administrator';
      default: return user.role;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <Card className="rounded-none border-b shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-start">
            <div className="flex items-start gap-4">
              <Button variant="outline" size="sm" onClick={onBack} className="gap-2">
                <X className="w-4 h-4" />
                Zurück
              </Button>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    {otherParticipant.profileImage ? (
                      <img
                        src={otherParticipant.profileImage}
                        alt={`${otherParticipant.firstName} ${otherParticipant.lastName}`}
                        className="w-10 h-10 rounded-full object-cover border-2 border-white shadow"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                        {otherParticipant.firstName?.[0]}{otherParticipant.lastName?.[0]}
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold">
                        {otherParticipant.firstName} {otherParticipant.lastName}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {getParticipantRole(otherParticipant)}
                        {otherParticipant.role === 'pastor' && (
                          <Crown className="w-3 h-3 inline ml-1 text-purple-600" />
                        )}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={`${getPriorityColor(chat.priority)} text-white`}>
                      {chat.priority === 'critical' ? 'Kritisch' : 
                       chat.priority === 'high' ? 'Hoch' : 
                       chat.priority === 'medium' ? 'Mittel' : 'Niedrig'}
                    </Badge>
                    <Badge variant="outline">
                      {getCategoryLabel(chat.category)}
                    </Badge>
                    <Badge variant="outline" className={getStatusColor(chat.status)}>
                      {chat.status === 'active' ? 'Aktiv' : 
                       chat.status === 'escalated' ? 'Weitergeleitet' : 
                       chat.status === 'resolved' ? 'Gelöst' : 'Geschlossen'}
                    </Badge>
                  </div>
                </div>

                {/* Verschlüsselungs-Info */}
                <div className="flex items-center gap-2 text-sm">
                  <div className="flex items-center gap-1 text-green-600">
                    <Shield className="w-4 h-4" />
                    <span>Ende-zu-Ende verschlüsselt</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEncryptionVisible(!isEncryptionVisible)}
                    className="h-6 px-2 text-xs"
                  >
                    {isEncryptionVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </Button>
                  {isEncryptionVisible && (
                    <span className="text-xs text-gray-500 font-mono">
                      {chat.encryptionKey.slice(0, 8)}...
                    </span>
                  )}
                </div>

                {/* Eskalations-Info */}
                {chat.status === 'escalated' && chat.escalatedTo && (
                  <Alert className="mt-3">
                    <ArrowUp className="h-4 w-4" />
                    <AlertDescription>
                      Dieser Chat wurde an einen Pastor weitergeleitet am{' '}
                      {chat.escalatedAt ? new Date(chat.escalatedAt).toLocaleString('de-DE') : 'unbekannt'}.
                      {chat.escalationReason && (
                        <span className="block mt-1 text-sm">
                          Grund: {chat.escalationReason}
                        </span>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {canEscalate && availablePastors.length > 0 && (
                <Button
                  onClick={() => setShowEscalation(true)}
                  variant="outline"
                  className="gap-2 border-orange-300 text-orange-700 hover:bg-orange-50"
                >
                  <ArrowUp className="w-4 h-4" />
                  An Pastor weiterleiten
                </Button>
              )}
              
              <Button
                onClick={onCloseChat}
                variant="outline"
                className="gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Chat beenden
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => {
          const isOwnMessage = message.senderId === currentUser.id;
          const sender = isOwnMessage ? currentUser : otherParticipant;
          
          return (
            <div
              key={message.id}
              className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md ${isOwnMessage ? 'order-2' : 'order-1'}`}>
                <div
                  className={`rounded-lg px-4 py-2 ${
                    isOwnMessage
                      ? 'bg-blue-600 text-white'
                      : message.messageType === 'system'
                      ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                      : message.messageType === 'escalation'
                      ? 'bg-orange-100 text-orange-800 border border-orange-300'
                      : 'bg-white text-gray-900 border border-gray-200'
                  }`}
                >
                  {message.messageType === 'system' && (
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="w-4 h-4" />
                      <span className="text-xs font-semibold">System</span>
                    </div>
                  )}
                  
                  {message.messageType === 'escalation' && (
                    <div className="flex items-center gap-2 mb-1">
                      <ArrowUp className="w-4 h-4" />
                      <span className="text-xs font-semibold">Weiterleitung</span>
                    </div>
                  )}
                  
                  <p className="text-sm">{message.content}</p>
                  
                  <div className={`flex items-center justify-between mt-1 text-xs ${
                    isOwnMessage ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    <span>{formatTime(message.timestamp)}</span>
                    {isOwnMessage && message.isRead && (
                      <UserCheck className="w-3 h-3" />
                    )}
                  </div>
                </div>
                
                {!isOwnMessage && (
                  <div className="flex items-center gap-2 mt-1 ml-2">
                    {sender.profileImage ? (
                      <img
                        src={sender.profileImage}
                        alt={`${sender.firstName} ${sender.lastName}`}
                        className="w-6 h-6 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-gray-400 flex items-center justify-center text-white text-xs font-semibold">
                        {sender.firstName?.[0]}{sender.lastName?.[0]}
                      </div>
                    )}
                    <span className="text-xs text-gray-500">
                      {sender.firstName} {sender.lastName}
                    </span>
                    {sender.role === 'pastor' && (
                      <Crown className="w-3 h-3 text-purple-600" />
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <Card className="rounded-none border-t">
        <CardContent className="p-4">
          <div className="flex gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Nachricht eingeben... (Enter zum Senden)"
              className="flex-1"
              disabled={chat.status === 'closed'}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || chat.status === 'closed'}
              className="gap-2"
            >
              <Send className="w-4 h-4" />
              Senden
            </Button>
          </div>
          
          <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Lock className="w-3 h-3" />
                <span>Verschlüsselt</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>
                  Automatische Löschung: {new Date(chat.metadata.autoDeleteAt).toLocaleDateString('de-DE')}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {otherParticipant.emergencyContactInfo?.phone && (
                <div className="flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  <span>{otherParticipant.emergencyContactInfo.phone}</span>
                </div>
              )}
              {otherParticipant.emergencyContactInfo?.email && (
                <div className="flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  <span>{otherParticipant.emergencyContactInfo.email}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Eskalations-Interface */}
      {showEscalation && (
        <EmergencyEscalationInterface
          chat={chat}
          currentUser={currentUser}
          availablePastors={availablePastors}
          onEscalate={(escalation) => {
            onEscalateChat(escalation);
            setShowEscalation(false);
          }}
          onClose={() => setShowEscalation(false)}
        />
      )}
    </div>
  );
}