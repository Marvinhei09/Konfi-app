import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  AlertTriangle, ArrowUp, Clock, User as UserIcon, Phone, Mail, 
  CheckCircle, X, Send, Shield, Heart, MessageSquare
} from 'lucide-react';
import type { EmergencyChat, EmergencySupervisor, User, EmergencyEscalation } from '@/types';

interface EmergencyEscalationInterfaceProps {
  chat: EmergencyChat;
  currentUser: User;
  availablePastors: EmergencySupervisor[];
  onEscalate: (escalation: Omit<EmergencyEscalation, 'id'>) => void;
  onClose: () => void;
}

export function EmergencyEscalationInterface({ 
  chat, 
  currentUser, 
  availablePastors, 
  onEscalate, 
  onClose 
}: EmergencyEscalationInterfaceProps) {
  const [selectedPastor, setSelectedPastor] = useState<string>('');
  const [escalationReason, setEscalationReason] = useState('');
  const [context, setContext] = useState('');
  const [priority, setPriority] = useState<'high' | 'critical'>('high');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleEscalate = async () => {
    if (!selectedPastor || !escalationReason.trim() || !context.trim()) {
      return;
    }

    setIsSubmitting(true);

    const escalation: Omit<EmergencyEscalation, 'id'> = {
      chatId: chat.id,
      fromSupervisorId: currentUser.id,
      toPastorId: selectedPastor,
      reason: escalationReason,
      escalatedAt: new Date().toISOString(),
      priority,
      context,
      isAccepted: false
    };

    try {
      await onEscalate(escalation);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      default: return 'bg-yellow-500';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'mobbing': return 'Mobbing/Konflikte';
      case 'family': return 'Familie/Zuhause';
      case 'health': return 'Gesundheit/Wohlbefinden';
      case 'safety': return 'Sicherheit/Gefahr';
      case 'spiritual': return 'Glaube/Spiritualität';
      default: return 'Sonstiges';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-red-50 border-b">
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <ArrowUp className="w-5 h-5" />
              Fall an Pastor weiterleiten
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          {/* Chat-Informationen */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                Chat-Informationen
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <Label className="text-sm font-medium text-gray-700">Kategorie</Label>
                  <p className="text-sm">{getCategoryLabel(chat.category)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Aktuelle Priorität</Label>
                  <Badge variant="outline" className={`${getPriorityColor(chat.priority)} text-white`}>
                    {chat.priority === 'critical' ? 'Kritisch' : 
                     chat.priority === 'high' ? 'Hoch' : 
                     chat.priority === 'medium' ? 'Mittel' : 'Niedrig'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Erstellt am</Label>
                  <p className="text-sm">{new Date(chat.createdAt).toLocaleString('de-DE')}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Nachrichten</Label>
                  <p className="text-sm">{chat.metadata.messageCount} Nachrichten</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Eskalations-Priorität */}
          <div>
            <Label className="text-base font-semibold mb-3 block">Eskalations-Priorität</Label>
            <div className="grid gap-3 md:grid-cols-2">
              <Card 
                className={`cursor-pointer transition-all border-2 ${
                  priority === 'high' 
                    ? 'border-orange-500 bg-orange-50' 
                    : 'border-gray-200 hover:border-orange-300'
                }`}
                onClick={() => setPriority('high')}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full bg-orange-500"></div>
                    <div>
                      <h4 className="font-semibold">Hoch</h4>
                      <p className="text-sm text-gray-600">Komplexer Fall, benötigt pastorale Expertise</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card 
                className={`cursor-pointer transition-all border-2 ${
                  priority === 'critical' 
                    ? 'border-red-500 bg-red-50' 
                    : 'border-gray-200 hover:border-red-300'
                }`}
                onClick={() => setPriority('critical')}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full bg-red-500"></div>
                    <div>
                      <h4 className="font-semibold">Kritisch</h4>
                      <p className="text-sm text-gray-600">Akute Krise, sofortige pastorale Intervention nötig</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Pastor-Auswahl */}
          <div>
            <Label className="text-base font-semibold mb-3 block">Pastor auswählen</Label>
            <div className="grid gap-4 md:grid-cols-2">
              {availablePastors.map((pastor) => (
                <Card 
                  key={pastor.id}
                  className={`cursor-pointer transition-all border-2 ${
                    selectedPastor === pastor.id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => setSelectedPastor(pastor.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
                        <UserIcon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold">Pastor {pastor.userId}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={pastor.status === 'available' ? 'default' : 'secondary'}>
                            {pastor.status === 'available' ? 'Verfügbar' : 
                             pastor.status === 'busy' ? 'Beschäftigt' : 
                             pastor.status === 'emergency_only' ? 'Nur Notfälle' : 'Offline'}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {pastor.currentChats.length}/{pastor.maxConcurrentChats} Chats
                          </span>
                        </div>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center gap-1 text-xs text-gray-600">
                            <Phone className="w-3 h-3" />
                            <span>{pastor.emergencyContact.phone || 'Nicht verfügbar'}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs text-gray-600">
                            <Mail className="w-3 h-3" />
                            <span>{pastor.emergencyContact.email || 'Nicht verfügbar'}</span>
                          </div>
                        </div>
                        <div className="mt-2">
                          <p className="text-xs text-gray-600">Spezialisierungen:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {pastor.specializations.slice(0, 2).map((spec) => (
                              <Badge key={spec} variant="outline" className="text-xs">
                                {spec}
                              </Badge>
                            ))}
                            {pastor.specializations.length > 2 && (
                              <span className="text-xs text-gray-500">+{pastor.specializations.length - 2}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Grund für Eskalation */}
          <div>
            <Label htmlFor="reason" className="text-base font-semibold">
              Grund für die Weiterleitung *
            </Label>
            <Textarea
              id="reason"
              value={escalationReason}
              onChange={(e) => setEscalationReason(e.target.value)}
              placeholder="Warum benötigt dieser Fall pastorale Betreuung? (z.B. Komplexität, Schwere, spezielle Expertise erforderlich)"
              rows={3}
              className="mt-2"
            />
          </div>

          {/* Kontext für Pastor */}
          <div>
            <Label htmlFor="context" className="text-base font-semibold">
              Zusammenfassung für Pastor *
            </Label>
            <Textarea
              id="context"
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="Kurze Zusammenfassung der Situation für den Pastor (ohne persönliche Details, die nicht notwendig sind)"
              rows={4}
              className="mt-2"
            />
            <p className="text-xs text-gray-500 mt-1">
              Geben Sie nur die notwendigen Informationen weiter, um die Vertraulichkeit zu wahren.
            </p>
          </div>

          {/* Wichtige Hinweise */}
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Datenschutz-Hinweis:</strong> Bei der Weiterleitung werden nur die notwendigen 
              Informationen übertragen. Der Pastor erhält Zugriff auf den verschlüsselten Chat und 
              Ihre Zusammenfassung. Alle Daten bleiben Ende-zu-Ende verschlüsselt.
            </AlertDescription>
          </Alert>

          {priority === 'critical' && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Kritische Eskalation:</strong> Der Pastor wird sofort benachrichtigt und 
                erhält eine Notfall-Benachrichtigung. Bitte stellen Sie sicher, dass die Situation 
                wirklich kritisch ist.
              </AlertDescription>
            </Alert>
          )}

          {/* Aktions-Buttons */}
          <div className="flex gap-4 pt-6 border-t">
            <Button 
              onClick={handleEscalate}
              disabled={!selectedPastor || !escalationReason.trim() || !context.trim() || isSubmitting}
              className="flex-1 gap-2 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
            >
              {isSubmitting ? (
                <>
                  <Clock className="w-4 h-4 animate-spin" />
                  Wird weitergeleitet...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  An Pastor weiterleiten
                </>
              )}
            </Button>
            <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
              Abbrechen
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}