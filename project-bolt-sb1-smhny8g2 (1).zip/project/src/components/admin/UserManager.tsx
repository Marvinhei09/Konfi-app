import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Users, Plus, Edit, Trash2, Save, X, Key, Eye, EyeOff, Copy, CheckCircle, AlertCircle, Shield, UserCheck, Plane } from 'lucide-react';
import type { User } from '@/types';

interface UserManagerProps {
  users: User[];
  onUsersChange: (users: User[]) => void;
}

export function UserManager({ users, onUsersChange }: UserManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [copiedPassword, setCopiedPassword] = useState<string>('');
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'konfi' as 'admin' | 'konfi' | 'teamer' | 'pastor',
    konfiRole: 'KU4' as 'KU4' | 'KUZ' | 'KU8',
    firstName: '',
    lastName: '',
    isAvailableForEmergency: false,
    specializations: ''
  });

  const generateSecurePassword = () => {
    const uppercase = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowercase = 'abcdefghijkmnpqrstuvwxyz';
    const numbers = '23456789';
    const symbols = '!@#$%&*';
    
    let password = '';
    password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
    password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
    password += numbers.charAt(Math.floor(Math.random() * numbers.length));
    password += symbols.charAt(Math.floor(Math.random() * symbols.length));
    
    const allChars = uppercase + lowercase + numbers + symbols;
    for (let i = 4; i < 10; i++) {
      password += allChars.charAt(Math.floor(Math.random() * allChars.length));
    }
    
    return password.split('').sort(() => Math.random() - 0.5).join('');
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const validateUserData = () => {
    if (!formData.username.trim()) {
      showNotification('error', 'Benutzername ist erforderlich');
      return false;
    }
    
    if (users.some(u => u.username === formData.username && u.id !== editingId)) {
      showNotification('error', 'Benutzername bereits vergeben');
      return false;
    }
    
    if (!formData.password) {
      showNotification('error', 'Passwort ist erforderlich');
      return false;
    }
    
    if (formData.role === 'konfi' && !formData.konfiRole) {
      showNotification('error', 'Konfirmanden-Rolle ist erforderlich');
      return false;
    }
    
    return true;
  };

  const handleAdd = () => {
    if (!validateUserData()) return;

    const newUser: User = {
      id: Date.now().toString(),
      username: formData.username,
      password: formData.password,
      role: formData.role,
      firstName: formData.firstName,
      lastName: formData.lastName,
      lastActive: new Date().toISOString(),
      ...(formData.role === 'konfi' && { konfiRole: formData.konfiRole }),
      ...((formData.role === 'teamer' || formData.role === 'pastor') && {
        isAvailableForEmergency: formData.isAvailableForEmergency,
        specializations: formData.specializations.split(',').map(s => s.trim()).filter(s => s),
        emergencyContactInfo: {
          phone: '',
          email: '',
          availableHours: ''
        }
      })
    };

    onUsersChange([...users, newUser]);
    
    showNotification('success', 
      `Benutzer erfolgreich erstellt!\nBenutzername: ${formData.username}\nPasswort: ${formData.password}`
    );
    
    resetForm();
    setShowAddForm(false);
  };

  const handleEdit = (user: User) => {
    setEditingId(user.id);
    setFormData({
      username: user.username,
      password: user.password,
      role: user.role,
      konfiRole: user.konfiRole || 'KU4',
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      isAvailableForEmergency: user.isAvailableForEmergency || false,
      specializations: user.specializations?.join(', ') || ''
    });
  };

  const handleSave = () => {
    if (!editingId || !validateUserData()) return;

    const updatedUsers = users.map(u => 
      u.id === editingId 
        ? { 
            ...u, 
            username: formData.username,
            password: formData.password,
            role: formData.role,
            firstName: formData.firstName,
            lastName: formData.lastName,
            ...(formData.role === 'konfi' && { konfiRole: formData.konfiRole }),
            ...(formData.role !== 'konfi' && { konfiRole: undefined }),
            ...((formData.role === 'teamer' || formData.role === 'pastor') && {
              isAvailableForEmergency: formData.isAvailableForEmergency,
              specializations: formData.specializations.split(',').map(s => s.trim()).filter(s => s)
            })
          }
        : u
    );

    onUsersChange(updatedUsers);
    showNotification('success', 'Benutzer erfolgreich aktualisiert');
    setEditingId(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    const userToDelete = users.find(u => u.id === id);
    if (userToDelete) {
      onUsersChange(users.filter(u => u.id !== id));
      showNotification('success', `Benutzer "${userToDelete.username}" wurde gelöscht`);
    }
  };

  const toggleEmergencyAvailability = (userId: string) => {
    const updatedUsers = users.map(u => 
      u.id === userId 
        ? { ...u, isAvailableForEmergency: !u.isAvailableForEmergency }
        : u
    );
    onUsersChange(updatedUsers);
    
    const user = users.find(u => u.id === userId);
    showNotification('success', 
      `${user?.firstName || user?.username} ist jetzt ${!user?.isAvailableForEmergency ? 'verfügbar' : 'nicht verfügbar'} für Notfall-Chats`
    );
  };

  const resetForm = () => {
    setFormData({
      username: '',
      password: '',
      role: 'konfi',
      konfiRole: 'KU4',
      firstName: '',
      lastName: '',
      isAvailableForEmergency: false,
      specializations: ''
    });
  };

  const togglePasswordVisibility = (userId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [userId]: !prev[userId]
    }));
  };

  const copyPassword = async (password: string) => {
    try {
      await navigator.clipboard.writeText(password);
      setCopiedPassword(password);
      showNotification('success', 'Passwort in Zwischenablage kopiert');
      setTimeout(() => setCopiedPassword(''), 2000);
    } catch (err) {
      showNotification('error', 'Fehler beim Kopieren des Passworts');
    }
  };

  const generateNewPassword = () => {
    const newPassword = generateSecurePassword();
    setFormData({ ...formData, password: newPassword });
    showNotification('success', 'Sicheres Passwort generiert');
  };

  const getRoleBadgeColor = (role: string, konfiRole?: string) => {
    if (role === 'admin') return 'default';
    if (role === 'teamer') return 'secondary';
    if (role === 'pastor') return 'destructive';
    
    switch (konfiRole) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  const getRoleLabel = (role: string, konfiRole?: string) => {
    if (role === 'admin') return 'Administrator';
    if (role === 'teamer') return 'Teamer';
    if (role === 'pastor') return 'Pastor';
    return `Konfirmand ${konfiRole}`;
  };

  const getRolePermissions = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Vollzugriff auf alle Funktionen';
      case 'teamer':
        return 'Fragen, Termine, Pässe verwalten (ohne Benutzerverwaltung)';
      case 'pastor':
        return 'Erweiterte Berechtigungen + Seelsorge';
      case 'konfi':
        return 'Quiz teilnehmen, eigenen Pass einsehen';
      default:
        return '';
    }
  };

  const handleRoleChange = (newRole: 'admin' | 'konfi' | 'teamer' | 'pastor') => {
    setFormData(prev => ({
      ...prev,
      role: newRole,
      password: newRole === 'konfi' && !editingId && !prev.password 
        ? generateSecurePassword() 
        : prev.password,
      isAvailableForEmergency: newRole === 'teamer' || newRole === 'pastor' ? false : prev.isAvailableForEmergency
    }));
  };

  const getInitials = (firstName?: string, lastName?: string, username?: string) => {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`.toUpperCase();
    }
    if (username) {
      const parts = username.split('.');
      if (parts.length >= 2) {
        return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
      }
      return username.slice(0, 2).toUpperCase();
    }
    return 'KU';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Benutzer verwalten</h2>
          <p className="text-gray-600 text-sm mt-1">
            Verwalten Sie Administratoren, Teamer, Pastoren und Konfirmanden
          </p>
        </div>
        <Button 
          onClick={() => setShowAddForm(true)} 
          className="gap-2"
          disabled={showAddForm || editingId}
        >
          <Plus className="w-4 h-4" />
          Neuer Benutzer
        </Button>
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          {notification.type === 'error' ? (
            <AlertCircle className="h-4 w-4" />
          ) : (
            <CheckCircle className="h-4 w-4" />
          )}
          <AlertDescription className="whitespace-pre-line">
            {notification.message}
          </AlertDescription>
        </Alert>
      )}

      {/* Notfall-Chat Übersicht */}
      <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-800">
            <Shield className="w-5 h-5" />
            Notfall-Chat Berechtigungen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h4 className="font-semibold mb-2">Verfügbare Teamer ({users.filter(u => u.role === 'teamer' && u.isAvailableForEmergency).length})</h4>
              <div className="space-y-2">
                {users.filter(u => u.role === 'teamer').map(user => (
                  <div key={user.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{user.firstName} {user.lastName}</span>
                      {!user.isAvailableForEmergency && (
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Plane className="w-3 h-3" />
                          <span>Abwesend</span>
                        </div>
                      )}
                    </div>
                    <Switch
                      checked={user.isAvailableForEmergency || false}
                      onCheckedChange={() => toggleEmergencyAvailability(user.id)}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Verfügbare Pastoren ({users.filter(u => u.role === 'pastor' && u.isAvailableForEmergency).length})</h4>
              <div className="space-y-2">
                {users.filter(u => u.role === 'pastor').map(user => (
                  <div key={user.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{user.firstName} {user.lastName}</span>
                      {!user.isAvailableForEmergency && (
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Plane className="w-3 h-3" />
                          <span>Abwesend</span>
                        </div>
                      )}
                    </div>
                    <Switch
                      checked={user.isAvailableForEmergency || false}
                      onCheckedChange={() => toggleEmergencyAvailability(user.id)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form */}
      {(showAddForm || editingId) && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>
              {editingId ? 'Benutzer bearbeiten' : 'Neuen Benutzer hinzufügen'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="firstName">Vorname</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  placeholder="Vorname"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Nachname</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  placeholder="Nachname"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="username">Benutzername *</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="z.B. max.mustermann"
                required
              />
            </div>

            <div>
              <Label htmlFor="role">Rolle *</Label>
              <Select
                value={formData.role}
                onValueChange={handleRoleChange}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="konfi">
                    <div className="flex flex-col items-start">
                      <span>Konfirmand</span>
                      <span className="text-xs text-gray-500">Quiz teilnehmen, Pass einsehen</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="teamer">
                    <div className="flex flex-col items-start">
                      <span>Teamer</span>
                      <span className="text-xs text-gray-500">Fragen und Termine verwalten</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="pastor">
                    <div className="flex flex-col items-start">
                      <span>Pastor</span>
                      <span className="text-xs text-gray-500">Erweiterte Berechtigungen + Seelsorge</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div className="flex flex-col items-start">
                      <span>Administrator</span>
                      <span className="text-xs text-gray-500">Vollzugriff auf alle Funktionen</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.role === 'konfi' && (
              <div>
                <Label htmlFor="konfiRole">Konfirmanden-Rolle *</Label>
                <Select
                  value={formData.konfiRole}
                  onValueChange={(value: 'KU4' | 'KUZ' | 'KU8') => setFormData({ ...formData, konfiRole: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="KU4">KU4 - 4. Klasse (Grundlagen)</SelectItem>
                    <SelectItem value="KUZ">KUZ - Zwischenjahr (Vertiefung)</SelectItem>
                    <SelectItem value="KU8">KU8 - 8. Klasse (Fortgeschritten)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {(formData.role === 'teamer' || formData.role === 'pastor') && (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Für Notfall-Chats verfügbar</Label>
                    <p className="text-sm text-gray-600">
                      Kann vertrauliche Gespräche mit Konfirmanden führen
                    </p>
                  </div>
                  <Switch
                    checked={formData.isAvailableForEmergency}
                    onCheckedChange={(checked) => setFormData({ ...formData, isAvailableForEmergency: checked })}
                  />
                </div>

                <div>
                  <Label htmlFor="specializations">Spezialisierungen (optional)</Label>
                  <Input
                    id="specializations"
                    value={formData.specializations}
                    onChange={(e) => setFormData({ ...formData, specializations: e.target.value })}
                    placeholder="z.B. Seelsorge, Krisenintervention, Jugendarbeit (durch Komma getrennt)"
                  />
                </div>
              </>
            )}

            <div>
              <Label htmlFor="password">Passwort *</Label>
              <div className="flex gap-2">
                <Input
                  id="password"
                  type="text"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Passwort eingeben oder generieren"
                  required
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={generateNewPassword}
                  className="gap-2 whitespace-nowrap"
                >
                  <Key className="w-4 h-4" />
                  Generieren
                </Button>
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={editingId ? handleSave : handleAdd} className="gap-2">
                <Save className="w-4 h-4" />
                {editingId ? 'Speichern' : 'Hinzufügen'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                  resetForm();
                }}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Users List */}
      <div className="space-y-4">
        {users.map((user) => (
          <Card key={user.id} className="transition-all hover:shadow-md">
            <CardContent className="p-6">
              <div className="flex justify-between items-start gap-4">
                <div className="flex items-center gap-4">
                  {/* Graues Standard-Profilbild */}
                  <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center text-white font-semibold border-2 border-white shadow">
                    {getInitials(user.firstName, user.lastName, user.username)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg">
                        {user.firstName && user.lastName 
                          ? `${user.firstName} ${user.lastName}` 
                          : user.username
                        }
                      </h3>
                      <Badge variant={getRoleBadgeColor(user.role, user.konfiRole)}>
                        {getRoleLabel(user.role, user.konfiRole)}
                      </Badge>
                      {(user.role === 'teamer' || user.role === 'pastor') && (
                        <Badge variant={user.isAvailableForEmergency ? "default" : "secondary"} className="gap-1">
                          <Shield className="w-3 h-3" />
                          {user.isAvailableForEmergency ? 'Notfall verfügbar' : 'Nicht verfügbar'}
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2">@{user.username}</p>
                    
                    <div className="flex items-center gap-2 mb-2">
                      <Label className="text-sm font-medium">Passwort:</Label>
                      <div className="flex items-center gap-2">
                        <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">
                          {showPasswords[user.id] ? user.password : '••••••••'}
                        </code>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => togglePasswordVisibility(user.id)}
                          className="h-6 w-6 p-0"
                        >
                          {showPasswords[user.id] ? (
                            <EyeOff className="w-3 h-3" />
                          ) : (
                            <Eye className="w-3 h-3" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyPassword(user.password)}
                          className="h-6 w-6 p-0"
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>

                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Berechtigungen:</strong> {getRolePermissions(user.role)}
                    </p>

                    {user.specializations && user.specializations.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {user.specializations.map((spec, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  {(user.role === 'teamer' || user.role === 'pastor') && (
                    <Button
                      size="sm"
                      variant={user.isAvailableForEmergency ? "default" : "outline"}
                      onClick={() => toggleEmergencyAvailability(user.id)}
                      className="gap-1"
                    >
                      <UserCheck className="w-3 h-3" />
                      {user.isAvailableForEmergency ? 'Verfügbar' : 'Aktivieren'}
                    </Button>
                  )}
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleEdit(user)}
                    disabled={editingId === user.id || showAddForm}
                    className="gap-1"
                  >
                    <Edit className="w-3 h-3" />
                    Bearbeiten
                  </Button>
                  <Button 
                    size="sm" 
                    variant="destructive"
                    onClick={() => handleDelete(user.id)}
                    disabled={editingId === user.id || showAddForm}
                    className="gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    Löschen
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {users.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Noch keine Benutzer vorhanden.</p>
            <p className="text-sm text-gray-500">Fügen Sie den ersten Benutzer hinzu, um zu beginnen.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}