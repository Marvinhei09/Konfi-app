import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Plus, Trash2, ChevronLeft, ChevronRight, CheckSquare, Square } from 'lucide-react';
import type { CalendarEvent } from '@/types';

interface CalendarManagerProps {
  events: CalendarEvent[];
  onEventsChange: (events: CalendarEvent[]) => void;
}

export function CalendarManager({ events, onEventsChange }: CalendarManagerProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [eventTitle, setEventTitle] = useState('');
  const [eventDescription, setEventDescription] = useState('');
  const [allowedRoles, setAllowedRoles] = useState<('KU4' | 'KUZ' | 'KU8' | 'teamer')[]>(['KU4', 'KUZ', 'KU8']);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [activeTab, setActiveTab] = useState('add');

  const handleAddEvent = () => {
    if (!eventTitle.trim()) return;

    const newEvent: CalendarEvent = {
      id: Date.now().toString(),
      date: selectedDate,
      title: eventTitle,
      description: eventDescription || undefined,
      allowedRoles: allowedRoles.length === 4 ? undefined : allowedRoles // If all roles selected, don't restrict
    };

    onEventsChange([...events, newEvent]);
    setEventTitle('');
    setEventDescription('');
    setAllowedRoles(['KU4', 'KUZ', 'KU8']);
  };

  const handleDeleteEvent = (id: string) => {
    onEventsChange(events.filter(e => e.id !== id));
  };

  const handleRoleChange = (role: 'KU4' | 'KUZ' | 'KU8' | 'teamer', checked: boolean) => {
    if (checked) {
      setAllowedRoles([...allowedRoles, role]);
    } else {
      setAllowedRoles(allowedRoles.filter(r => r !== role));
    }
  };

  const toggleAllRoles = () => {
    const allRoles: ('KU4' | 'KUZ' | 'KU8' | 'teamer')[] = ['KU4', 'KUZ', 'KU8', 'teamer'];
    const hasAllRoles = allRoles.every(role => allowedRoles.includes(role));
    
    if (hasAllRoles) {
      setAllowedRoles([]);
    } else {
      setAllowedRoles(allRoles);
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      case 'teamer': return 'default';
      default: return 'secondary';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'KU4': return 'KU4';
      case 'KUZ': return 'KUZ';
      case 'KU8': return 'KU8';
      case 'teamer': return 'Teamer';
      default: return role;
    }
  };

  // Calendar helper functions
  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return firstDay === 0 ? 6 : firstDay - 1; // Convert Sunday (0) to be last day (6)
  };

  const getMonthEvents = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate.getFullYear() === year && eventDate.getMonth() === month;
    });
  };

  const getEventsForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return events.filter(event => event.date === dateString);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(newDate.getMonth() - 1);
      } else {
        newDate.setMonth(newDate.getMonth() + 1);
      }
      return newDate;
    });
  };

  const goToToday = () => {
    setCurrentMonth(new Date());
  };

  const selectedDateEvents = events.filter(e => e.date === selectedDate);
  const sortedEvents = [...events].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const monthEvents = getMonthEvents(currentMonth);
  const allRoles: ('KU4' | 'KUZ' | 'KU8' | 'teamer')[] = ['KU4', 'KUZ', 'KU8', 'teamer'];
  const hasAllRoles = allRoles.every(role => allowedRoles.includes(role));

  // Generate calendar grid
  const daysInMonth = getDaysInMonth(currentMonth);
  const firstDay = getFirstDayOfMonth(currentMonth);
  const calendarDays = [];

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < firstDay; i++) {
    calendarDays.push(null);
  }

  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    calendarDays.push(day);
  }

  const monthNames = [
    'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni',
    'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'
  ];

  const dayNames = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="add">Termin hinzufügen</TabsTrigger>
          <TabsTrigger value="month">Monatsansicht</TabsTrigger>
          <TabsTrigger value="list">Terminliste</TabsTrigger>
        </TabsList>

        <TabsContent value="add" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Neuen Termin hinzufügen
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="date">Datum</Label>
                  <Input
                    id="date"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="title">Titel</Label>
                  <Input
                    id="title"
                    value={eventTitle}
                    onChange={(e) => setEventTitle(e.target.value)}
                    placeholder="Titel des Termins"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Beschreibung (optional)</Label>
                  <Textarea
                    id="description"
                    value={eventDescription}
                    onChange={(e) => setEventDescription(e.target.value)}
                    placeholder="Zusätzliche Informationen..."
                    rows={3}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Sichtbar für Rollen</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={toggleAllRoles}
                      className="gap-2 text-xs"
                    >
                      {hasAllRoles ? (
                        <>
                          <CheckSquare className="w-3 h-3" />
                          Alle abwählen
                        </>
                      ) : (
                        <>
                          <Square className="w-3 h-3" />
                          Alle auswählen
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {allRoles.map((role) => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox
                          id={`role-${role}`}
                          checked={allowedRoles.includes(role)}
                          onCheckedChange={(checked) => handleRoleChange(role, checked as boolean)}
                        />
                        <Label htmlFor={`role-${role}`} className="text-sm">
                          <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                            {getRoleLabel(role)}
                          </Badge>
                        </Label>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Wählen Sie die Rollen aus, die diesen Termin sehen sollen. 
                    Wenn alle Rollen ausgewählt sind, ist der Termin für alle sichtbar.
                  </p>
                </div>

                <Button onClick={handleAddEvent} className="w-full gap-2" disabled={allowedRoles.length === 0}>
                  <Plus className="w-4 h-4" />
                  Termin hinzufügen
                </Button>

                {selectedDateEvents.length > 0 && (
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold mb-2">
                      Termine am {new Date(selectedDate).toLocaleDateString('de-DE')}:
                    </h4>
                    <div className="space-y-2">
                      {selectedDateEvents.map((event) => (
                        <div key={event.id} className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{event.title}</p>
                            {event.description && (
                              <p className="text-sm text-gray-600">{event.description}</p>
                            )}
                            {event.allowedRoles && (
                              <div className="flex gap-1 mt-1">
                                {event.allowedRoles.map(role => (
                                  <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                                    {getRoleLabel(role)}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleDeleteEvent(event.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Rollenübersicht</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-3">
                    <div className="p-3 bg-blue-50 rounded-lg border">
                      <Badge variant="secondary" className="mb-2">KU4</Badge>
                      <p className="text-sm text-gray-700">Konfirmationsunterricht 4. Klasse</p>
                      <p className="text-xs text-gray-500">Grundlagen des christlichen Glaubens</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg border">
                      <Badge variant="outline" className="mb-2">KUZ</Badge>
                      <p className="text-sm text-gray-700">Konfirmationsunterricht Zwischenjahr</p>
                      <p className="text-xs text-gray-500">Vertiefung und Reflexion</p>
                    </div>
                    <div className="p-3 bg-red-50 rounded-lg border">
                      <Badge variant="destructive" className="mb-2">KU8</Badge>
                      <p className="text-sm text-gray-700">Konfirmationsunterricht 8. Klasse</p>
                      <p className="text-xs text-gray-500">Vorbereitung zur Konfirmation</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg border">
                      <Badge variant="default" className="mb-2">Teamer</Badge>
                      <p className="text-sm text-gray-700">Jugendliche Mitarbeiter</p>
                      <p className="text-xs text-gray-500">Unterstützung und Begleitung</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="month" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigateMonth('prev')}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToToday}
                  >
                    Heute
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigateMonth('next')}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {dayNames.map(day => (
                  <div key={day} className="p-2 text-center font-semibold text-gray-600 text-sm">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-1">
                {calendarDays.map((day, index) => {
                  if (day === null) {
                    return <div key={index} className="p-2 h-24"></div>;
                  }
                  
                  const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                  const dayEvents = getEventsForDate(date);
                  const isToday = date.toDateString() === new Date().toDateString();
                  const isSelected = date.toISOString().split('T')[0] === selectedDate;
                  
                  return (
                    <div
                      key={day}
                      className={`p-2 h-24 border rounded cursor-pointer transition-colors ${
                        isToday ? 'bg-blue-100 border-blue-300' : 
                        isSelected ? 'bg-blue-50 border-blue-200' : 
                        'border-gray-200 hover:bg-gray-50'
                      }`}
                      onClick={() => {
                        setSelectedDate(date.toISOString().split('T')[0]);
                        setActiveTab('add');
                      }}
                    >
                      <div className={`text-sm font-medium ${isToday ? 'text-blue-700' : 'text-gray-900'}`}>
                        {day}
                      </div>
                      <div className="mt-1 space-y-1">
                        {dayEvents.slice(0, 2).map((event) => (
                          <div
                            key={event.id}
                            className="text-xs p-1 bg-blue-500 text-white rounded truncate"
                            title={event.title}
                          >
                            {event.title}
                          </div>
                        ))}
                        {dayEvents.length > 2 && (
                          <div className="text-xs text-gray-500">
                            +{dayEvents.length - 2} weitere
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold mb-2">
                  Termine im {monthNames[currentMonth.getMonth()]} ({monthEvents.length})
                </h4>
                {monthEvents.length === 0 ? (
                  <p className="text-gray-500 text-sm">Keine Termine in diesem Monat</p>
                ) : (
                  <div className="grid gap-2 md:grid-cols-2">
                    {monthEvents.slice(0, 6).map((event) => (
                      <div key={event.id} className="text-sm p-2 bg-white rounded border">
                        <div className="font-medium">{event.title}</div>
                        <div className="text-gray-600">
                          {new Date(event.date).toLocaleDateString('de-DE')}
                        </div>
                        {event.allowedRoles && (
                          <div className="flex gap-1 mt-1">
                            {event.allowedRoles.slice(0, 3).map(role => (
                              <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                                {getRoleLabel(role)}
                              </Badge>
                            ))}
                            {event.allowedRoles.length > 3 && (
                              <span className="text-xs text-gray-500">+{event.allowedRoles.length - 3}</span>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                    {monthEvents.length > 6 && (
                      <div className="text-sm text-gray-500 p-2">
                        ... und {monthEvents.length - 6} weitere Termine
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alle Termine</CardTitle>
            </CardHeader>
            <CardContent>
              {sortedEvents.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Noch keine Termine vorhanden</p>
                  <p className="text-sm">Fügen Sie den ersten Termin hinzu</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {sortedEvents.map((event) => (
                    <Card key={event.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-blue-600">
                                {new Date(event.date).toLocaleDateString('de-DE', {
                                  weekday: 'long',
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}
                              </span>
                            </div>
                            <h4 className="font-semibold">{event.title}</h4>
                            {event.description && (
                              <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                            )}
                            {event.allowedRoles && (
                              <div className="flex gap-1 mt-2 flex-wrap">
                                {event.allowedRoles.map(role => (
                                  <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                                    {getRoleLabel(role)}
                                  </Badge>
                                ))}
                              </div>
                            )}
                            {!event.allowedRoles && (
                              <Badge variant="outline" className="text-xs mt-2">
                                Alle Rollen
                              </Badge>
                            )}
                          </div>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleDeleteEvent(event.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}