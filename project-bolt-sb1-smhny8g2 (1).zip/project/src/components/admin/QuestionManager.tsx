import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, Edit, Trash2, Save, X, BookOpen, Camera, Upload, 
  CheckSquare, Square, Check, X as XIcon, ListOrdered, CheckCircle
} from 'lucide-react';
import type { Question } from '@/types';

interface QuestionManagerProps {
  questions: Question[];
  onQuestionsChange: (questions: Question[]) => void;
}

export function QuestionManager({ questions, onQuestionsChange }: QuestionManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'multiple-choice' | 'true-false' | 'sequence'>('multiple-choice');
  
  // Form state für Multiple-Choice
  const [mcFormData, setMcFormData] = useState({
    question: '',
    options: ['', '', '', ''],
    answer: '',
    topic: '',
    allowedRoles: ['KU4', 'KUZ', 'KU8'] as ('KU4' | 'KUZ' | 'KU8')[]
  });

  // Form state für Wahr/Falsch
  const [tfFormData, setTfFormData] = useState({
    question: 'Wahr oder Falsch: ',
    topic: '',
    allowedRoles: ['KU4', 'KUZ', 'KU8'] as ('KU4' | 'KUZ' | 'KU8')[],
    statements: [
      { text: '', isTrue: true },
      { text: '', isTrue: false },
      { text: '', isTrue: true },
      { text: '', isTrue: false },
      { text: '', isTrue: true }
    ]
  });

  // Form state für Sequenz
  const [seqFormData, setSeqFormData] = useState({
    question: 'Bringe die folgenden Elemente in die richtige Reihenfolge:',
    topic: '',
    allowedRoles: ['KU4', 'KUZ', 'KU8'] as ('KU4' | 'KUZ' | 'KU8')[],
    sequence: ['', '', '', '', '']
  });

  const handleAddMultipleChoice = () => {
    if (!mcFormData.question || !mcFormData.answer || !mcFormData.topic || 
        mcFormData.options.some(opt => !opt.trim()) || mcFormData.allowedRoles.length === 0) return;

    const newQuestion: Question = {
      id: Date.now().toString(),
      question: mcFormData.question,
      options: mcFormData.options,
      answer: mcFormData.answer,
      topic: mcFormData.topic,
      allowedRoles: mcFormData.allowedRoles,
      type: 'multiple-choice'
    };

    onQuestionsChange([...questions, newQuestion]);
    resetForms();
    setShowAddForm(false);
  };

  const handleAddTrueFalse = () => {
    if (!tfFormData.topic || tfFormData.allowedRoles.length === 0 || 
        tfFormData.statements.some(s => !s.text.trim())) return;

    const newQuestion: Question = {
      id: Date.now().toString(),
      question: tfFormData.question,
      options: [], // Nicht verwendet für diesen Typ
      answer: '', // Nicht verwendet für diesen Typ
      topic: tfFormData.topic,
      allowedRoles: tfFormData.allowedRoles,
      type: 'true-false',
      statements: tfFormData.statements
    };

    onQuestionsChange([...questions, newQuestion]);
    resetForms();
    setShowAddForm(false);
  };

  const handleAddSequence = () => {
    if (!seqFormData.topic || seqFormData.allowedRoles.length === 0 || 
        seqFormData.sequence.some(s => !s.trim())) return;

    const newQuestion: Question = {
      id: Date.now().toString(),
      question: seqFormData.question,
      options: [], // Nicht verwendet für diesen Typ
      answer: '', // Nicht verwendet für diesen Typ
      topic: seqFormData.topic,
      allowedRoles: seqFormData.allowedRoles,
      type: 'sequence',
      sequence: seqFormData.sequence.filter(s => s.trim())
    };

    onQuestionsChange([...questions, newQuestion]);
    resetForms();
    setShowAddForm(false);
  };

  const handleEdit = (question: Question) => {
    setEditingId(question.id);
    
    if (question.type === 'true-false') {
      setTfFormData({
        question: question.question,
        topic: question.topic,
        allowedRoles: question.allowedRoles || ['KU4', 'KUZ', 'KU8'],
        statements: question.statements || []
      });
      setActiveTab('true-false');
    } else if (question.type === 'sequence') {
      setSeqFormData({
        question: question.question,
        topic: question.topic,
        allowedRoles: question.allowedRoles || ['KU4', 'KUZ', 'KU8'],
        sequence: question.sequence || []
      });
      setActiveTab('sequence');
    } else {
      // Standard Multiple-Choice
      setMcFormData({
        question: question.question,
        options: [...question.options],
        answer: question.answer,
        topic: question.topic,
        allowedRoles: question.allowedRoles || ['KU4', 'KUZ', 'KU8']
      });
      setActiveTab('multiple-choice');
    }
  };

  const handleSave = () => {
    if (!editingId) return;

    let updatedQuestion: Question;
    
    if (activeTab === 'true-false') {
      updatedQuestion = {
        id: editingId,
        question: tfFormData.question,
        options: [],
        answer: '',
        topic: tfFormData.topic,
        allowedRoles: tfFormData.allowedRoles,
        type: 'true-false',
        statements: tfFormData.statements
      };
    } else if (activeTab === 'sequence') {
      updatedQuestion = {
        id: editingId,
        question: seqFormData.question,
        options: [],
        answer: '',
        topic: seqFormData.topic,
        allowedRoles: seqFormData.allowedRoles,
        type: 'sequence',
        sequence: seqFormData.sequence.filter(s => s.trim())
      };
    } else {
      updatedQuestion = {
        id: editingId,
        question: mcFormData.question,
        options: mcFormData.options,
        answer: mcFormData.answer,
        topic: mcFormData.topic,
        allowedRoles: mcFormData.allowedRoles,
        type: 'multiple-choice'
      };
    }

    const updatedQuestions = questions.map(q => 
      q.id === editingId ? updatedQuestion : q
    );

    onQuestionsChange(updatedQuestions);
    setEditingId(null);
    resetForms();
  };

  const handleDelete = (id: string) => {
    onQuestionsChange(questions.filter(q => q.id !== id));
  };

  const resetForms = () => {
    setMcFormData({
      question: '',
      options: ['', '', '', ''],
      answer: '',
      topic: '',
      allowedRoles: ['KU4', 'KUZ', 'KU8']
    });
    
    setTfFormData({
      question: 'Wahr oder Falsch: ',
      topic: '',
      allowedRoles: ['KU4', 'KUZ', 'KU8'],
      statements: [
        { text: '', isTrue: true },
        { text: '', isTrue: false },
        { text: '', isTrue: true },
        { text: '', isTrue: false },
        { text: '', isTrue: true }
      ]
    });
    
    setSeqFormData({
      question: 'Bringe die folgenden Elemente in die richtige Reihenfolge:',
      topic: '',
      allowedRoles: ['KU4', 'KUZ', 'KU8'],
      sequence: ['', '', '', '', '']
    });
  };

  const updateMcOption = (index: number, value: string) => {
    const newOptions = [...mcFormData.options];
    newOptions[index] = value;
    setMcFormData({ ...mcFormData, options: newOptions });
  };

  const updateTfStatement = (index: number, text: string, isTrue?: boolean) => {
    const newStatements = [...tfFormData.statements];
    newStatements[index] = { 
      text: text, 
      isTrue: isTrue !== undefined ? isTrue : newStatements[index].isTrue 
    };
    setTfFormData({ ...tfFormData, statements: newStatements });
  };

  const updateSeqItem = (index: number, value: string) => {
    const newSequence = [...seqFormData.sequence];
    newSequence[index] = value;
    setSeqFormData({ ...seqFormData, sequence: newSequence });
  };

  const addTfStatement = () => {
    setTfFormData({
      ...tfFormData,
      statements: [...tfFormData.statements, { text: '', isTrue: true }]
    });
  };

  const removeTfStatement = (index: number) => {
    if (tfFormData.statements.length <= 1) return;
    const newStatements = [...tfFormData.statements];
    newStatements.splice(index, 1);
    setTfFormData({ ...tfFormData, statements: newStatements });
  };

  const addSeqItem = () => {
    setSeqFormData({
      ...seqFormData,
      sequence: [...seqFormData.sequence, '']
    });
  };

  const removeSeqItem = (index: number) => {
    if (seqFormData.sequence.length <= 1) return;
    const newSequence = [...seqFormData.sequence];
    newSequence.splice(index, 1);
    setSeqFormData({ ...seqFormData, sequence: newSequence });
  };

  const handleRoleChange = (role: 'KU4' | 'KUZ' | 'KU8', checked: boolean, formType: 'mc' | 'tf' | 'seq') => {
    if (formType === 'mc') {
      if (checked) {
        setMcFormData({
          ...mcFormData,
          allowedRoles: [...mcFormData.allowedRoles, role]
        });
      } else {
        setMcFormData({
          ...mcFormData,
          allowedRoles: mcFormData.allowedRoles.filter(r => r !== role)
        });
      }
    } else if (formType === 'tf') {
      if (checked) {
        setTfFormData({
          ...tfFormData,
          allowedRoles: [...tfFormData.allowedRoles, role]
        });
      } else {
        setTfFormData({
          ...tfFormData,
          allowedRoles: tfFormData.allowedRoles.filter(r => r !== role)
        });
      }
    } else {
      if (checked) {
        setSeqFormData({
          ...seqFormData,
          allowedRoles: [...seqFormData.allowedRoles, role]
        });
      } else {
        setSeqFormData({
          ...seqFormData,
          allowedRoles: seqFormData.allowedRoles.filter(r => r !== role)
        });
      }
    }
  };

  const toggleAllRoles = (formType: 'mc' | 'tf' | 'seq') => {
    const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
    
    if (formType === 'mc') {
      const hasAllRoles = allRoles.every(role => mcFormData.allowedRoles.includes(role));
      setMcFormData({ ...mcFormData, allowedRoles: hasAllRoles ? [] : allRoles });
    } else if (formType === 'tf') {
      const hasAllRoles = allRoles.every(role => tfFormData.allowedRoles.includes(role));
      setTfFormData({ ...tfFormData, allowedRoles: hasAllRoles ? [] : allRoles });
    } else {
      const hasAllRoles = allRoles.every(role => seqFormData.allowedRoles.includes(role));
      setSeqFormData({ ...seqFormData, allowedRoles: hasAllRoles ? [] : allRoles });
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  const getQuestionTypeIcon = (type?: string) => {
    switch (type) {
      case 'true-false': return <Check className="w-4 h-4" />;
      case 'sequence': return <ListOrdered className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  const getQuestionTypeLabel = (type?: string) => {
    switch (type) {
      case 'true-false': return 'Wahr/Falsch';
      case 'sequence': return 'Sequenz';
      default: return 'Multiple-Choice';
    }
  };

  const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
  const mcHasAllRoles = allRoles.every(role => mcFormData.allowedRoles.includes(role));
  const tfHasAllRoles = allRoles.every(role => tfFormData.allowedRoles.includes(role));
  const seqHasAllRoles = allRoles.every(role => seqFormData.allowedRoles.includes(role));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Fragen verwalten</h2>
          <p className="text-gray-600 text-sm mt-1">
            Verwalten Sie verschiedene Fragetypen mit rollenbasierten Berechtigungen
          </p>
        </div>
        <Button 
          onClick={() => setShowAddForm(true)} 
          className="gap-2"
          disabled={showAddForm || editingId}
        >
          <Plus className="w-4 h-4" />
          Neue Frage
        </Button>
      </div>

      {/* Role explanation */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2">Fragetypen und Berechtigungen:</h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span className="font-medium">Multiple-Choice</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span className="font-medium">Wahr/Falsch</span>
              </div>
              <div className="flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-purple-600" />
                <span className="font-medium">Sequenz/Reihenfolge</span>
              </div>
            </div>
            <div className="grid gap-2 text-sm">
              <div>
                <Badge variant="secondary" className="mr-2">KU4</Badge>
                <span>4. Klasse - Grundlagen</span>
              </div>
              <div>
                <Badge variant="outline" className="mr-2">KUZ</Badge>
                <span>Zwischenjahr - Vertiefung</span>
              </div>
              <div>
                <Badge variant="destructive" className="mr-2">KU8</Badge>
                <span>8. Klasse - Fortgeschritten</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form */}
      {(showAddForm || editingId) && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>
              {editingId ? 'Frage bearbeiten' : 'Neue Frage hinzufügen'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="multiple-choice" className="gap-2">
                  <BookOpen className="w-4 h-4" />
                  Multiple-Choice
                </TabsTrigger>
                <TabsTrigger value="true-false" className="gap-2">
                  <Check className="w-4 h-4" />
                  Wahr/Falsch
                </TabsTrigger>
                <TabsTrigger value="sequence" className="gap-2">
                  <ListOrdered className="w-4 h-4" />
                  Sequenz
                </TabsTrigger>
              </TabsList>

              {/* Multiple-Choice Form */}
              <TabsContent value="multiple-choice" className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="mcTopic">Thema</Label>
                  <Input
                    id="mcTopic"
                    value={mcFormData.topic}
                    onChange={(e) => setMcFormData({ ...mcFormData, topic: e.target.value })}
                    placeholder="z.B. Grundwissen, Bibel, Gebote..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="mcQuestion">Frage</Label>
                  <Textarea
                    id="mcQuestion"
                    value={mcFormData.question}
                    onChange={(e) => setMcFormData({ ...mcFormData, question: e.target.value })}
                    placeholder="Geben Sie die Frage ein..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label>Antwortmöglichkeiten</Label>
                  <div className="grid gap-2 mt-2">
                    {mcFormData.options.map((option, index) => (
                      <Input
                        key={index}
                        value={option}
                        onChange={(e) => updateMcOption(index, e.target.value)}
                        placeholder={`Antwort ${index + 1}`}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="mcAnswer">Richtige Antwort</Label>
                  <Input
                    id="mcAnswer"
                    value={mcFormData.answer}
                    onChange={(e) => setMcFormData({ ...mcFormData, answer: e.target.value })}
                    placeholder="Die korrekte Antwort (muss exakt einer Antwortmöglichkeit entsprechen)"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Sichtbar für Rollen</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => toggleAllRoles('mc')}
                      className="gap-2 text-xs"
                    >
                      {mcHasAllRoles ? (
                        <>
                          <CheckSquare className="w-3 h-3" />
                          Alle abwählen
                        </>
                      ) : (
                        <>
                          <Square className="w-3 h-3" />
                          Alle auswählen
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="flex gap-4 mt-2">
                    {allRoles.map((role) => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox
                          id={`mc-${role}`}
                          checked={mcFormData.allowedRoles.includes(role)}
                          onCheckedChange={(checked) => handleRoleChange(role, checked as boolean, 'mc')}
                        />
                        <Label htmlFor={`mc-${role}`} className="text-sm">
                          <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                            {role}
                          </Badge>
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Wahr/Falsch Form */}
              <TabsContent value="true-false" className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="tfTopic">Thema</Label>
                  <Input
                    id="tfTopic"
                    value={tfFormData.topic}
                    onChange={(e) => setTfFormData({ ...tfFormData, topic: e.target.value })}
                    placeholder="z.B. Grundwissen, Bibel, Gebote..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="tfQuestion">Frage/Titel</Label>
                  <Input
                    id="tfQuestion"
                    value={tfFormData.question}
                    onChange={(e) => setTfFormData({ ...tfFormData, question: e.target.value })}
                    placeholder="z.B. Wahr oder Falsch: Aussagen zur Bibel"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Aussagen</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addTfStatement}
                      className="gap-2 text-xs"
                    >
                      <Plus className="w-3 h-3" />
                      Aussage hinzufügen
                    </Button>
                  </div>
                  <div className="space-y-2 mt-2">
                    {tfFormData.statements.map((statement, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Select
                          value={statement.isTrue ? "true" : "false"}
                          onValueChange={(value) => updateTfStatement(index, statement.text, value === "true")}
                        >
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="true">Wahr</SelectItem>
                            <SelectItem value="false">Falsch</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <Input
                          value={statement.text}
                          onChange={(e) => updateTfStatement(index, e.target.value)}
                          placeholder="Aussage eingeben..."
                          className="flex-1"
                        />
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeTfStatement(index)}
                          disabled={tfFormData.statements.length <= 1}
                          className="h-8 w-8 p-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Sichtbar für Rollen</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => toggleAllRoles('tf')}
                      className="gap-2 text-xs"
                    >
                      {tfHasAllRoles ? (
                        <>
                          <CheckSquare className="w-3 h-3" />
                          Alle abwählen
                        </>
                      ) : (
                        <>
                          <Square className="w-3 h-3" />
                          Alle auswählen
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="flex gap-4 mt-2">
                    {allRoles.map((role) => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox
                          id={`tf-${role}`}
                          checked={tfFormData.allowedRoles.includes(role)}
                          onCheckedChange={(checked) => handleRoleChange(role, checked as boolean, 'tf')}
                        />
                        <Label htmlFor={`tf-${role}`} className="text-sm">
                          <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                            {role}
                          </Badge>
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Sequenz Form */}
              <TabsContent value="sequence" className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="seqTopic">Thema</Label>
                  <Input
                    id="seqTopic"
                    value={seqFormData.topic}
                    onChange={(e) => setSeqFormData({ ...seqFormData, topic: e.target.value })}
                    placeholder="z.B. Grundwissen, Bibel, Gebote..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="seqQuestion">Frage/Anweisung</Label>
                  <Textarea
                    id="seqQuestion"
                    value={seqFormData.question}
                    onChange={(e) => setSeqFormData({ ...seqFormData, question: e.target.value })}
                    placeholder="z.B. Bringe die folgenden Ereignisse in die richtige Reihenfolge:"
                    rows={2}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Elemente (in korrekter Reihenfolge)</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addSeqItem}
                      className="gap-2 text-xs"
                    >
                      <Plus className="w-3 h-3" />
                      Element hinzufügen
                    </Button>
                  </div>
                  <div className="space-y-2 mt-2">
                    {seqFormData.sequence.map((item, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-800">
                          {index + 1}
                        </div>
                        
                        <Input
                          value={item}
                          onChange={(e) => updateSeqItem(index, e.target.value)}
                          placeholder={`Element ${index + 1}`}
                          className="flex-1"
                        />
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeSeqItem(index)}
                          disabled={seqFormData.sequence.length <= 1}
                          className="h-8 w-8 p-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Sichtbar für Rollen</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => toggleAllRoles('seq')}
                      className="gap-2 text-xs"
                    >
                      {seqHasAllRoles ? (
                        <>
                          <CheckSquare className="w-3 h-3" />
                          Alle abwählen
                        </>
                      ) : (
                        <>
                          <Square className="w-3 h-3" />
                          Alle auswählen
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="flex gap-4 mt-2">
                    {allRoles.map((role) => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox
                          id={`seq-${role}`}
                          checked={seqFormData.allowedRoles.includes(role)}
                          onCheckedChange={(checked) => handleRoleChange(role, checked as boolean, 'seq')}
                        />
                        <Label htmlFor={`seq-${role}`} className="text-sm">
                          <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                            {role}
                          </Badge>
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex gap-2 pt-4">
              <Button 
                onClick={
                  editingId ? handleSave : 
                  activeTab === 'multiple-choice' ? handleAddMultipleChoice :
                  activeTab === 'true-false' ? handleAddTrueFalse :
                  handleAddSequence
                } 
                className="gap-2"
              >
                <Save className="w-4 h-4" />
                {editingId ? 'Speichern' : 'Hinzufügen'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                  resetForms();
                }}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Questions List */}
      <div className="space-y-4">
        {questions.map((question) => (
          <Card key={question.id} className="transition-all hover:shadow-md">
            <CardContent className="p-6">
              <div className="flex justify-between items-start gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{question.topic}</Badge>
                    <Badge variant="outline" className="gap-1">
                      {getQuestionTypeIcon(question.type)}
                      {getQuestionTypeLabel(question.type)}
                    </Badge>
                    <div className="flex gap-1">
                      {question.allowedRoles?.map(role => (
                        <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                          {role}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <h3 className="font-semibold text-lg mb-3">{question.question}</h3>
                  
                  {/* Multiple-Choice Anzeige */}
                  {(!question.type || question.type === 'multiple-choice') && (
                    <>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        {question.options.map((option, index) => (
                          <div 
                            key={index}
                            className={`p-2 rounded text-sm ${
                              option === question.answer 
                                ? 'bg-green-100 text-green-800 font-medium' 
                                : 'bg-gray-100'
                            }`}
                          >
                            {option}
                          </div>
                        ))}
                      </div>
                      <p className="text-sm text-gray-600">
                        <strong>Richtige Antwort:</strong> {question.answer}
                      </p>
                    </>
                  )}
                  
                  {/* Wahr/Falsch Anzeige */}
                  {question.type === 'true-false' && question.statements && (
                    <div className="space-y-2 mb-3">
                      {question.statements.map((statement, index) => (
                        <div 
                          key={index}
                          className={`p-2 rounded text-sm flex items-center gap-2 ${
                            statement.isTrue 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {statement.isTrue ? (
                            <CheckCircle className="w-4 h-4 shrink-0" />
                          ) : (
                            <XIcon className="w-4 h-4 shrink-0" />
                          )}
                          <span>{statement.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Sequenz Anzeige */}
                  {question.type === 'sequence' && question.sequence && (
                    <div className="space-y-2 mb-3">
                      {question.sequence.map((item, index) => (
                        <div 
                          key={index}
                          className="p-2 rounded text-sm flex items-center gap-2 bg-blue-50 text-blue-800"
                        >
                          <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-800">
                            {index + 1}
                          </div>
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleEdit(question)}
                    disabled={editingId === question.id || showAddForm}
                    className="gap-1"
                  >
                    <Edit className="w-3 h-3" />
                    Bearbeiten
                  </Button>
                  <Button 
                    size="sm" 
                    variant="destructive"
                    onClick={() => handleDelete(question.id)}
                    disabled={editingId === question.id || showAddForm}
                    className="gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    Löschen
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {questions.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Noch keine Fragen vorhanden.</p>
            <p className="text-sm text-gray-500">Fügen Sie die erste Frage hinzu, um zu beginnen.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}