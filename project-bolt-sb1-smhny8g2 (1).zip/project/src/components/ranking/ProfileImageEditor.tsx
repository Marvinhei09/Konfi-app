import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, Camera, Save, X, RotateCcw, Crop, Copyright as Brightness4, Contrast, Download, AlertCircle, CheckCircle } from 'lucide-react';
import type { User, ProfileImageUpload } from '@/types';

interface ProfileImageEditorProps {
  user: User;
  onSave: (updatedUser: User) => void;
  onClose: () => void;
}

export function ProfileImageEditor({ user, onSave, onClose }: ProfileImageEditorProps) {
  const [uploadData, setUploadData] = useState<ProfileImageUpload | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  const [filters, setFilters] = useState({
    brightness: 100,
    contrast: 100
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validierung
    if (file.size > 5 * 1024 * 1024) {
      setError('Datei ist zu groß. Maximale Größe: 5MB');
      return;
    }

    if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
      setError('Ungültiger Dateityp. Nur JPG, PNG und GIF sind erlaubt.');
      return;
    }

    setError('');
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Überprüfe Mindestauflösung
        if (img.width < 500 || img.height < 500) {
          setError('Bild ist zu klein. Mindestauflösung: 500x500px');
          setIsProcessing(false);
          return;
        }

        const preview = e.target?.result as string;
        setUploadData({
          file,
          preview,
          cropData: {
            x: 0,
            y: 0,
            width: Math.min(img.width, img.height),
            height: Math.min(img.width, img.height)
          },
          filters: { brightness: 100, contrast: 100 }
        });
        setIsProcessing(false);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        } 
      });
      
      // Hier würde normalerweise eine Kamera-Aufnahme-Komponente geöffnet
      // Für diese Demo simulieren wir es
      alert('Kamera-Funktion würde hier implementiert werden');
      stream.getTracks().forEach(track => track.stop());
    } catch (err) {
      setError('Kamera-Zugriff nicht möglich');
    }
  };

  const applyFilters = () => {
    if (!uploadData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = 500;
      canvas.height = 500;

      // Anwenden der Filter
      ctx.filter = `brightness(${filters.brightness}%) contrast(${filters.contrast}%)`;
      
      // Crop und resize
      const cropData = uploadData.cropData!;
      ctx.drawImage(
        img,
        cropData.x, cropData.y, cropData.width, cropData.height,
        0, 0, 500, 500
      );
    };
    img.src = uploadData.preview;
  };

  const handleSave = async () => {
    if (!uploadData) return;

    setIsProcessing(true);

    try {
      // Simuliere Bildverarbeitung
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In einer echten Implementierung würde hier das Bild hochgeladen werden
      const processedImageUrl = uploadData.preview; // Placeholder

      const updatedUser: User = {
        ...user,
        profileImage: processedImageUrl
      };

      onSave(updatedUser);
    } catch (err) {
      setError('Fehler beim Speichern des Bildes');
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;

    const link = document.createElement('a');
    link.download = `${user.username}_profilbild.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Profilbild bearbeiten
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Fehler-Anzeige */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Upload-Bereich */}
          {!uploadData && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Bild hochladen</h3>
                <p className="text-gray-600 mb-4">
                  Wählen Sie ein Bild aus oder nutzen Sie die Kamera
                </p>
                <div className="flex gap-4 justify-center">
                  <Button onClick={() => fileInputRef.current?.click()} className="gap-2">
                    <Upload className="w-4 h-4" />
                    Datei auswählen
                  </Button>
                  <Button variant="outline" onClick={handleCameraCapture} className="gap-2">
                    <Camera className="w-4 h-4" />
                    Kamera verwenden
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-4">
                  Unterstützte Formate: JPG, PNG, GIF • Max. 5MB • Min. 500x500px
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          )}

          {/* Bearbeitungsbereich */}
          {uploadData && (
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Vorschau */}
              <div className="space-y-4">
                <h3 className="font-semibold">Vorschau</h3>
                <div className="relative">
                  <img
                    src={uploadData.preview}
                    alt="Vorschau"
                    className="w-full max-w-md mx-auto rounded-lg border"
                    style={{
                      filter: `brightness(${filters.brightness}%) contrast(${filters.contrast}%)`
                    }}
                  />
                  
                  {/* Crop-Overlay (vereinfacht) */}
                  <div className="absolute inset-0 border-2 border-blue-500 rounded-lg pointer-events-none opacity-50"></div>
                </div>

                {/* Verarbeitetes Bild */}
                <div className="text-center">
                  <h4 className="font-medium mb-2">Finales Bild (500x500px)</h4>
                  <canvas
                    ref={canvasRef}
                    width="150"
                    height="150"
                    className="border rounded-full mx-auto"
                  />
                </div>
              </div>

              {/* Bearbeitungstools */}
              <div className="space-y-6">
                <h3 className="font-semibold">Bearbeitungstools</h3>

                {/* Zuschneiden */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Crop className="w-4 h-4" />
                      Zuschneiden
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-gray-600">
                      Das Bild wird automatisch auf ein quadratisches Format zugeschnitten
                    </p>
                    <Button variant="outline" size="sm" className="gap-2">
                      <RotateCcw className="w-3 h-3" />
                      Zurücksetzen
                    </Button>
                  </CardContent>
                </Card>

                {/* Filter */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Brightness4 className="w-4 h-4" />
                      Filter
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="brightness">
                        Helligkeit: {filters.brightness}%
                      </Label>
                      <Input
                        id="brightness"
                        type="range"
                        min="50"
                        max="150"
                        value={filters.brightness}
                        onChange={(e) => setFilters(prev => ({ 
                          ...prev, 
                          brightness: parseInt(e.target.value) 
                        }))}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contrast">
                        Kontrast: {filters.contrast}%
                      </Label>
                      <Input
                        id="contrast"
                        type="range"
                        min="50"
                        max="150"
                        value={filters.contrast}
                        onChange={(e) => setFilters(prev => ({ 
                          ...prev, 
                          contrast: parseInt(e.target.value) 
                        }))}
                        className="mt-1"
                      />
                    </div>

                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={applyFilters}
                      className="gap-2"
                    >
                      <CheckCircle className="w-3 h-3" />
                      Filter anwenden
                    </Button>
                  </CardContent>
                </Card>

                {/* Komprimierung */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Komprimierung</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">
                      Das Bild wird automatisch für optimale Ladezeiten komprimiert
                    </p>
                    <div className="mt-2 text-xs text-gray-500">
                      Originalgröße: {(uploadData.file.size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Aktionen */}
          {uploadData && (
            <div className="flex gap-4 pt-6 border-t">
              <Button 
                onClick={handleSave} 
                disabled={isProcessing}
                className="gap-2"
              >
                <Save className="w-4 h-4" />
                {isProcessing ? 'Verarbeite...' : 'Speichern'}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={handleDownload}
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Herunterladen
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => setUploadData(null)}
                className="gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Neues Bild
              </Button>
              
              <Button variant="ghost" onClick={onClose}>
                Abbrechen
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}