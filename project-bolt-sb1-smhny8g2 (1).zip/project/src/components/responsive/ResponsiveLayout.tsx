import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, Tablet, Monitor, Info, 
  LayoutGrid, Menu, ArrowLeft, Settings
} from 'lucide-react';

interface ResponsiveLayoutProps {
  children: React.ReactNode;
  title: string;
  backAction?: () => void;
  settingsAction?: () => void;
}

export function ResponsiveLayout({ 
  children, 
  title,
  backAction,
  settingsAction
}: ResponsiveLayoutProps) {
  const [deviceType, setDeviceType] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [menuOpen, setMenuOpen] = useState(false);

  // Detect device type and orientation
  useEffect(() => {
    const detectDevice = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      
      // Set orientation
      setOrientation(width > height ? 'landscape' : 'portrait');
      
      // Set device type based on width
      if (width < 768) {
        setDeviceType('mobile');
      } else if (width < 1024) {
        setDeviceType('tablet');
      } else {
        setDeviceType('desktop');
      }
    };

    // Initial detection
    detectDevice();

    // Listen for resize and orientation change events
    window.addEventListener('resize', detectDevice);
    window.addEventListener('orientationchange', detectDevice);

    return () => {
      window.removeEventListener('resize', detectDevice);
      window.removeEventListener('orientationchange', detectDevice);
    };
  }, []);

  const getDeviceIcon = () => {
    switch (deviceType) {
      case 'mobile': return <Smartphone className="w-4 h-4" />;
      case 'tablet': return <Tablet className="w-4 h-4" />;
      case 'desktop': return <Monitor className="w-4 h-4" />;
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 ${
      deviceType === 'mobile' ? 'p-2' : 'p-6'
    }`}>
      <div className="container mx-auto">
        {/* Header */}
        <div className={`flex justify-between items-center mb-4 ${
          deviceType === 'mobile' ? 'px-2 py-3' : 'mb-6'
        }`}>
          <div className="flex items-center gap-2">
            {backAction && (
              <Button 
                variant="ghost" 
                size={deviceType === 'mobile' ? 'sm' : 'default'}
                onClick={backAction}
                className="mr-1"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
            )}
            <div>
              <h1 className={`font-bold text-gray-900 ${
                deviceType === 'mobile' ? 'text-xl' : 'text-3xl'
              }`}>
                {title}
              </h1>
              {deviceType !== 'mobile' && (
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="gap-1">
                    {getDeviceIcon()}
                    {deviceType} • {orientation}
                  </Badge>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {deviceType === 'mobile' ? (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setMenuOpen(!menuOpen)}
              >
                <Menu className="w-5 h-5" />
              </Button>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-1"
                >
                  <Info className="w-4 h-4" />
                  Info
                </Button>
                {settingsAction && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={settingsAction}
                    className="gap-1"
                  >
                    <Settings className="w-4 h-4" />
                    Einstellungen
                  </Button>
                )}
              </>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {deviceType === 'mobile' && menuOpen && (
          <Card className="mb-4 animate-in fade-in-50 slide-in-from-top-5 duration-300">
            <CardContent className="p-3 space-y-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start gap-2"
              >
                <Info className="w-4 h-4" />
                Info
              </Button>
              {settingsAction && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={settingsAction}
                  className="w-full justify-start gap-2"
                >
                  <Settings className="w-4 h-4" />
                  Einstellungen
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setMenuOpen(false)}
                className="w-full justify-start gap-2 text-red-600"
              >
                <ArrowLeft className="w-4 h-4" />
                Schließen
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        <div className={deviceType === 'mobile' ? 'space-y-3' : 'space-y-6'}>
          {children}
        </div>
      </div>
    </div>
  );
}