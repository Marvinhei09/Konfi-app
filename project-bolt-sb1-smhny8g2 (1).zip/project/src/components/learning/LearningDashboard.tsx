import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { UserProfile } from '../common/UserProfile';
import { 
  BookOpen, FileText, GraduationCap, BarChart3, Clock, Target, 
  TrendingUp, Award, Brain, Search, Filter, Play, ArrowLeft, Users, Settings, Church
} from 'lucide-react';
import { FlashcardManager } from './FlashcardManager';
import { MaterialManager } from './MaterialManager';
import { FlashcardStudy } from './FlashcardStudy';
import { StudentLearningView } from './StudentLearningView';
import type { Flashcard, LearningMaterial, User, StudySession, LearningProgress } from '@/types';

interface LearningDashboardProps {
  flashcards: Flashcard[];
  onFlashcardsChange: (flashcards: Flashcard[]) => void;
  materials: LearningMaterial[];
  onMaterialsChange: (materials: LearningMaterial[]) => void;
  studySessions: StudySession[];
  onStudySessionsChange: (sessions: StudySession[]) => void;
  currentUser: User;
  onBack: () => void;
  churchLogo?: string;
}

export function LearningDashboard({ 
  flashcards, 
  onFlashcardsChange, 
  materials, 
  onMaterialsChange,
  studySessions,
  onStudySessionsChange,
  currentUser,
  onBack,
  churchLogo
}: LearningDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [showStudyMode, setShowStudyMode] = useState(false);

  const handleSessionComplete = (session: Omit<StudySession, 'id'>) => {
    const newSession: StudySession = {
      ...session,
      id: Date.now().toString()
    };
    onStudySessionsChange([...studySessions, newSession]);
    setShowStudyMode(false);
  };

  const handleLogout = () => {
    onBack();
  };

  // Calculate user statistics
  const userSessions = studySessions.filter(s => s.userId === currentUser.username);
  const totalStudyTime = userSessions.reduce((sum, s) => sum + s.duration, 0);
  const totalCardsStudied = userSessions.reduce((sum, s) => sum + s.flashcardsStudied.length, 0);
  const averageAccuracy = userSessions.length > 0 
    ? Math.round(userSessions.reduce((sum, s) => sum + (s.correctAnswers / s.totalAnswers), 0) / userSessions.length * 100)
    : 0;

  // Filter content based on user role
  const availableFlashcards = flashcards.filter(card => {
    if (currentUser.role === 'admin' || currentUser.role === 'teamer') return true;
    if (!card.allowedRoles) return true;
    return currentUser.konfiRole && card.allowedRoles.includes(currentUser.konfiRole);
  });

  const availableMaterials = materials.filter(material => {
    if (currentUser.role === 'admin' || currentUser.role === 'teamer') return true;
    if (!material.allowedRoles) return true;
    return currentUser.konfiRole && material.allowedRoles.includes(currentUser.konfiRole);
  });

  // Get topics and progress
  const topics = [...new Set([...availableFlashcards.map(f => f.topic), ...availableMaterials.map(m => m.topic)])];
  
  const getTopicProgress = (topic: string) => {
    const topicSessions = userSessions.filter(s => s.topic === topic || s.topic === 'all');
    const cardsInTopic = availableFlashcards.filter(f => f.topic === topic);
    const studiedCards = new Set();
    
    topicSessions.forEach(session => {
      session.flashcardsStudied.forEach(cardId => studiedCards.add(cardId));
    });
    
    const progress = cardsInTopic.length > 0 ? (studiedCards.size / cardsInTopic.length) * 100 : 0;
    const accuracy = topicSessions.length > 0 
      ? topicSessions.reduce((sum, s) => sum + (s.correctAnswers / s.totalAnswers), 0) / topicSessions.length * 100
      : 0;
    
    return { progress: Math.min(progress, 100), accuracy: Math.round(accuracy) };
  };

  if (showStudyMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto p-6">
          <FlashcardStudy
            flashcards={availableFlashcards}
            currentUser={currentUser}
            onSessionComplete={handleSessionComplete}
            onBack={() => setShowStudyMode(false)}
          />
        </div>
      </div>
    );
  }

  // Für Konfirmanden: Vereinfachte Ansicht
  if (currentUser.role === 'konfi') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto p-6">
          {/* Header mit Profilbild */}
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center gap-4">
              {/* Church Logo */}
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg">
                {churchLogo ? (
                  <img 
                    src={churchLogo} 
                    alt="Kirchenlogo" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-blue-500 flex items-center justify-center">
                    <Church className="w-8 h-8 text-white" />
                  </div>
                )}
              </div>
              
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Lernplattform</h1>
                <p className="text-gray-600 mt-1">
                  Digitale Karteikarten und Lernmaterialien für den Konfirmationsunterricht
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button onClick={onBack} variant="outline" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Zurück
              </Button>
              <UserProfile user={currentUser} onLogout={handleLogout} />
            </div>
          </div>

          <StudentLearningView
            flashcards={availableFlashcards}
            materials={availableMaterials}
            studySessions={studySessions}
            currentUser={currentUser}
            onStartFlashcardStudy={() => setShowStudyMode(true)}
          />
        </div>
      </div>
    );
  }

  // Für Admins und Teamer: Vollständige Verwaltungsansicht
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        {/* Header mit Profilbild */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            {/* Church Logo */}
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg">
              {churchLogo ? (
                <img 
                  src={churchLogo} 
                  alt="Kirchenlogo" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-blue-500 flex items-center justify-center">
                  <Church className="w-8 h-8 text-white" />
                </div>
              )}
            </div>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Lernplattform</h1>
              <p className="text-gray-600 mt-1">
                Digitale Karteikarten und Lernmaterialien verwalten
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button onClick={onBack} variant="outline" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Zurück zum Dashboard
            </Button>
            <UserProfile user={currentUser} onLogout={handleLogout} />
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Übersicht
            </TabsTrigger>
            <TabsTrigger value="flashcards" className="gap-2">
              <Brain className="w-4 h-4" />
              Karteikarten
            </TabsTrigger>
            <TabsTrigger value="materials" className="gap-2">
              <FileText className="w-4 h-4" />
              Materialien
            </TabsTrigger>
            <TabsTrigger value="progress" className="gap-2">
              <TrendingUp className="w-4 h-4" />
              Fortschritt
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Statistics Cards */}
            <div className="grid gap-6 md:grid-cols-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Karteikarten</p>
                      <p className="text-3xl font-bold">{availableFlashcards.length}</p>
                    </div>
                    <Brain className="w-8 h-8 text-blue-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">Materialien</p>
                      <p className="text-3xl font-bold">{availableMaterials.length}</p>
                    </div>
                    <FileText className="w-8 h-8 text-green-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Lernsessions</p>
                      <p className="text-3xl font-bold">{studySessions.length}</p>
                    </div>
                    <Clock className="w-8 h-8 text-purple-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100">Aktive Nutzer</p>
                      <p className="text-3xl font-bold">{new Set(studySessions.map(s => s.userId)).size}</p>
                    </div>
                    <Users className="w-8 h-8 text-orange-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Play className="w-5 h-5 text-blue-600" />
                    Lernen starten
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Beginnen Sie eine neue Lernsession mit digitalen Karteikarten.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>Verfügbare Karten: {availableFlashcards.length}</p>
                    <p>Themen: {topics.length}</p>
                  </div>
                  <Button 
                    onClick={() => setShowStudyMode(true)} 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    disabled={availableFlashcards.length === 0}
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Karteikarten lernen
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-green-600" />
                    Lernmaterialien
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Zugriff auf PDFs, Zusammenfassungen und andere Lernmaterialien.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>Verfügbare Materialien: {availableMaterials.length}</p>
                    <p>PDFs: {availableMaterials.filter(m => m.type === 'pdf').length}</p>
                    <p>Zusammenfassungen: {availableMaterials.filter(m => m.type === 'summary').length}</p>
                  </div>
                  <Button 
                    onClick={() => setActiveTab('materials')} 
                    variant="outline"
                    className="w-full"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Materialien durchsuchen
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Topic Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Themenübersicht</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {topics.map((topic) => {
                    const { progress, accuracy } = getTopicProgress(topic);
                    const cardCount = availableFlashcards.filter(f => f.topic === topic).length;
                    const materialCount = availableMaterials.filter(m => m.topic === topic).length;
                    
                    return (
                      <Card key={topic} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <h4 className="font-semibold mb-2">{topic}</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Karteikarten:</span>
                              <span>{cardCount}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Materialien:</span>
                              <span>{materialCount}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Fortschritt:</span>
                              <span>{Math.round(progress)}%</span>
                            </div>
                            {accuracy > 0 && (
                              <div className="flex justify-between">
                                <span>Genauigkeit:</span>
                                <span>{accuracy}%</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="flashcards" className="mt-6">
            <FlashcardManager 
              flashcards={flashcards}
              onFlashcardsChange={onFlashcardsChange}
              currentUser={currentUser}
            />
          </TabsContent>

          <TabsContent value="materials" className="mt-6">
            <MaterialManager 
              materials={materials}
              onMaterialsChange={onMaterialsChange}
              currentUser={currentUser}
            />
          </TabsContent>

          <TabsContent value="progress" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5" />
                    Lernstatistiken
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-3xl font-bold text-blue-600">{studySessions.length}</div>
                      <div className="text-sm text-gray-600">Gesamt Sessions</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-3xl font-bold text-green-600">{new Set(studySessions.map(s => s.userId)).size}</div>
                      <div className="text-sm text-gray-600">Aktive Lerner</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-3xl font-bold text-purple-600">
                        {studySessions.reduce((sum, s) => sum + s.duration, 0)}
                      </div>
                      <div className="text-sm text-gray-600">Minuten gelernt</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {studySessions.length === 0 ? (
                <Card className="p-12 text-center bg-gray-50">
                  <CardContent>
                    <GraduationCap className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Noch keine Lernsessions aufgezeichnet.</p>
                    <p className="text-sm text-gray-500">Starten Sie die erste Lernsession, um Statistiken zu sehen.</p>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Letzte Aktivitäten</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {studySessions.slice(-10).reverse().map((session) => (
                        <div key={session.id} className="flex justify-between items-center p-4 border rounded-lg">
                          <div>
                            <h4 className="font-semibold">
                              {session.topic === 'all' ? 'Alle Themen' : session.topic}
                            </h4>
                            <p className="text-sm text-gray-600">
                              Benutzer: {session.userId}
                            </p>
                            <p className="text-sm text-gray-600">
                              {new Date(session.date).toLocaleDateString('de-DE', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant={session.correctAnswers / session.totalAnswers >= 0.8 ? "default" : "secondary"}>
                                {Math.round((session.correctAnswers / session.totalAnswers) * 100)}%
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">
                              {session.correctAnswers}/{session.totalAnswers} richtig • {session.duration} Min
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}