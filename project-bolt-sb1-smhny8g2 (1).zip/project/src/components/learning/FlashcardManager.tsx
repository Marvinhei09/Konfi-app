import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Edit, Trash2, Save, X, BookOpen, Search, Filter, CheckSquare, Square } from 'lucide-react';
import type { Flashcard, User } from '@/types';

interface FlashcardManagerProps {
  flashcards: Flashcard[];
  onFlashcardsChange: (flashcards: Flashcard[]) => void;
  currentUser: User;
}

export function FlashcardManager({ flashcards, onFlashcardsChange, currentUser }: FlashcardManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTopic, setFilterTopic] = useState<string>('all');
  const [filterDifficulty, setFilterDifficulty] = useState<string>('all');
  
  const [formData, setFormData] = useState({
    topic: '',
    question: '',
    answer: '',
    difficulty: 'medium' as 'easy' | 'medium' | 'hard',
    allowedRoles: ['KU4', 'KUZ', 'KU8'] as ('KU4' | 'KUZ' | 'KU8')[],
    tags: ''
  });

  const topics = [...new Set(flashcards.map(f => f.topic))];

  const handleAdd = () => {
    if (!formData.topic || !formData.question || !formData.answer) return;

    const newFlashcard: Flashcard = {
      id: Date.now().toString(),
      topic: formData.topic,
      question: formData.question,
      answer: formData.answer,
      difficulty: formData.difficulty,
      allowedRoles: formData.allowedRoles.length === 3 ? undefined : formData.allowedRoles,
      createdBy: currentUser.username,
      createdAt: new Date().toISOString(),
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
    };

    onFlashcardsChange([...flashcards, newFlashcard]);
    resetForm();
    setShowAddForm(false);
  };

  const handleEdit = (flashcard: Flashcard) => {
    setEditingId(flashcard.id);
    setFormData({
      topic: flashcard.topic,
      question: flashcard.question,
      answer: flashcard.answer,
      difficulty: flashcard.difficulty,
      allowedRoles: flashcard.allowedRoles || ['KU4', 'KUZ', 'KU8'],
      tags: flashcard.tags.join(', ')
    });
  };

  const handleSave = () => {
    if (!editingId) return;

    const updatedFlashcards = flashcards.map(f => 
      f.id === editingId 
        ? { 
            ...f, 
            ...formData,
            allowedRoles: formData.allowedRoles.length === 3 ? undefined : formData.allowedRoles,
            tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
          }
        : f
    );

    onFlashcardsChange(updatedFlashcards);
    setEditingId(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    onFlashcardsChange(flashcards.filter(f => f.id !== id));
  };

  const resetForm = () => {
    setFormData({
      topic: '',
      question: '',
      answer: '',
      difficulty: 'medium',
      allowedRoles: ['KU4', 'KUZ', 'KU8'],
      tags: ''
    });
  };

  const handleRoleChange = (role: 'KU4' | 'KUZ' | 'KU8', checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        allowedRoles: [...formData.allowedRoles, role]
      });
    } else {
      setFormData({
        ...formData,
        allowedRoles: formData.allowedRoles.filter(r => r !== role)
      });
    }
  };

  const toggleAllRoles = () => {
    const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
    const hasAllRoles = allRoles.every(role => formData.allowedRoles.includes(role));
    
    if (hasAllRoles) {
      setFormData({ ...formData, allowedRoles: [] });
    } else {
      setFormData({ ...formData, allowedRoles: allRoles });
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'hard': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'Einfach';
      case 'medium': return 'Mittel';
      case 'hard': return 'Schwer';
      default: return difficulty;
    }
  };

  // Filter flashcards
  const filteredFlashcards = flashcards.filter(flashcard => {
    const matchesSearch = flashcard.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         flashcard.answer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         flashcard.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesTopic = filterTopic === 'all' || flashcard.topic === filterTopic;
    const matchesDifficulty = filterDifficulty === 'all' || flashcard.difficulty === filterDifficulty;
    
    // Role-based filtering for non-admin users
    let matchesRole = true;
    if (currentUser.role === 'konfi' && currentUser.konfiRole) {
      matchesRole = !flashcard.allowedRoles || flashcard.allowedRoles.includes(currentUser.konfiRole);
    }
    
    return matchesSearch && matchesTopic && matchesDifficulty && matchesRole;
  });

  const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
  const hasAllRoles = allRoles.every(role => formData.allowedRoles.includes(role));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Digitale Karteikarten</h2>
          <p className="text-gray-600 text-sm mt-1">
            Erstellen und verwalten Sie Lernkarten für den Konfirmationsunterricht
          </p>
        </div>
        {(currentUser.role === 'admin' || currentUser.role === 'teamer') && (
          <Button 
            onClick={() => setShowAddForm(true)} 
            className="gap-2"
            disabled={showAddForm || editingId}
          >
            <Plus className="w-4 h-4" />
            Neue Karteikarte
          </Button>
        )}
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterTopic} onValueChange={setFilterTopic}>
              <SelectTrigger>
                <SelectValue placeholder="Thema" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Themen</SelectItem>
                {topics.map(topic => (
                  <SelectItem key={topic} value={topic}>{topic}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
              <SelectTrigger>
                <SelectValue placeholder="Schwierigkeit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Schwierigkeiten</SelectItem>
                <SelectItem value="easy">Einfach</SelectItem>
                <SelectItem value="medium">Mittel</SelectItem>
                <SelectItem value="hard">Schwer</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {filteredFlashcards.length} von {flashcards.length} Karten
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form */}
      {(showAddForm || editingId) && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>
              {editingId ? 'Karteikarte bearbeiten' : 'Neue Karteikarte erstellen'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="topic">Thema *</Label>
                <Input
                  id="topic"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  placeholder="z.B. Grundwissen, Bibel, Gebote..."
                />
              </div>
              <div>
                <Label htmlFor="difficulty">Schwierigkeit</Label>
                <Select
                  value={formData.difficulty}
                  onValueChange={(value: 'easy' | 'medium' | 'hard') => setFormData({ ...formData, difficulty: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Einfach</SelectItem>
                    <SelectItem value="medium">Mittel</SelectItem>
                    <SelectItem value="hard">Schwer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="question">Frage *</Label>
              <Textarea
                id="question"
                value={formData.question}
                onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                placeholder="Geben Sie die Frage ein..."
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="answer">Antwort *</Label>
              <Textarea
                id="answer"
                value={formData.answer}
                onChange={(e) => setFormData({ ...formData, answer: e.target.value })}
                placeholder="Geben Sie die Antwort ein..."
                rows={4}
              />
            </div>

            <div>
              <Label htmlFor="tags">Tags (optional)</Label>
              <Input
                id="tags"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder="Tags durch Komma getrennt, z.B. grundlagen, wichtig, prüfung"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Sichtbar für Rollen</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={toggleAllRoles}
                  className="gap-2 text-xs"
                >
                  {hasAllRoles ? (
                    <>
                      <CheckSquare className="w-3 h-3" />
                      Alle abwählen
                    </>
                  ) : (
                    <>
                      <Square className="w-3 h-3" />
                      Alle auswählen
                    </>
                  )}
                </Button>
              </div>
              <div className="flex gap-4">
                {allRoles.map((role) => (
                  <div key={role} className="flex items-center space-x-2">
                    <Checkbox
                      id={role}
                      checked={formData.allowedRoles.includes(role)}
                      onCheckedChange={(checked) => handleRoleChange(role, checked as boolean)}
                    />
                    <Label htmlFor={role} className="text-sm">
                      <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                        {role}
                      </Badge>
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={editingId ? handleSave : handleAdd} className="gap-2">
                <Save className="w-4 h-4" />
                {editingId ? 'Speichern' : 'Erstellen'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                  resetForm();
                }}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Flashcards Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredFlashcards.map((flashcard) => (
          <Card key={flashcard.id} className="transition-all hover:shadow-lg">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{flashcard.topic}</Badge>
                  <div className={`w-3 h-3 rounded-full ${getDifficultyColor(flashcard.difficulty)}`} 
                       title={getDifficultyLabel(flashcard.difficulty)} />
                </div>
                {(currentUser.role === 'admin' || currentUser.role === 'teamer' || flashcard.createdBy === currentUser.username) && (
                  <div className="flex gap-1">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => handleEdit(flashcard)}
                      disabled={editingId === flashcard.id || showAddForm}
                      className="h-6 w-6 p-0"
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => handleDelete(flashcard.id)}
                      disabled={editingId === flashcard.id || showAddForm}
                      className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-sm text-gray-700 mb-1">Frage:</h4>
                  <p className="text-sm">{flashcard.question}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-sm text-gray-700 mb-1">Antwort:</h4>
                  <p className="text-sm text-gray-600">{flashcard.answer}</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t">
                {flashcard.allowedRoles && (
                  <div className="flex gap-1 mb-2">
                    {flashcard.allowedRoles.map(role => (
                      <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                        {role}
                      </Badge>
                    ))}
                  </div>
                )}
                
                {flashcard.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {flashcard.tags.map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                )}
                
                <p className="text-xs text-gray-500">
                  Erstellt von {flashcard.createdBy} am {new Date(flashcard.createdAt).toLocaleDateString('de-DE')}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredFlashcards.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {flashcards.length === 0 
                ? 'Noch keine Karteikarten vorhanden.' 
                : 'Keine Karteikarten entsprechen den Filterkriterien.'
              }
            </p>
            <p className="text-sm text-gray-500">
              {currentUser.role === 'admin' || currentUser.role === 'teamer' 
                ? 'Erstellen Sie die erste Karteikarte, um zu beginnen.'
                : 'Warten Sie auf neue Karteikarten von Ihren Lehrern.'
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}