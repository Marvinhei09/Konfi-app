import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  RotateCcw, CheckCircle, XCircle, Eye, EyeOff, Shuffle, 
  Trophy, Clock, Target, ArrowLeft, ArrowRight, SkipForward
} from 'lucide-react';
import type { Flashcard, User, StudySession } from '@/types';

interface FlashcardStudyProps {
  flashcards: Flashcard[];
  currentUser: User;
  onSessionComplete: (session: Omit<StudySession, 'id'>) => void;
  onBack: () => void;
}

export function FlashcardStudy({ flashcards, currentUser, onSessionComplete, onBack }: FlashcardStudyProps) {
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [studyCards, setStudyCards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [studiedCards, setStudiedCards] = useState<string[]>([]);
  const [sessionStartTime, setSessionStartTime] = useState<Date | null>(null);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionComplete, setSessionComplete] = useState(false);

  // Filter flashcards based on user role and selected topic
  const availableFlashcards = flashcards.filter(card => {
    const roleMatch = currentUser.role === 'admin' || 
                     !card.allowedRoles || 
                     (currentUser.konfiRole && card.allowedRoles.includes(currentUser.konfiRole));
    
    const topicMatch = selectedTopic === 'all' || card.topic === selectedTopic;
    
    return roleMatch && topicMatch;
  });

  const topics = [...new Set(availableFlashcards.map(f => f.topic))];

  const startStudySession = (topic: string) => {
    const cardsToStudy = topic === 'all' 
      ? availableFlashcards 
      : availableFlashcards.filter(f => f.topic === topic);
    
    // Shuffle cards for better learning
    const shuffledCards = [...cardsToStudy].sort(() => Math.random() - 0.5);
    
    setStudyCards(shuffledCards);
    setCurrentIndex(0);
    setShowAnswer(false);
    setCorrectAnswers(0);
    setStudiedCards([]);
    setSessionStartTime(new Date());
    setIsSessionActive(true);
    setSessionComplete(false);
  };

  const handleAnswer = (isCorrect: boolean) => {
    if (!studyCards[currentIndex]) return;

    const cardId = studyCards[currentIndex].id;
    
    if (!studiedCards.includes(cardId)) {
      setStudiedCards([...studiedCards, cardId]);
      if (isCorrect) {
        setCorrectAnswers(correctAnswers + 1);
      }
    }

    // Move to next card or complete session
    if (currentIndex + 1 < studyCards.length) {
      setCurrentIndex(currentIndex + 1);
      setShowAnswer(false);
    } else {
      completeSession();
    }
  };

  const completeSession = () => {
    if (!sessionStartTime) return;

    const duration = Math.round((new Date().getTime() - sessionStartTime.getTime()) / 60000); // minutes
    
    const session: Omit<StudySession, 'id'> = {
      userId: currentUser.username,
      topic: selectedTopic,
      flashcardsStudied: studiedCards,
      correctAnswers,
      totalAnswers: studiedCards.length,
      duration,
      date: new Date().toISOString()
    };

    onSessionComplete(session);
    setSessionComplete(true);
    setIsSessionActive(false);
  };

  const restartSession = () => {
    startStudySession(selectedTopic);
  };

  const skipCard = () => {
    if (currentIndex + 1 < studyCards.length) {
      setCurrentIndex(currentIndex + 1);
      setShowAnswer(false);
    } else {
      completeSession();
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setShowAnswer(false);
    }
  };

  const shuffleCards = () => {
    const shuffled = [...studyCards].sort(() => Math.random() - 0.5);
    setStudyCards(shuffled);
    setCurrentIndex(0);
    setShowAnswer(false);
  };

  const currentCard = studyCards[currentIndex];
  const progress = studyCards.length > 0 ? ((currentIndex + 1) / studyCards.length) * 100 : 0;
  const accuracy = studiedCards.length > 0 ? Math.round((correctAnswers / studiedCards.length) * 100) : 0;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'hard': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'Einfach';
      case 'medium': return 'Mittel';
      case 'hard': return 'Schwer';
      default: return difficulty;
    }
  };

  if (sessionComplete) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card className="border-2 border-green-200 bg-green-50">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
              <Trophy className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl text-green-800">
              Lernsession abgeschlossen!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-3 text-center">
              <div className="p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{studiedCards.length}</div>
                <div className="text-sm text-gray-600">Karten studiert</div>
              </div>
              <div className="p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-green-600">{accuracy}%</div>
                <div className="text-sm text-gray-600">Genauigkeit</div>
              </div>
              <div className="p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-purple-600">
                  {sessionStartTime ? Math.round((new Date().getTime() - sessionStartTime.getTime()) / 60000) : 0}
                </div>
                <div className="text-sm text-gray-600">Minuten</div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Richtige Antworten</span>
                <span>{correctAnswers} von {studiedCards.length}</span>
              </div>
              <Progress value={accuracy} className="h-3" />
            </div>

            <div className="flex gap-2 justify-center">
              <Button onClick={restartSession} className="gap-2">
                <RotateCcw className="w-4 h-4" />
                Nochmal üben
              </Button>
              <Button variant="outline" onClick={onBack} className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Zurück
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isSessionActive) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onBack} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Zurück
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Karteikarten lernen</h1>
            <p className="text-gray-600">Wählen Sie ein Thema zum Üben aus</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lernsession starten</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Thema auswählen</label>
              <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                <SelectTrigger>
                  <SelectValue placeholder="Thema wählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle Themen ({availableFlashcards.length} Karten)</SelectItem>
                  {topics.map(topic => {
                    const count = availableFlashcards.filter(f => f.topic === topic).length;
                    return (
                      <SelectItem key={topic} value={topic}>
                        {topic} ({count} Karten)
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {selectedTopic && (
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold mb-2">Ausgewähltes Thema: {selectedTopic === 'all' ? 'Alle Themen' : selectedTopic}</h4>
                <p className="text-sm text-gray-600 mb-3">
                  {selectedTopic === 'all' 
                    ? `${availableFlashcards.length} Karteikarten aus allen Themenbereichen`
                    : `${availableFlashcards.filter(f => f.topic === selectedTopic).length} Karteikarten zum Thema ${selectedTopic}`
                  }
                </p>
                <Button 
                  onClick={() => startStudySession(selectedTopic)} 
                  className="w-full gap-2"
                  disabled={availableFlashcards.filter(f => selectedTopic === 'all' || f.topic === selectedTopic).length === 0}
                >
                  <Target className="w-4 h-4" />
                  Lernsession starten
                </Button>
              </div>
            )}

            {availableFlashcards.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Target className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>Keine Karteikarten für Ihre Rolle verfügbar.</p>
                <p className="text-sm">Warten Sie auf neue Karteikarten von Ihren Lehrern.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!currentCard) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-gray-600">Keine Karteikarten zum Lernen verfügbar.</p>
            <Button onClick={onBack} className="mt-4">Zurück</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header with progress */}
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack} className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Beenden
        </Button>
        <div className="text-center">
          <div className="text-sm text-gray-600">
            Karte {currentIndex + 1} von {studyCards.length}
          </div>
          <div className="text-xs text-gray-500">
            {accuracy}% richtig • {Math.round((new Date().getTime() - (sessionStartTime?.getTime() || 0)) / 60000)} Min
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={shuffleCards} className="gap-1">
            <Shuffle className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <Progress value={progress} className="h-2" />

      {/* Flashcard */}
      <Card className="min-h-[400px] cursor-pointer" onClick={() => setShowAnswer(!showAnswer)}>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{currentCard.topic}</Badge>
              <div className={`w-3 h-3 rounded-full ${getDifficultyColor(currentCard.difficulty)}`} 
                   title={getDifficultyLabel(currentCard.difficulty)} />
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                setShowAnswer(!showAnswer);
              }}
              className="gap-2"
            >
              {showAnswer ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showAnswer ? 'Antwort verbergen' : 'Antwort zeigen'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-4">Frage:</h3>
            <p className="text-xl leading-relaxed">{currentCard.question}</p>
          </div>

          {showAnswer && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold mb-4 text-green-700">Antwort:</h3>
              <p className="text-lg leading-relaxed text-gray-700">{currentCard.answer}</p>
            </div>
          )}

          {!showAnswer && (
            <div className="text-center text-gray-500">
              <p className="text-sm">Klicken Sie hier oder auf "Antwort zeigen", um die Antwort zu sehen</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action buttons */}
      <div className="flex gap-2 justify-center">
        <Button
          variant="outline"
          onClick={goToPrevious}
          disabled={currentIndex === 0}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Zurück
        </Button>

        <Button
          variant="outline"
          onClick={skipCard}
          className="gap-2"
        >
          <SkipForward className="w-4 h-4" />
          Überspringen
        </Button>

        {showAnswer && (
          <>
            <Button
              variant="destructive"
              onClick={() => handleAnswer(false)}
              className="gap-2"
            >
              <XCircle className="w-4 h-4" />
              Falsch
            </Button>
            <Button
              variant="default"
              onClick={() => handleAnswer(true)}
              className="gap-2 bg-green-600 hover:bg-green-700"
            >
              <CheckCircle className="w-4 h-4" />
              Richtig
            </Button>
          </>
        )}
      </div>

      {/* Tags */}
      {currentCard.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 justify-center">
          {currentCard.tags.map(tag => (
            <Badge key={tag} variant="outline" className="text-xs">
              #{tag}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}