import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Plus, Edit, Trash2, Save, X, FileText, Image, BookOpen, Search, Filter, 
  Download, Eye, Upload, CheckSquare, Square, AlertCircle, CheckCircle,
  File, Video, Music
} from 'lucide-react';
import type { LearningMaterial, User } from '@/types';

interface MaterialManagerProps {
  materials: LearningMaterial[];
  onMaterialsChange: (materials: LearningMaterial[]) => void;
  currentUser: User;
}

export function MaterialManager({ materials, onMaterialsChange, currentUser }: MaterialManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTopic, setFilterTopic] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'summary' as 'pdf' | 'image' | 'summary' | 'video' | 'audio',
    content: '',
    topic: '',
    allowedRoles: ['KU4', 'KUZ', 'KU8'] as ('KU4' | 'KUZ' | 'KU8')[],
    tags: ''
  });

  const topics = [...new Set(materials.map(m => m.topic))];

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        showNotification('error', 'Datei ist zu groß. Maximale Größe: 10MB');
        return;
      }

      // Check file type
      const allowedTypes = {
        'pdf': ['application/pdf'],
        'image': ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
        'video': ['video/mp4', 'video/webm', 'video/ogg'],
        'audio': ['audio/mp3', 'audio/wav', 'audio/ogg']
      };

      const typeCategory = Object.keys(allowedTypes).find(category => 
        allowedTypes[category as keyof typeof allowedTypes].includes(file.type)
      );

      if (!typeCategory) {
        showNotification('error', 'Dateityp nicht unterstützt');
        return;
      }

      setSelectedFile(file);
      setFormData({ 
        ...formData, 
        type: typeCategory as 'pdf' | 'image' | 'video' | 'audio',
        title: formData.title || file.name.split('.')[0]
      });
      showNotification('success', `Datei "${file.name}" ausgewählt`);
    }
  };

  const handleAdd = () => {
    if (!formData.title || !formData.topic) {
      showNotification('error', 'Titel und Thema sind erforderlich');
      return;
    }

    if (formData.type === 'summary' && !formData.content) {
      showNotification('error', 'Inhalt ist für Zusammenfassungen erforderlich');
      return;
    }

    if (formData.type !== 'summary' && !selectedFile) {
      showNotification('error', 'Datei ist erforderlich');
      return;
    }

    // In a real implementation, you would upload the file to a server
    const fileUrl = selectedFile ? URL.createObjectURL(selectedFile) : undefined;

    const newMaterial: LearningMaterial = {
      id: Date.now().toString(),
      title: formData.title,
      description: formData.description,
      type: formData.type,
      fileUrl,
      content: formData.type === 'summary' ? formData.content : undefined,
      topic: formData.topic,
      allowedRoles: formData.allowedRoles.length === 3 ? undefined : formData.allowedRoles,
      uploadedBy: currentUser.username,
      uploadedAt: new Date().toISOString(),
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      fileSize: selectedFile?.size,
      fileName: selectedFile?.name
    };

    onMaterialsChange([...materials, newMaterial]);
    showNotification('success', 'Lernmaterial erfolgreich hinzugefügt');
    resetForm();
    setShowAddForm(false);
  };

  const handleEdit = (material: LearningMaterial) => {
    setEditingId(material.id);
    setFormData({
      title: material.title,
      description: material.description,
      type: material.type,
      content: material.content || '',
      topic: material.topic,
      allowedRoles: material.allowedRoles || ['KU4', 'KUZ', 'KU8'],
      tags: material.tags.join(', ')
    });
  };

  const handleSave = () => {
    if (!editingId) return;

    const updatedMaterials = materials.map(m => 
      m.id === editingId 
        ? { 
            ...m, 
            title: formData.title,
            description: formData.description,
            content: formData.type === 'summary' ? formData.content : m.content,
            topic: formData.topic,
            allowedRoles: formData.allowedRoles.length === 3 ? undefined : formData.allowedRoles,
            tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
          }
        : m
    );

    onMaterialsChange(updatedMaterials);
    showNotification('success', 'Lernmaterial erfolgreich aktualisiert');
    setEditingId(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    const material = materials.find(m => m.id === id);
    onMaterialsChange(materials.filter(m => m.id !== id));
    showNotification('success', `"${material?.title}" wurde gelöscht`);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      type: 'summary',
      content: '',
      topic: '',
      allowedRoles: ['KU4', 'KUZ', 'KU8'],
      tags: ''
    });
    setSelectedFile(null);
  };

  const handleRoleChange = (role: 'KU4' | 'KUZ' | 'KU8', checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        allowedRoles: [...formData.allowedRoles, role]
      });
    } else {
      setFormData({
        ...formData,
        allowedRoles: formData.allowedRoles.filter(r => r !== role)
      });
    }
  };

  const toggleAllRoles = () => {
    const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
    const hasAllRoles = allRoles.every(role => formData.allowedRoles.includes(role));
    
    if (hasAllRoles) {
      setFormData({ ...formData, allowedRoles: [] });
    } else {
      setFormData({ ...formData, allowedRoles: allRoles });
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="w-4 h-4" />;
      case 'image': return <Image className="w-4 h-4" />;
      case 'summary': return <BookOpen className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'audio': return <Music className="w-4 h-4" />;
      default: return <File className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'pdf': return 'PDF-Dokument';
      case 'image': return 'Bild/Grafik';
      case 'summary': return 'Zusammenfassung';
      case 'video': return 'Video';
      case 'audio': return 'Audio';
      default: return type;
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  // Filter materials
  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesTopic = filterTopic === 'all' || material.topic === filterTopic;
    const matchesType = filterType === 'all' || material.type === filterType;
    
    // Role-based filtering for non-admin users
    let matchesRole = true;
    if (currentUser.role === 'konfi' && currentUser.konfiRole) {
      matchesRole = !material.allowedRoles || material.allowedRoles.includes(currentUser.konfiRole);
    }
    
    return matchesSearch && matchesTopic && matchesType && matchesRole;
  });

  const allRoles: ('KU4' | 'KUZ' | 'KU8')[] = ['KU4', 'KUZ', 'KU8'];
  const hasAllRoles = allRoles.every(role => formData.allowedRoles.includes(role));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Lernmaterialien</h2>
          <p className="text-gray-600 text-sm mt-1">
            Verwalten Sie PDFs, Bilder, Zusammenfassungen und andere Lernmaterialien
          </p>
        </div>
        {(currentUser.role === 'admin' || currentUser.role === 'teamer') && (
          <Button 
            onClick={() => setShowAddForm(true)} 
            className="gap-2"
            disabled={showAddForm || editingId}
          >
            <Plus className="w-4 h-4" />
            Material hinzufügen
          </Button>
        )}
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          {notification.type === 'error' ? (
            <AlertCircle className="h-4 w-4" />
          ) : (
            <CheckCircle className="h-4 w-4" />
          )}
          <AlertDescription>{notification.message}</AlertDescription>
        </Alert>
      )}

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterTopic} onValueChange={setFilterTopic}>
              <SelectTrigger>
                <SelectValue placeholder="Thema" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Themen</SelectItem>
                {topics.map(topic => (
                  <SelectItem key={topic} value={topic}>{topic}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Typ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Typen</SelectItem>
                <SelectItem value="pdf">PDF-Dokumente</SelectItem>
                <SelectItem value="image">Bilder/Grafiken</SelectItem>
                <SelectItem value="summary">Zusammenfassungen</SelectItem>
                <SelectItem value="video">Videos</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {filteredMaterials.length} von {materials.length} Materialien
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form */}
      {(showAddForm || editingId) && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>
              {editingId ? 'Lernmaterial bearbeiten' : 'Neues Lernmaterial hinzufügen'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="title">Titel *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Titel des Materials"
                />
              </div>
              <div>
                <Label htmlFor="topic">Thema *</Label>
                <Input
                  id="topic"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  placeholder="z.B. Grundwissen, Bibel, Gebote..."
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Beschreibung</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Kurze Beschreibung des Materials..."
                rows={2}
              />
            </div>

            <div>
              <Label htmlFor="type">Material-Typ</Label>
              <Select
                value={formData.type}
                onValueChange={(value: 'pdf' | 'image' | 'summary' | 'video' | 'audio') => 
                  setFormData({ ...formData, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="summary">Zusammenfassung (Text)</SelectItem>
                  <SelectItem value="pdf">PDF-Dokument</SelectItem>
                  <SelectItem value="image">Bild/Grafik</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="audio">Audio</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.type === 'summary' ? (
              <div>
                <Label htmlFor="content">Inhalt *</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Geben Sie den Inhalt der Zusammenfassung ein... (Markdown wird unterstützt)"
                  rows={8}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Sie können Markdown-Formatierung verwenden (# für Überschriften, ** für fett, etc.)
                </p>
              </div>
            ) : (
              <div>
                <Label htmlFor="file">Datei hochladen *</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="file"
                    type="file"
                    onChange={handleFileSelect}
                    accept={
                      formData.type === 'pdf' ? '.pdf' :
                      formData.type === 'image' ? 'image/*' :
                      formData.type === 'video' ? 'video/*' :
                      formData.type === 'audio' ? 'audio/*' : '*'
                    }
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="gap-2"
                    onClick={() => document.getElementById('file')?.click()}
                  >
                    <Upload className="w-4 h-4" />
                    Auswählen
                  </Button>
                </div>
                {selectedFile && (
                  <div className="mt-2 p-2 bg-green-50 rounded border">
                    <p className="text-sm text-green-700">
                      Datei ausgewählt: {selectedFile.name} ({formatFileSize(selectedFile.size)})
                    </p>
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Maximale Dateigröße: 10MB. Unterstützte Formate: PDF, JPG, PNG, GIF, MP4, MP3, WAV
                </p>
              </div>
            )}

            <div>
              <Label htmlFor="tags">Tags (optional)</Label>
              <Input
                id="tags"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder="Tags durch Komma getrennt, z.B. wichtig, prüfung, grundlagen"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Sichtbar für Rollen</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={toggleAllRoles}
                  className="gap-2 text-xs"
                >
                  {hasAllRoles ? (
                    <>
                      <CheckSquare className="w-3 h-3" />
                      Alle abwählen
                    </>
                  ) : (
                    <>
                      <Square className="w-3 h-3" />
                      Alle auswählen
                    </>
                  )}
                </Button>
              </div>
              <div className="flex gap-4">
                {allRoles.map((role) => (
                  <div key={role} className="flex items-center space-x-2">
                    <Checkbox
                      id={role}
                      checked={formData.allowedRoles.includes(role)}
                      onCheckedChange={(checked) => handleRoleChange(role, checked as boolean)}
                    />
                    <Label htmlFor={role} className="text-sm">
                      <Badge variant={getRoleBadgeColor(role)} className="mr-1">
                        {role}
                      </Badge>
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={editingId ? handleSave : handleAdd} className="gap-2">
                <Save className="w-4 h-4" />
                {editingId ? 'Speichern' : 'Hinzufügen'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                  resetForm();
                }}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Materials Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredMaterials.map((material) => (
          <Card key={material.id} className="transition-all hover:shadow-lg">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  {getTypeIcon(material.type)}
                  <Badge variant="secondary">{material.topic}</Badge>
                </div>
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={() => {
                      if (material.type === 'summary') {
                        // Show content in a modal or navigate to detail view
                        alert('Zusammenfassung anzeigen: ' + material.title);
                      } else if (material.fileUrl) {
                        window.open(material.fileUrl, '_blank');
                      }
                    }}
                    className="h-6 w-6 p-0"
                    title="Anzeigen"
                  >
                    <Eye className="w-3 h-3" />
                  </Button>
                  {material.fileUrl && material.type !== 'summary' && (
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = material.fileUrl!;
                        link.download = material.fileName || material.title;
                        link.click();
                      }}
                      className="h-6 w-6 p-0"
                      title="Herunterladen"
                    >
                      <Download className="w-3 h-3" />
                    </Button>
                  )}
                  {(currentUser.role === 'admin' || currentUser.role === 'teamer' || material.uploadedBy === currentUser.username) && (
                    <>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => handleEdit(material)}
                        disabled={editingId === material.id || showAddForm}
                        className="h-6 w-6 p-0"
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => handleDelete(material.id)}
                        disabled={editingId === material.id || showAddForm}
                        className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold">{material.title}</h4>
                <p className="text-sm text-gray-600">{material.description}</p>
                
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Badge variant="outline" className="text-xs">
                    {getTypeLabel(material.type)}
                  </Badge>
                  {material.fileSize && (
                    <span>{formatFileSize(material.fileSize)}</span>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t">
                {material.allowedRoles && (
                  <div className="flex gap-1 mb-2">
                    {material.allowedRoles.map(role => (
                      <Badge key={role} variant={getRoleBadgeColor(role)} className="text-xs">
                        {role}
                      </Badge>
                    ))}
                  </div>
                )}
                
                {material.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {material.tags.slice(0, 3).map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                    {material.tags.length > 3 && (
                      <span className="text-xs text-gray-500">+{material.tags.length - 3}</span>
                    )}
                  </div>
                )}
                
                <p className="text-xs text-gray-500">
                  Von {material.uploadedBy} am {new Date(material.uploadedAt).toLocaleDateString('de-DE')}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMaterials.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {materials.length === 0 
                ? 'Noch keine Lernmaterialien vorhanden.' 
                : 'Keine Materialien entsprechen den Filterkriterien.'
              }
            </p>
            <p className="text-sm text-gray-500">
              {currentUser.role === 'admin' || currentUser.role === 'teamer' 
                ? 'Fügen Sie das erste Lernmaterial hinzu, um zu beginnen.'
                : 'Warten Sie auf neue Materialien von Ihren Lehrern.'
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}