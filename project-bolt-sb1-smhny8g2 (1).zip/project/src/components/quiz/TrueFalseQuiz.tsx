import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, ArrowRight, ThumbsUp } from 'lucide-react';
import type { Question } from '@/types';

interface TrueFalseQuizProps {
  question: Question;
  onComplete: (score: number, total: number) => void;
  onBack: () => void;
}

export function TrueFalseQuiz({ question, onComplete, onBack }: TrueFalseQuizProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);

  const statements = question.statements || [];
  const progress = ((currentIndex + 1) / statements.length) * 100;

  const handleAnswer = (answer: boolean) => {
    if (isAnswered) return;
    
    const isCorrect = answer === statements[currentIndex].isTrue;
    
    if (isCorrect) {
      setScore(score + 1);
    }
    
    setAnswers([...answers, answer]);
    setIsAnswered(true);
  };

  const handleNext = () => {
    if (currentIndex + 1 < statements.length) {
      setCurrentIndex(currentIndex + 1);
      setIsAnswered(false);
    } else {
      setShowResult(true);
      onComplete(score + (isAnswered && answers[answers.length-1] === statements[currentIndex].isTrue ? 1 : 0), statements.length);
    }
  };

  if (showResult) {
    const finalScore = score + (isAnswered && answers[answers.length-1] === statements[currentIndex].isTrue ? 1 : 0);
    const percentage = Math.round((finalScore / statements.length) * 100);
    
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-green-400 to-green-500 rounded-full flex items-center justify-center mb-4">
            <ThumbsUp className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold">Wahr/Falsch Quiz Abgeschlossen!</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
            <div className="text-4xl font-bold text-blue-600 mb-2">
              {finalScore} / {statements.length}
            </div>
            <div className="text-lg text-gray-600">
              {percentage}% richtig beantwortet
            </div>
          </div>
          <div className="flex justify-center">
            <Badge 
              variant={percentage >= 80 ? "default" : percentage >= 60 ? "secondary" : "destructive"}
              className="text-sm px-4 py-2"
            >
              {percentage >= 80 ? "Ausgezeichnet!" : percentage >= 60 ? "Gut gemacht!" : "Weiter üben!"}
            </Badge>
          </div>
          <Button onClick={onBack} className="gap-2">
            Zurück zur Übersicht
          </Button>
        </CardContent>
      </Card>
    );
  }

  const currentStatement = statements[currentIndex];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <Badge variant="outline">{question.topic}</Badge>
          <span className="text-sm text-gray-500">
            Aussage {currentIndex + 1} von {statements.length}
          </span>
        </div>
        <Progress value={progress} className="mb-4" />
        <CardTitle className="text-xl leading-relaxed">
          Ist folgende Aussage wahr oder falsch?
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-6 bg-gray-50 rounded-lg border text-center text-lg font-medium">
          {currentStatement.text}
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <Button
            variant={
              !isAnswered 
                ? "outline" 
                : currentStatement.isTrue
                  ? "default"
                  : answers[currentIndex] === true
                    ? "destructive"
                    : "outline"
            }
            className={`h-16 text-lg font-semibold transition-all ${
              isAnswered && currentStatement.isTrue
                ? "bg-green-500 hover:bg-green-600 text-white"
                : isAnswered && answers[currentIndex] === true && !currentStatement.isTrue
                  ? "bg-red-500 hover:bg-red-600 text-white"
                  : ""
            }`}
            onClick={() => handleAnswer(true)}
            disabled={isAnswered}
          >
            <div className="flex items-center gap-3">
              {isAnswered && (
                currentStatement.isTrue ? (
                  <CheckCircle className="w-6 h-6" />
                ) : answers[currentIndex] === true ? (
                  <XCircle className="w-6 h-6" />
                ) : null
              )}
              <span>Wahr</span>
            </div>
          </Button>
          
          <Button
            variant={
              !isAnswered 
                ? "outline" 
                : !currentStatement.isTrue
                  ? "default"
                  : answers[currentIndex] === false
                    ? "destructive"
                    : "outline"
            }
            className={`h-16 text-lg font-semibold transition-all ${
              isAnswered && !currentStatement.isTrue
                ? "bg-green-500 hover:bg-green-600 text-white"
                : isAnswered && answers[currentIndex] === false && currentStatement.isTrue
                  ? "bg-red-500 hover:bg-red-600 text-white"
                  : ""
            }`}
            onClick={() => handleAnswer(false)}
            disabled={isAnswered}
          >
            <div className="flex items-center gap-3">
              {isAnswered && (
                !currentStatement.isTrue ? (
                  <CheckCircle className="w-6 h-6" />
                ) : answers[currentIndex] === false ? (
                  <XCircle className="w-6 h-6" />
                ) : null
              )}
              <span>Falsch</span>
            </div>
          </Button>
        </div>
        
        {isAnswered && (
          <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
            <p className="font-medium text-blue-800">
              {currentStatement.isTrue ? "Richtig! Diese Aussage ist wahr." : "Richtig! Diese Aussage ist falsch."}
            </p>
            <p className="text-blue-600 mt-2">
              {currentStatement.isTrue 
                ? "Du hast die Wahrheit erkannt!" 
                : "Gut gemacht, du hast den Fehler entdeckt!"}
            </p>
          </div>
        )}
        
        {isAnswered && (
          <div className="pt-4">
            <Button onClick={handleNext} className="w-full gap-2">
              {currentIndex + 1 < statements.length ? (
                <>
                  Nächste Aussage
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : (
                'Quiz beenden'
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}