import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Trophy } from 'lucide-react';
import { TrueFalseQuiz } from './TrueFalseQuiz';
import { SequenceQuiz } from './SequenceQuiz';
import type { Question, QuizHistory } from '@/types';

interface QuizInterfaceProps {
  questions: Question[];
  onComplete: (result: Omit<QuizHistory, 'id'>) => void;
  username: string;
}

export function QuizInterface({ questions, onComplete, username }: QuizInterfaceProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isAnswered, setIsAnswered] = useState(false);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  // Prüfe, ob es sich um einen speziellen Fragetyp handelt
  const isSpecialQuestionType = currentQuestion?.type === 'true-false' || currentQuestion?.type === 'sequence';

  const handleAnswerSelect = (answer: string) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    if (answer === currentQuestion.answer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setShowResult(true);
      onComplete({
        user: username,
        date: new Date().toLocaleString('de-DE'),
        points: score + (selectedAnswer === currentQuestion.answer ? 1 : 0),
        max: questions.length
      });
    }
  };

  const handleSpecialQuestionComplete = (questionScore: number, maxScore: number) => {
    // Aktualisiere den Gesamtscore
    setScore(score + questionScore);
    
    // Gehe zur nächsten Frage oder beende das Quiz
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setShowResult(true);
      onComplete({
        user: username,
        date: new Date().toLocaleString('de-DE'),
        points: score + questionScore,
        max: questions.reduce((total, q) => {
          if (q.type === 'true-false' && q.statements) {
            return total + q.statements.length;
          } else if (q.type === 'sequence' && q.sequence) {
            return total + q.sequence.length;
          } else {
            return total + 1;
          }
        }, 0)
      });
    }
  };

  // Rendere spezielle Fragetypen
  if (currentQuestion?.type === 'true-false') {
    return (
      <TrueFalseQuiz 
        question={currentQuestion} 
        onComplete={handleSpecialQuestionComplete}
        onBack={() => {}} // Wird nicht verwendet, da wir im Quiz-Flow sind
      />
    );
  }

  if (currentQuestion?.type === 'sequence') {
    return (
      <SequenceQuiz 
        question={currentQuestion} 
        onComplete={handleSpecialQuestionComplete}
        onBack={() => {}} // Wird nicht verwendet, da wir im Quiz-Flow sind
      />
    );
  }

  if (showResult) {
    const finalScore = score + (selectedAnswer === currentQuestion?.answer ? 1 : 0);
    const percentage = Math.round((finalScore / questions.length) * 100);
    
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-4">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold">Quiz Abgeschlossen!</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
            <div className="text-4xl font-bold text-blue-600 mb-2">
              {finalScore} / {questions.length}
            </div>
            <div className="text-lg text-gray-600">
              {percentage}% richtig beantwortet
            </div>
          </div>
          <div className="flex justify-center">
            <Badge 
              variant={percentage >= 80 ? "default" : percentage >= 60 ? "secondary" : "destructive"}
              className="text-sm px-4 py-2"
            >
              {percentage >= 80 ? "Ausgezeichnet!" : percentage >= 60 ? "Gut gemacht!" : "Weiter üben!"}
            </Badge>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <Badge variant="outline">{currentQuestion.topic}</Badge>
          <span className="text-sm text-gray-500">
            Frage {currentIndex + 1} von {questions.length}
          </span>
        </div>
        <Progress value={progress} className="mb-4" />
        <CardTitle className="text-xl leading-relaxed">
          {currentQuestion.question}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3">
          {currentQuestion.options.map((option) => (
            <Button
              key={option}
              variant={
                !isAnswered 
                  ? selectedAnswer === option ? "default" : "outline"
                  : option === currentQuestion.answer
                    ? "default"
                    : selectedAnswer === option && option !== currentQuestion.answer
                      ? "destructive"
                      : "outline"
              }
              className={`justify-start h-auto p-4 text-left transition-all ${
                isAnswered && option === currentQuestion.answer
                  ? "bg-green-500 hover:bg-green-600 text-white"
                  : isAnswered && selectedAnswer === option && option !== currentQuestion.answer
                    ? "bg-red-500 hover:bg-red-600 text-white"
                    : ""
              }`}
              onClick={() => handleAnswerSelect(option)}
              disabled={isAnswered}
            >
              <div className="flex items-center gap-3 w-full">
                {isAnswered && (
                  option === currentQuestion.answer ? (
                    <CheckCircle className="w-5 h-5 shrink-0" />
                  ) : selectedAnswer === option ? (
                    <XCircle className="w-5 h-5 shrink-0" />
                  ) : null
                )}
                <span className="flex-1">{option}</span>
              </div>
            </Button>
          ))}
        </div>
        
        {isAnswered && (
          <div className="pt-4 border-t">
            <Button onClick={handleNext} className="w-full">
              {currentIndex + 1 < questions.length ? 'Nächste Frage' : 'Quiz beenden'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}