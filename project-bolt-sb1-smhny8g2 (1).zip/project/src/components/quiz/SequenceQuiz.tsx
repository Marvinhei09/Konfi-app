import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, ArrowUp, ArrowDown, Shuffle, 
  RotateCcw, Check, Award, MoveVertical
} from 'lucide-react';
import type { Question } from '@/types';

interface SequenceQuizProps {
  question: Question;
  onComplete: (score: number, total: number) => void;
  onBack: () => void;
}

export function SequenceQuiz({ question, onComplete, onBack }: SequenceQuizProps) {
  const [items, setItems] = useState<string[]>([]);
  const [correctSequence, setCorrectSequence] = useState<string[]>([]);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (question.sequence) {
      // Speichere die korrekte Reihenfolge
      setCorrectSequence([...question.sequence]);
      
      // Mische die Elemente für die Anzeige
      const shuffled = [...question.sequence].sort(() => Math.random() - 0.5);
      setItems(shuffled);
    }
  }, [question]);

  const moveItem = (index: number, direction: 'up' | 'down') => {
    if (isSubmitted) return;
    
    const newItems = [...items];
    
    if (direction === 'up' && index > 0) {
      [newItems[index], newItems[index - 1]] = [newItems[index - 1], newItems[index]];
    } else if (direction === 'down' && index < items.length - 1) {
      [newItems[index], newItems[index + 1]] = [newItems[index + 1], newItems[index]];
    }
    
    setItems(newItems);
  };

  const shuffleItems = () => {
    if (isSubmitted) return;
    const shuffled = [...items].sort(() => Math.random() - 0.5);
    setItems(shuffled);
  };

  const resetItems = () => {
    if (isSubmitted) return;
    if (question.sequence) {
      const shuffled = [...question.sequence].sort(() => Math.random() - 0.5);
      setItems(shuffled);
    }
  };

  const handleSubmit = () => {
    // Berechne die Punktzahl basierend auf der Anzahl der korrekt platzierten Elemente
    let correctCount = 0;
    
    for (let i = 0; i < items.length; i++) {
      if (items[i] === correctSequence[i]) {
        correctCount++;
      }
    }
    
    const calculatedScore = Math.round((correctCount / items.length) * 100) / 100;
    setScore(calculatedScore * items.length);
    setIsSubmitted(true);
    
    // Gib die Punktzahl an die übergeordnete Komponente zurück
    onComplete(calculatedScore * items.length, items.length);
  };

  const isCorrectPosition = (index: number): boolean => {
    return isSubmitted && items[index] === correctSequence[index];
  };

  if (items.length === 0) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8 text-center">
          <p className="text-gray-600">Keine Sequenz-Elemente verfügbar.</p>
          <Button onClick={onBack} className="mt-4">Zurück</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <Badge variant="outline">{question.topic}</Badge>
          <div className="flex items-center gap-2">
            <MoveVertical className="w-4 h-4 text-blue-500" />
            <span className="text-sm text-gray-500">
              Ordne {items.length} Elemente
            </span>
          </div>
        </div>
        <CardTitle className="text-xl leading-relaxed mb-4">
          {question.question}
        </CardTitle>
        
        {!isSubmitted && (
          <div className="flex gap-2 mb-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={shuffleItems}
              className="gap-2"
            >
              <Shuffle className="w-4 h-4" />
              Neu mischen
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetItems}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Zurücksetzen
            </Button>
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          {items.map((item, index) => (
            <div 
              key={index}
              className={`flex items-center gap-2 p-4 rounded-lg border-2 ${
                isSubmitted
                  ? isCorrectPosition(index)
                    ? 'border-green-500 bg-green-50'
                    : 'border-red-300 bg-red-50'
                  : 'border-gray-200 bg-white hover:border-blue-300'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-800">
                {index + 1}
              </div>
              
              <div className="flex-1 font-medium">{item}</div>
              
              {!isSubmitted && (
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => moveItem(index, 'up')}
                    disabled={index === 0}
                    className="h-8 w-8 p-0"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => moveItem(index, 'down')}
                    disabled={index === items.length - 1}
                    className="h-8 w-8 p-0"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </Button>
                </div>
              )}
              
              {isSubmitted && (
                <div className="w-8 h-8 flex items-center justify-center">
                  {isCorrectPosition(index) ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <span className="text-xs text-gray-500">
                      #{correctSequence.indexOf(item) + 1}
                    </span>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
        
        {isSubmitted ? (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-2">Ergebnis</h3>
              <div className="flex items-center gap-2 mb-2">
                <Progress value={(score / items.length) * 100} className="flex-1" />
                <span className="font-medium">{Math.round((score / items.length) * 100)}%</span>
              </div>
              <p className="text-blue-700">
                Du hast {Math.round(score)} von {items.length} Elementen richtig platziert.
              </p>
            </div>
            
            <div className="flex gap-2">
              <Button onClick={onBack} className="flex-1 gap-2">
                <Award className="w-4 h-4" />
                Fertig
              </Button>
            </div>
          </div>
        ) : (
          <Button 
            onClick={handleSubmit} 
            className="w-full gap-2"
          >
            <Check className="w-4 h-4" />
            Reihenfolge prüfen
          </Button>
        )}
      </CardContent>
    </Card>
  );
}