import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.konfiapp.app',
  appName: 'Konfi Quiz App',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#f8fafc",
      showSpinner: true,
      spinnerColor: "#3b82f6",
      androidSpinnerStyle: "large"
    }
  }
};

export default config;