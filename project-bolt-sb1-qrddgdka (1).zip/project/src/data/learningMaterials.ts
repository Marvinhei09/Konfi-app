import { LearningMaterial } from '@/types';

export const initialLearningMaterials: LearningMaterial[] = [
  {
    id: '1',
    title: 'Die Zehn Gebote - Übersicht',
    description: 'Eine vollständige Übersicht über die Zehn Gebote mit Erklärungen und Beispielen aus dem Alltag.',
    type: 'pdf',
    fileUrl: 'https://example.com/zehn-gebote.pdf',
    topic: 'Gebote',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['zehn gebote', 'ethik', 'alltag'],
    fileSize: 2048000, // 2MB
    fileName: 'zehn-gebote-übersicht.pdf'
  },
  {
    id: '2',
    title: 'Das Glaubensbekenntnis erklärt',
    description: 'Zusammenfassung der wichtigsten Punkte des apostolischen Glaubensbekenntnisses.',
    type: 'summary',
    content: `# Das Apostolische Glaubensbekenntnis

## Erster Artikel - Gott der Vater
"Ich glaube an Gott, den Vater, den Allmächtigen, den Schöpfer des Himmels und der Erde."

Hier bekennen wir unseren Glauben an Gott als Schöpfer und Vater. Er hat alles geschaffen und sorgt für uns wie ein liebender Vater.

## Zweiter Artikel - Jesus Christus
"Und an Jesus Christus, seinen eingeborenen Sohn, unsern Herrn..."

Jesus ist Gottes Sohn, der Mensch wurde, um uns zu erlösen. Er starb am Kreuz für unsere Sünden und ist auferstanden.

## Dritter Artikel - Der Heilige Geist
"Ich glaube an den Heiligen Geist, die heilige christliche Kirche..."

Der Heilige Geist verbindet uns mit Gott und anderen Christen. Er schenkt uns Glauben und Kraft für das Leben.`,
    topic: 'Glaube',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['glaubensbekenntnis', 'trinität', 'grundlagen']
  },
  {
    id: '3',
    title: 'Bibelkunde - Aufbau der Bibel',
    description: 'Grafische Darstellung des Aufbaus der Bibel mit allen Büchern des Alten und Neuen Testaments.',
    type: 'image',
    fileUrl: 'https://images.pexels.com/photos/1112048/pexels-photo-1112048.jpeg',
    topic: 'Bibel',
    allowedRoles: ['KUZ', 'KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['bibel', 'aufbau', 'bücher', 'übersicht'],
    fileSize: 1024000, // 1MB
    fileName: 'bibel-aufbau.jpg'
  },
  {
    id: '4',
    title: 'Das Leben Jesu - Zeitleiste',
    description: 'Eine detaillierte Zeitleiste mit den wichtigsten Ereignissen im Leben Jesu Christi.',
    type: 'pdf',
    fileUrl: 'https://example.com/jesus-zeitleiste.pdf',
    topic: 'Jesus',
    allowedRoles: ['KUZ', 'KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['jesus', 'zeitleiste', 'leben', 'ereignisse'],
    fileSize: 1536000, // 1.5MB
    fileName: 'jesus-zeitleiste.pdf'
  },
  {
    id: '5',
    title: 'Reformation - Zusammenfassung',
    description: 'Wichtige Fakten und Personen der Reformation für Fortgeschrittene.',
    type: 'summary',
    content: `# Die Reformation

## Was war die Reformation?
Die Reformation war eine Erneuerungsbewegung der Kirche im 16. Jahrhundert, die von Martin Luther ausging.

## Wichtige Personen:
- **Martin Luther** (1483-1546): Begründer der Reformation
- **Johannes Calvin** (1509-1564): Reformator in Genf
- **Huldrych Zwingli** (1484-1531): Reformator in Zürich

## Wichtige Ereignisse:
- **1517**: Luthers 95 Thesen
- **1521**: Reichstag zu Worms
- **1530**: Augsburger Bekenntnis

## Die vier "Sola" der Reformation:
1. **Sola scriptura** - Allein die Schrift
2. **Sola gratia** - Allein aus Gnade
3. **Sola fide** - Allein durch Glauben
4. **Solus Christus** - Allein Christus`,
    topic: 'Kirche',
    allowedRoles: ['KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['reformation', 'martin luther', 'geschichte', 'sola']
  },
  {
    id: '6',
    title: 'Kirchenjahr - Übersicht',
    description: 'Grafische Darstellung des Kirchenjahres mit allen Festen und Zeiten.',
    type: 'image',
    fileUrl: 'https://images.pexels.com/photos/8468/candles-christmas-light-decoration.jpg',
    topic: 'Kirche',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    uploadedBy: 'Marvin.Heiligentag',
    uploadedAt: '2025-01-01',
    tags: ['kirchenjahr', 'feste', 'advent', 'ostern'],
    fileSize: 2048000, // 2MB
    fileName: 'kirchenjahr-übersicht.jpg'
  }
];