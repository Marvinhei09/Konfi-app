import { KonfiRating, RatingAuditLog } from '@/types';

export const initialRatings: KonfiRating[] = [
  {
    id: '1',
    konfiId: '2', // Tim Heiligentag
    lessonDate: '2025-01-15',
    participation: 4, // 4 von 5 Sternen
    socialBehavior: 5, // 5 von 5 Sternen
    customCategory: {
      name: 'Bibelkenntnisse',
      rating: 4 // 4 von 5 Sternen
    },
    comment: 'Tim zeigt großes Interesse und beteiligt sich aktiv am Unterricht. Seine Bibelkenntnisse sind beeindruckend und er hilft anderen Konfirmanden gerne.',
    createdBy: '1', // Marvin Heiligentag (Admin)
    createdAt: '2025-01-15T18:30:00Z'
  },
  {
    id: '2',
    konfiId: '2', // Tim Heiligentag
    lessonDate: '2025-01-22',
    participation: 3, // 3 von 5 Sternen
    socialBehavior: 4, // 4 von 5 Sternen
    comment: 'Tim war heute etwas zurückhaltender als sonst, hat aber trotzdem gut mitgearbeitet. Besonders in der Gruppenarbeit hat er sich positiv eingebracht.',
    createdBy: '3', // Nena (Teamer)
    createdAt: '2025-01-22T18:45:00Z'
  },
  {
    id: '3',
    konfiId: '4', // Anna Müller
    lessonDate: '2025-01-15',
    participation: 5, // 5 von 5 Sternen
    socialBehavior: 4, // 4 von 5 Sternen
    customCategory: {
      name: 'Kreativität',
      rating: 5 // 5 von 5 Sternen
    },
    comment: 'Anna hat heute hervorragend mitgearbeitet und sehr kreative Ideen eingebracht. Sie ist eine große Bereicherung für die Gruppe.',
    createdBy: '1', // Marvin Heiligentag (Admin)
    createdAt: '2025-01-15T18:35:00Z'
  }
];

export const initialRatingAuditLog: RatingAuditLog[] = [
  {
    id: '1',
    ratingId: '1',
    action: 'create',
    userId: '1', // Marvin Heiligentag (Admin)
    timestamp: '2025-01-15T18:30:00Z',
    details: 'Bewertung für Tim Heiligentag erstellt'
  },
  {
    id: '2',
    ratingId: '2',
    action: 'create',
    userId: '3', // Nena (Teamer)
    timestamp: '2025-01-22T18:45:00Z',
    details: 'Bewertung für Tim Heiligentag erstellt'
  },
  {
    id: '3',
    ratingId: '3',
    action: 'create',
    userId: '1', // Marvin Heiligentag (Admin)
    timestamp: '2025-01-15T18:35:00Z',
    details: 'Bewertung für Anna Müller erstellt'
  }
];