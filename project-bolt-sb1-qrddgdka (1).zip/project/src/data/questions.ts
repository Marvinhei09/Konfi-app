import { Question } from '@/types';

export const initialQuestions: Question[] = [
  // Grundwissen - Für alle Rollen
  {
    id: '1',
    question: "Was bedeutet das Wort 'Konfirmation'?",
    options: ["Bestätigung", "Erleuchtung", "Abendmahl", "Taufe"],
    answer: "Bestätigung",
    topic: "Grundwissen",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '2',
    question: "In welchem Alter werden Jugendliche normalerweise konfirmiert?",
    options: ["12-13 Jahre", "14-15 Jahre", "16-17 Jahre", "18-19 Jahre"],
    answer: "14-15 Jahre",
    topic: "Grundwissen",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '3',
    question: "Was ist das Glaubensbekenntnis?",
    options: ["Ein Gebet", "Eine Zusammenfassung des christlichen Glaubens", "Ein Kirchenlied", "Eine Bibelstelle"],
    answer: "Eine Zusammenfassung des christlichen Glaubens",
    topic: "Grundwissen",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },

  // Bibel - Für KUZ und KU8
  {
    id: '4',
    question: "Wer schrieb das Neue Testament?",
    options: ["Die Apostel", "Jesus selbst", "Paulus allein", "Martin Luther"],
    answer: "Die Apostel",
    topic: "Bibel",
    allowedRoles: ['KUZ', 'KU8']
  },
  {
    id: '5',
    question: "Wie viele Bücher hat die Bibel?",
    options: ["66", "73", "39", "27"],
    answer: "66",
    topic: "Bibel",
    allowedRoles: ['KUZ', 'KU8']
  },
  {
    id: '6',
    question: "In welcher Sprache wurde das Neue Testament ursprünglich geschrieben?",
    options: ["Hebräisch", "Aramäisch", "Griechisch", "Lateinisch"],
    answer: "Griechisch",
    topic: "Bibel",
    allowedRoles: ['KU8']
  },

  // Gebote - Für alle Rollen
  {
    id: '7',
    question: "Was ist das wichtigste Gebot im Christentum?",
    options: ["Du sollst nicht töten", "Liebe Gott und deinen Nächsten", "Du sollst nicht stehlen", "Ehre deine Eltern"],
    answer: "Liebe Gott und deinen Nächsten",
    topic: "Gebote",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '8',
    question: "Wie viele Gebote gab Gott Mose?",
    options: ["5", "10", "12", "7"],
    answer: "10",
    topic: "Gebote",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '9',
    question: "Welches ist das erste Gebot?",
    options: ["Du sollst nicht töten", "Du sollst keine anderen Götter haben", "Du sollst nicht stehlen", "Du sollst den Sabbat heiligen"],
    answer: "Du sollst keine anderen Götter haben",
    topic: "Gebote",
    allowedRoles: ['KUZ', 'KU8']
  },

  // Jesus - Für KUZ und KU8
  {
    id: '10',
    question: "In welcher Stadt wurde Jesus geboren?",
    options: ["Jerusalem", "Nazareth", "Bethlehem", "Kapernaum"],
    answer: "Bethlehem",
    topic: "Jesus",
    allowedRoles: ['KUZ', 'KU8']
  },
  {
    id: '11',
    question: "Wie viele Jünger hatte Jesus?",
    options: ["10", "12", "7", "24"],
    answer: "12",
    topic: "Jesus",
    allowedRoles: ['KUZ', 'KU8']
  },
  {
    id: '12',
    question: "Wer taufte Jesus?",
    options: ["Petrus", "Johannes der Täufer", "Paulus", "Andreas"],
    answer: "Johannes der Täufer",
    topic: "Jesus",
    allowedRoles: ['KU8']
  },

  // Kirche - Nur für KU8
  {
    id: '13',
    question: "Wer begründete die Reformation?",
    options: ["Johannes Calvin", "Martin Luther", "Huldrych Zwingli", "Thomas Müntzer"],
    answer: "Martin Luther",
    topic: "Kirche",
    allowedRoles: ['KU8']
  },
  {
    id: '14',
    question: "In welchem Jahr begann die Reformation?",
    options: ["1517", "1520", "1525", "1530"],
    answer: "1517",
    topic: "Kirche",
    allowedRoles: ['KU8']
  },
  {
    id: '15',
    question: "Was sind die beiden Sakramente in der evangelischen Kirche?",
    options: ["Taufe und Konfirmation", "Taufe und Abendmahl", "Abendmahl und Trauung", "Konfirmation und Trauung"],
    answer: "Taufe und Abendmahl",
    topic: "Kirche",
    allowedRoles: ['KU8']
  },

  // Glaube - Für alle Rollen
  {
    id: '16',
    question: "Was bedeutet 'Gnade' im christlichen Glauben?",
    options: ["Gottes unverdiente Liebe", "Menschliche Güte", "Kirchliche Tradition", "Religiöse Pflicht"],
    answer: "Gottes unverdiente Liebe",
    topic: "Glaube",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '17',
    question: "Was ist das Vaterunser?",
    options: ["Ein Kirchenlied", "Das Gebet, das Jesus lehrte", "Ein Psalm", "Ein Glaubensbekenntnis"],
    answer: "Das Gebet, das Jesus lehrte",
    topic: "Glaube",
    allowedRoles: ['KU4', 'KUZ', 'KU8']
  },
  {
    id: '18',
    question: "Was bedeutet 'Trinität'?",
    options: ["Die drei Weisen", "Vater, Sohn und Heiliger Geist", "Die drei Evangelisten", "Die drei Tugenden"],
    answer: "Vater, Sohn und Heiliger Geist",
    topic: "Glaube",
    allowedRoles: ['KUZ', 'KU8']
  },
  
  // Wahr/Falsch-Fragen
  {
    id: '19',
    type: 'true-false',
    question: "Wahr oder Falsch: Aussagen zum christlichen Glauben",
    topic: "Grundwissen",
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    statements: [
      { text: "Die Bibel besteht aus dem Alten und dem Neuen Testament.", isTrue: true },
      { text: "Jesus wurde in Jerusalem geboren.", isTrue: false },
      { text: "Die Bergpredigt wurde von Petrus gehalten.", isTrue: false },
      { text: "Die Zehn Gebote wurden Mose auf dem Berg Sinai gegeben.", isTrue: true },
      { text: "Paulus schrieb alle Bücher des Neuen Testaments.", isTrue: false }
    ]
  },
  {
    id: '20',
    type: 'true-false',
    question: "Wahr oder Falsch: Kirchengeschichte",
    topic: "Kirche",
    allowedRoles: ['KU8'],
    statements: [
      { text: "Martin Luther hat 95 Thesen an die Kirchentür in Wittenberg geschlagen.", isTrue: true },
      { text: "Die Reformation begann im Jahr 1617.", isTrue: false },
      { text: "Die evangelische Kirche kennt sieben Sakramente.", isTrue: false },
      { text: "Martin Luther übersetzte die Bibel ins Deutsche.", isTrue: true },
      { text: "Die Confessio Augustana ist ein wichtiges Bekenntnis der evangelischen Kirche.", isTrue: true }
    ]
  },
  {
    id: '21',
    type: 'true-false',
    question: "Wahr oder Falsch: Jesus und die Evangelien",
    topic: "Jesus",
    allowedRoles: ['KUZ', 'KU8'],
    statements: [
      { text: "Jesus hatte genau zwölf Jünger.", isTrue: true },
      { text: "Die vier Evangelien wurden von Matthäus, Markus, Lukas und Johannes geschrieben.", isTrue: true },
      { text: "Jesus wurde 33 Jahre alt.", isTrue: true },
      { text: "Jesus wurde in Nazareth geboren.", isTrue: false },
      { text: "Jesus hat viele seiner Lehren in Form von Gleichnissen vermittelt.", isTrue: true }
    ]
  },
  
  // Sequenz-Fragen
  {
    id: '22',
    type: 'sequence',
    question: "Bringe die folgenden Ereignisse aus dem Leben Jesu in die richtige Reihenfolge:",
    topic: "Jesus",
    allowedRoles: ['KUZ', 'KU8'],
    sequence: [
      "Geburt in Bethlehem",
      "Taufe durch Johannes den Täufer",
      "Berufung der ersten Jünger",
      "Bergpredigt",
      "Einzug in Jerusalem",
      "Letztes Abendmahl",
      "Kreuzigung",
      "Auferstehung"
    ]
  },
  {
    id: '23',
    type: 'sequence',
    question: "Bringe die Bücher der Bibel in die richtige Reihenfolge:",
    topic: "Bibel",
    allowedRoles: ['KU8'],
    sequence: [
      "1. Mose (Genesis)",
      "2. Mose (Exodus)",
      "Josua",
      "Richter",
      "1. Samuel",
      "Psalmen",
      "Jesaja",
      "Matthäus",
      "Apostelgeschichte",
      "Römer",
      "Offenbarung"
    ]
  },
  {
    id: '24',
    type: 'sequence',
    question: "Bringe die Zehn Gebote in die richtige Reihenfolge:",
    topic: "Gebote",
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    sequence: [
      "Du sollst keine anderen Götter haben neben mir",
      "Du sollst dir kein Bildnis machen",
      "Du sollst den Namen des Herrn nicht missbrauchen",
      "Gedenke des Sabbattages, dass du ihn heiligst",
      "Du sollst deinen Vater und deine Mutter ehren",
      "Du sollst nicht töten",
      "Du sollst nicht ehebrechen",
      "Du sollst nicht stehlen",
      "Du sollst nicht falsch Zeugnis reden",
      "Du sollst nicht begehren deines Nächsten Haus"
    ]
  }
];