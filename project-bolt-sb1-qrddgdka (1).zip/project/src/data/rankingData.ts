import { RankingSettings, RankingAuditLog, RankingCriteria } from '@/types';

export const initialRankingCriteria: RankingCriteria[] = [
  {
    id: '1',
    name: 'Quiz-Leistung',
    weight: 40,
    isActive: true,
    description: 'Durchschnittliche Punktzahl in Quiz und Tests'
  },
  {
    id: '2',
    name: 'Anwesenheit',
    weight: 30,
    isActive: true,
    description: 'Regelmäßige Teilnahme am Konfirmationsunterricht'
  },
  {
    id: '3',
    name: 'Mitarbeit',
    weight: 20,
    isActive: true,
    description: 'Aktive Beteiligung und Engagement im Unterricht'
  },
  {
    id: '4',
    name: 'Lernplattform',
    weight: 10,
    isActive: true,
    description: 'Nutzung der digitalen Lernmaterialien und Karteikarten'
  }
];

export const initialRankingSettings: RankingSettings = {
  isPublicVisible: true,
  updateInterval: 300, // 5 Minuten
  maxDisplayCount: 10,
  criteria: initialRankingCriteria,
  lastUpdated: new Date().toISOString()
};

export const initialAuditLog: RankingAuditLog[] = [
  {
    id: '1',
    timestamp: new Date().toISOString(),
    action: 'score_update',
    adminUser: 'Marvin.Heiligentag',
    details: 'Automatische Aktualisierung der Quiz-Scores',
    affectedUser: 'tim.heiligentag',
    oldValue: 85,
    newValue: 88
  }
];