import { Flashcard } from '@/types';

export const initialFlashcards: Flashcard[] = [
  // Grundwissen - Für alle Rollen
  {
    id: '1',
    topic: 'Grundwissen',
    question: 'Was bedeutet das Wort "Konfirmation"?',
    answer: 'Konfirmation bedeutet "Bestätigung" oder "Bekräftigung". Bei der Konfirmation bestätigen Jugendliche ihren christlichen Glauben und werden als vollwertige Mitglieder der Kirchengemeinde aufgenommen.',
    difficulty: 'easy',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['konfirmation', 'grundlagen', 'bedeutung']
  },
  {
    id: '2',
    topic: 'Grundwissen',
    question: 'Welche beiden Sakramente gibt es in der evangelischen Kirche?',
    answer: 'Die beiden Sakramente in der evangelischen Kirche sind die Taufe und das Abendmahl. Sie wurden von Jesus Christus eingesetzt und sind sichtbare Zeichen der Gnade Gottes.',
    difficulty: 'medium',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['sakramente', 'taufe', 'abendmahl']
  },
  {
    id: '3',
    topic: 'Grundwissen',
    question: 'Was ist das Glaubensbekenntnis?',
    answer: 'Das Glaubensbekenntnis ist eine Zusammenfassung der wichtigsten christlichen Glaubensinhalte. Es bekennt den Glauben an Gott den Vater, Jesus Christus den Sohn und den Heiligen Geist (Trinität).',
    difficulty: 'easy',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['glaubensbekenntnis', 'trinität', 'glaube']
  },

  // Bibel - Für KUZ und KU8
  {
    id: '4',
    topic: 'Bibel',
    question: 'Aus wie vielen Büchern besteht die Bibel?',
    answer: 'Die Bibel besteht aus 66 Büchern: 39 Bücher im Alten Testament und 27 Bücher im Neuen Testament. Sie wurde über einen Zeitraum von etwa 1500 Jahren von verschiedenen Autoren geschrieben.',
    difficulty: 'medium',
    allowedRoles: ['KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['bibel', 'bücher', 'altes testament', 'neues testament']
  },
  {
    id: '5',
    topic: 'Bibel',
    question: 'In welcher Sprache wurde das Neue Testament ursprünglich geschrieben?',
    answer: 'Das Neue Testament wurde ursprünglich in griechischer Sprache (Koine-Griechisch) geschrieben. Das war die Verkehrssprache im östlichen Mittelmeerraum zur Zeit Jesu.',
    difficulty: 'hard',
    allowedRoles: ['KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['neues testament', 'griechisch', 'sprache', 'übersetzung']
  },

  // Gebote - Für alle Rollen
  {
    id: '6',
    topic: 'Gebote',
    question: 'Wie lautet das wichtigste Gebot im Christentum?',
    answer: 'Das wichtigste Gebot lautet: "Du sollst den Herrn, deinen Gott, lieben von ganzem Herzen, von ganzer Seele und von ganzem Gemüt. Das andere aber ist dem gleich: Du sollst deinen Nächsten lieben wie dich selbst." (Matthäus 22,37-39)',
    difficulty: 'medium',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['gebote', 'nächstenliebe', 'gottesliebe', 'jesus']
  },
  {
    id: '7',
    topic: 'Gebote',
    question: 'Wie viele Gebote gab Gott Mose am Berg Sinai?',
    answer: 'Gott gab Mose zehn Gebote am Berg Sinai. Diese Zehn Gebote (Dekalog) sind grundlegende Regeln für das Zusammenleben mit Gott und den Menschen.',
    difficulty: 'easy',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['zehn gebote', 'mose', 'sinai', 'dekalog']
  },

  // Jesus - Für KUZ und KU8
  {
    id: '8',
    topic: 'Jesus',
    question: 'In welcher Stadt wurde Jesus geboren?',
    answer: 'Jesus wurde in Bethlehem geboren. Dies geschah während einer Volkszählung, weshalb Maria und Josef von Nazareth nach Bethlehem reisen mussten.',
    difficulty: 'easy',
    allowedRoles: ['KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['jesus', 'bethlehem', 'geburt', 'weihnachten']
  },
  {
    id: '9',
    topic: 'Jesus',
    question: 'Wer taufte Jesus und wo?',
    answer: 'Jesus wurde von Johannes dem Täufer im Jordan getauft. Bei der Taufe öffnete sich der Himmel und eine Stimme sprach: "Dies ist mein lieber Sohn, an dem ich Wohlgefallen habe."',
    difficulty: 'medium',
    allowedRoles: ['KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['jesus', 'taufe', 'johannes der täufer', 'jordan']
  },

  // Glaube - Für alle Rollen
  {
    id: '10',
    topic: 'Glaube',
    question: 'Was bedeutet "Gnade" im christlichen Glauben?',
    answer: 'Gnade bedeutet Gottes unverdiente Liebe und Vergebung. Menschen können sich Gottes Liebe nicht verdienen - sie ist ein Geschenk, das Gott aus Liebe gibt.',
    difficulty: 'medium',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['gnade', 'vergebung', 'liebe', 'geschenk']
  },
  {
    id: '11',
    topic: 'Glaube',
    question: 'Was ist das Vaterunser?',
    answer: 'Das Vaterunser ist das Gebet, das Jesus seine Jünger gelehrt hat. Es beginnt mit "Vater unser im Himmel" und enthält sieben Bitten, die alle wichtigen Bereiche des Lebens umfassen.',
    difficulty: 'easy',
    allowedRoles: ['KU4', 'KUZ', 'KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['vaterunser', 'gebet', 'jesus', 'bitten']
  },

  // Kirche - Nur für KU8
  {
    id: '12',
    topic: 'Kirche',
    question: 'Wer begründete die Reformation und wann?',
    answer: 'Martin Luther begründete die Reformation im Jahr 1517, als er seine 95 Thesen an die Schlosskirche zu Wittenberg schlug. Er kritisierte Missstände in der katholischen Kirche.',
    difficulty: 'hard',
    allowedRoles: ['KU8'],
    createdBy: 'Marvin.Heiligentag',
    createdAt: '2025-01-01',
    tags: ['reformation', 'martin luther', '1517', 'wittenberg']
  }
];