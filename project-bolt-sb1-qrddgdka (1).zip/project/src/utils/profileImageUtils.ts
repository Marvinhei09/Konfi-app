import { ProfileImageSettings, ProfileImageUpload } from '@/types';

export const DEFAULT_PROFILE_IMAGE_SETTINGS: ProfileImageSettings = {
  maxFileSize: 5 * 1024 * 1024, // 5MB
  allowedFormats: ['image/jpeg', 'image/png', 'image/webp'],
  minDimensions: { width: 200, height: 200 },
  maxDimensions: { width: 2048, height: 2048 },
  compressionQuality: 85,
  enableFilters: true,
  autoResize: true
};

export class ProfileImageManager {
  private static instance: ProfileImageManager;
  private settings: ProfileImageSettings;

  private constructor() {
    this.settings = DEFAULT_PROFILE_IMAGE_SETTINGS;
  }

  public static getInstance(): ProfileImageManager {
    if (!ProfileImageManager.instance) {
      ProfileImageManager.instance = new ProfileImageManager();
    }
    return ProfileImageManager.instance;
  }

  // Generiere Standard-Profilbild (grauer Platzhalter)
  public generateDefaultProfileImage(initials: string, size: number = 150): string {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return '';

    canvas.width = size;
    canvas.height = size;

    // Grauer Hintergrund
    ctx.fillStyle = '#9CA3AF'; // Tailwind gray-400
    ctx.fillRect(0, 0, size, size);

    // Weißer Text (Initialen)
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${size * 0.4}px Inter, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    ctx.fillText(initials.toUpperCase(), size / 2, size / 2);

    return canvas.toDataURL('image/png');
  }

  // Validiere Bilddatei
  public validateImage(file: File): { isValid: boolean; error?: string } {
    // Dateigröße prüfen
    if (file.size > this.settings.maxFileSize) {
      return {
        isValid: false,
        error: `Datei ist zu groß. Maximale Größe: ${this.formatFileSize(this.settings.maxFileSize)}`
      };
    }

    // Dateiformat prüfen
    if (!this.settings.allowedFormats.includes(file.type)) {
      return {
        isValid: false,
        error: `Ungültiges Dateiformat. Erlaubt: ${this.settings.allowedFormats.join(', ')}`
      };
    }

    return { isValid: true };
  }

  // Bild komprimieren und optimieren
  public async processImage(file: File): Promise<ProfileImageUpload> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Canvas-Kontext nicht verfügbar'));
        return;
      }

      img.onload = () => {
        // Berechne optimale Dimensionen
        const { width, height } = this.calculateOptimalDimensions(
          img.width,
          img.height
        );

        canvas.width = width;
        canvas.height = height;

        // Zeichne und komprimiere Bild
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Bildverarbeitung fehlgeschlagen'));
              return;
            }

            const processedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now()
            });

            const result: ProfileImageUpload = {
              file: processedFile,
              preview: canvas.toDataURL('image/jpeg', this.settings.compressionQuality / 100),
              metadata: {
                originalSize: file.size,
                compressedSize: blob.size,
                format: 'image/jpeg',
                dimensions: { width, height }
              },
              filters: {
                brightness: 100,
                contrast: 100,
                saturation: 100,
                blur: 0
              }
            };

            resolve(result);
          },
          'image/jpeg',
          this.settings.compressionQuality / 100
        );
      };

      img.onerror = () => {
        reject(new Error('Bild konnte nicht geladen werden'));
      };

      img.src = URL.createObjectURL(file);
    });
  }

  // Berechne optimale Bildabmessungen
  private calculateOptimalDimensions(originalWidth: number, originalHeight: number): { width: number; height: number } {
    const { maxDimensions, minDimensions } = this.settings;
    
    let width = originalWidth;
    let height = originalHeight;

    // Skaliere runter wenn zu groß
    if (width > maxDimensions.width || height > maxDimensions.height) {
      const ratio = Math.min(
        maxDimensions.width / width,
        maxDimensions.height / height
      );
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }

    // Skaliere hoch wenn zu klein
    if (width < minDimensions.width || height < minDimensions.height) {
      const ratio = Math.max(
        minDimensions.width / width,
        minDimensions.height / height
      );
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }

    return { width, height };
  }

  // Formatiere Dateigröße für Anzeige
  public formatFileSize(bytes: number): string {
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 Bytes';
    
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  }

  // Generiere Initialen aus Namen
  public generateInitials(firstName?: string, lastName?: string, username?: string): string {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`;
    }
    if (username) {
      const parts = username.split('.');
      if (parts.length >= 2) {
        return `${parts[0][0]}${parts[1][0]}`;
      }
      return username.slice(0, 2);
    }
    return 'KU';
  }

  // Prüfe ob Benutzer Profilbild ändern darf
  public canEditProfileImage(userRole: string): boolean {
    return ['admin', 'teamer'].includes(userRole);
  }

  // Erstelle Audit-Log-Eintrag
  public createAuditLogEntry(
    userId: string,
    action: 'upload' | 'update' | 'delete' | 'reset',
    adminUser?: string,
    oldImageUrl?: string,
    newImageUrl?: string,
    fileSize?: number,
    reason?: string
  ) {
    return {
      id: Date.now().toString(),
      userId,
      action,
      timestamp: new Date().toISOString(),
      adminUser,
      oldImageUrl,
      newImageUrl,
      fileSize,
      reason
    };
  }
}