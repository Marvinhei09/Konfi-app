import { useState } from 'react';
import { LoginForm } from './components/auth/LoginForm';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { TeamerDashboard } from './components/teamer/TeamerDashboard';
import { StudentDashboard } from './components/student/StudentDashboard';
import { LearningDashboard } from './components/learning/LearningDashboard';
import { EmergencyChatManager } from './components/chat/EmergencyChatManager';
import { QRScannerApp } from './components/scanner/QRScannerApp';
import { ParentDashboard } from './components/parent/ParentDashboard';
import { initialQuestions } from './data/questions';
import { initialContacts } from './data/contacts';
import { initialPasses } from './data/passes';
import { initialFlashcards } from './data/flashcards';
import { initialLearningMaterials } from './data/learningMaterials';
import { initialRatings } from './data/ratings';
import { users as initialUsers } from './data/users';
import type { User, Question, QuizHistory, CalendarEvent, KonfiContact, KonfiPass, Flashcard, LearningMaterial, StudySession, KonfiRating, RatingAuditLog } from './types';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [questions, setQuestions] = useState<Question[]>(initialQuestions);
  const [history, setHistory] = useState<QuizHistory[]>([]);
  const [contacts, setContacts] = useState<KonfiContact[]>(initialContacts);
  const [passes, setPasses] = useState<KonfiPass[]>(initialPasses);
  const [flashcards, setFlashcards] = useState<Flashcard[]>(initialFlashcards);
  const [learningMaterials, setLearningMaterials] = useState<LearningMaterial[]>(initialLearningMaterials);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [ratings, setRatings] = useState<KonfiRating[]>(initialRatings);
  const [ratingAuditLog, setRatingAuditLog] = useState<RatingAuditLog[]>([]);
  const [currentView, setCurrentView] = useState<'dashboard' | 'learning' | 'emergency-chat' | 'scanner'>('dashboard');
  const [churchLogo, setChurchLogo] = useState<string | undefined>(undefined);
  const [events, setEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      date: '2025-02-15',
      title: 'Konfirmandenstunde KU8',
      description: 'Thema: Die Zehn Gebote',
      allowedRoles: ['KU8']
    },
    {
      id: '2', 
      date: '2025-02-22',
      title: 'Gottesdienst mit Konfis',
      description: 'Mitwirkung der Konfirmanden'
      // No allowedRoles = visible for all
    },
    {
      id: '3',
      date: '2025-02-28',
      title: 'KU4 Gruppenstunde',
      description: 'Erste Schritte im Glauben',
      allowedRoles: ['KU4']
    },
    {
      id: '4',
      date: '2025-03-05',
      title: 'Teamer-Meeting',
      description: 'Planung der nächsten Aktivitäten',
      allowedRoles: ['teamer']
    },
    {
      id: '5',
      date: '2025-03-10',
      title: 'Pastor-Konferenz',
      description: 'Austausch über Seelsorge und Gemeindearbeit',
      allowedRoles: ['pastor']
    }
  ]);

  const handleLogin = (user: User) => {
    setUser(user);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('dashboard');
  };

  const handleQuizComplete = (result: Omit<QuizHistory, 'id'>) => {
    const newResult: QuizHistory = {
      ...result,
      id: Date.now().toString()
    };
    setHistory(prev => [...prev, newResult]);

    // Update user quiz score based on recent performance
    if (user) {
      const userQuizzes = [...history, newResult].filter(h => h.user === user.username);
      const averageScore = userQuizzes.length > 0 
        ? Math.round((userQuizzes.reduce((sum, h) => sum + (h.points / h.max), 0) / userQuizzes.length) * 100)
        : 0;
      
      const updatedUsers = users.map(u => 
        u.id === user.id ? { ...u, quizScore: averageScore } : u
      );
      setUsers(updatedUsers);
      
      // Update current user
      setUser({...user, quizScore: averageScore});
    }
  };

  const handlePasswordChange = (userId: string, newPassword: string) => {
    setUsers(prev => prev.map(u => 
      u.id === userId ? { ...u, password: newPassword } : u
    ));
    
    // Update current user if they changed their own password
    if (user && user.id === userId) {
      setUser({ ...user, password: newPassword });
    }
  };

  const handleNavigateToEmergencyChat = () => {
    // Check if emergency chat is available
    const emergencyChatAvailable = users.some(u => 
      (u.role === 'teamer' || u.role === 'pastor') && 
      u.isAvailableForEmergency
    );
    
    if (emergencyChatAvailable) {
      setCurrentView('emergency-chat');
    } else if (user?.role === 'konfi') {
      // Show an alert for students that no one is available
      alert('Derzeit ist kein Betreuer für den Notfall-Chat verfügbar. Bitte versuche es später noch einmal oder wende dich direkt an einen Betreuer.');
    }
  };

  // Get children for parent dashboard
  const getChildrenForParent = (parentId: string): KonfiContact[] => {
    const parent = users.find(u => u.id === parentId);
    if (!parent || !parent.childrenIds || parent.childrenIds.length === 0) {
      return [];
    }
    
    // Get child users
    const childUsers = users.filter(u => parent.childrenIds?.includes(u.id));
    
    // Get corresponding contacts
    return contacts.filter(c => 
      childUsers.some(u => u.username === c.username)
    );
  };

  if (!user) {
    return <LoginForm onLogin={handleLogin} users={users} />;
  }

  if (currentView === 'emergency-chat') {
    return (
      <EmergencyChatManager
        currentUser={user}
        users={users}
        onBack={() => setCurrentView('dashboard')}
      />
    );
  }

  if (currentView === 'learning') {
    return (
      <LearningDashboard
        flashcards={flashcards}
        onFlashcardsChange={setFlashcards}
        materials={learningMaterials}
        onMaterialsChange={setLearningMaterials}
        studySessions={studySessions}
        onStudySessionsChange={setStudySessions}
        currentUser={user}
        onBack={() => setCurrentView('dashboard')}
      />
    );
  }

  if (currentView === 'scanner') {
    return (
      <QRScannerApp />
    );
  }

  // Parent Dashboard
  if (user.role === 'parent') {
    const children = getChildrenForParent(user.id);
    
    return (
      <ParentDashboard
        user={user}
        children={children}
        questions={questions}
        history={history}
        events={events}
        passes={passes}
        contacts={contacts}
        users={users}
        onEmergencyChat={handleNavigateToEmergencyChat}
        onLogout={handleLogout}
      />
    );
  }

  if (user.role === 'admin') {
    return (
      <AdminDashboard
        questions={questions}
        onQuestionsChange={setQuestions}
        history={history}
        events={events}
        onEventsChange={setEvents}
        contacts={contacts}
        onContactsChange={setContacts}
        passes={passes}
        onPassesChange={setPasses}
        users={users}
        onUsersChange={setUsers}
        flashcards={flashcards}
        onFlashcardsChange={setFlashcards}
        learningMaterials={learningMaterials}
        onLearningMaterialsChange={setLearningMaterials}
        ratings={ratings}
        onRatingsChange={setRatings}
        ratingAuditLog={ratingAuditLog}
        onRatingAuditLogChange={setRatingAuditLog}
        onNavigateToLearning={() => setCurrentView('learning')}
        onEmergencyChat={handleNavigateToEmergencyChat}
        onLogout={handleLogout}
      />
    );
  }

  if (user.role === 'teamer') {
    return (
      <TeamerDashboard
        questions={questions}
        onQuestionsChange={setQuestions}
        history={history}
        events={events}
        onEventsChange={setEvents}
        contacts={contacts}
        passes={passes}
        onPassesChange={setPasses}
        flashcards={flashcards}
        onFlashcardsChange={setFlashcards}
        learningMaterials={learningMaterials}
        onLearningMaterialsChange={setLearningMaterials}
        users={users}
        onNavigateToLearning={() => setCurrentView('learning')}
        onEmergencyChat={handleNavigateToEmergencyChat}
        onLogout={handleLogout}
      />
    );
  }

  if (user.role === 'pastor') {
    // Pastoren verwenden das gleiche Dashboard wie Teamer, aber mit erweiterten Rechten
    return (
      <TeamerDashboard
        questions={questions}
        onQuestionsChange={setQuestions}
        history={history}
        events={events}
        onEventsChange={setEvents}
        contacts={contacts}
        passes={passes}
        onPassesChange={setPasses}
        flashcards={flashcards}
        onFlashcardsChange={setFlashcards}
        learningMaterials={learningMaterials}
        onLearningMaterialsChange={setLearningMaterials}
        users={users}
        onNavigateToLearning={() => setCurrentView('learning')}
        onEmergencyChat={handleNavigateToEmergencyChat}
        onLogout={handleLogout}
      />
    );
  }

  // Check if emergency chat is available for students
  const emergencyChatAvailable = users.some(u => 
    (u.role === 'teamer' || u.role === 'pastor') && 
    u.isAvailableForEmergency
  );

  return (
    <StudentDashboard
      user={user}
      questions={questions}
      history={history}
      events={events}
      passes={passes}
      contacts={contacts}
      users={users}
      onUsersChange={setUsers}
      onQuizComplete={handleQuizComplete}
      onPasswordChange={(newPassword) => handlePasswordChange(user.id, newPassword)}
      onNavigateToLearning={() => setCurrentView('learning')}
      onEmergencyChat={emergencyChatAvailable ? handleNavigateToEmergencyChat : undefined}
      onLogout={handleLogout}
    />
  );
}

export default App;