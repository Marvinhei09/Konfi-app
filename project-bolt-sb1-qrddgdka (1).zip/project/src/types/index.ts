export interface User {
  id: string;
  username: string;
  password: string;
  role: 'admin' | 'konfi' | 'teamer' | 'pastor' | 'parent'; // Parent-Rolle hinzugefügt
  konfiRole?: 'KU4' | 'KUZ' | 'KU8'; // Konfirmanden-Rollen
  profileImage?: string; // URL zum Profilbild
  firstName?: string;
  lastName?: string;
  // Ranking-spezifische Felder
  quizScore?: number;
  attendanceScore?: number;
  participationScore?: number;
  totalScore?: number;
  rank?: number;
  lastActive?: string;
  // Neue Felder für Profilbilder
  hasCustomProfileImage?: boolean;
  profileImageUploadedAt?: string;
  profileImageSize?: number;
  trend?: 'up' | 'down' | 'same';
  previousRank?: number;
  // Pastor-spezifische Felder
  isAvailableForEmergency?: boolean;
  specializations?: string[]; // z.B. ["Seelsorge", "Krisenintervention", "Familienberatung"]
  emergencyContactInfo?: {
    phone?: string;
    email?: string;
    availableHours?: string;
  };
  // Eltern-spezifische Felder
  childrenIds?: string[]; // IDs der Kinder (User-IDs der Konfirmanden)
  // Neues Feld für Eltern-Passwort
  parentPassword?: string;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  answer: string;
  topic: string;
  allowedRoles?: ('KU4' | 'KUZ' | 'KU8')[]; // Welche Konfi-Rollen diese Frage sehen dürfen
  type?: 'multiple-choice' | 'true-false' | 'sequence'; // Neuer Fragetyp
  statements?: { text: string; isTrue: boolean }[]; // Für Wahr/Falsch-Fragen
  sequence?: string[]; // Für Sequenz-Fragen (richtige Reihenfolge)
}

export interface QuizHistory {
  id: string;
  user: string;
  date: string;
  points: number;
  max: number;
  category?: string;
}

export interface CalendarEvent {
  id: string;
  date: string;
  title: string;
  description?: string;
  allowedRoles?: ('KU4' | 'KUZ' | 'KU8' | 'teamer' | 'pastor' | 'parent')[]; // Parent-Rolle hinzugefügt
}

export interface KonfiContact {
  id: string;
  username: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  address: {
    street: string;
    postalCode: string;
    city: string;
  };
  phone: string;
  email?: string;
  parentName?: string;
  parentPhone?: string;
  notes?: string;
  konfiRole?: 'KU4' | 'KUZ' | 'KU8';
  parentIds?: string[]; // IDs der Eltern (User-IDs)
}

export interface ActivitySignature {
  id: string;
  konfiUsername: string;
  activityType: 'konfirmationsunterricht' | 'gottesdienst' | 'kirchliche_aktivitaet';
  activityTitle: string;
  date: string;
  time: string;
  adminSignature: string; // Admin username who signed
  comments?: string;
  location?: string;
}

export interface ActivityRequirement {
  type: 'konfirmationsunterricht' | 'gottesdienst' | 'kirchliche_aktivitaet';
  title: string;
  required: number;
  description: string;
}

export interface KonfiPass {
  id: string;
  konfiUsername: string;
  qrCode: string;
  signatures: ActivitySignature[];
  createdAt: string;
  isActive: boolean;
}

// Neue Typen für die Lernplattform
export interface Flashcard {
  id: string;
  topic: string;
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  allowedRoles?: ('KU4' | 'KUZ' | 'KU8')[];
  createdBy: string;
  createdAt: string;
  tags: string[];
}

export interface LearningMaterial {
  id: string;
  title: string;
  description: string;
  type: 'pdf' | 'image' | 'summary' | 'video' | 'audio';
  fileUrl?: string;
  content?: string; // For summaries
  topic: string;
  allowedRoles?: ('KU4' | 'KUZ' | 'KU8')[];
  uploadedBy: string;
  uploadedAt: string;
  tags: string[];
  fileSize?: number;
  fileName?: string;
}

export interface StudySession {
  id: string;
  userId: string;
  topic: string;
  flashcardsStudied: string[];
  correctAnswers: number;
  totalAnswers: number;
  duration: number; // in minutes
  date: string;
}

export interface LearningProgress {
  userId: string;
  topic: string;
  masteredFlashcards: string[];
  studySessions: number;
  totalTimeSpent: number; // in minutes
  lastStudied: string;
  averageScore: number;
}

// Neue Typen für das Ranking-System
export interface RankingCriteria {
  id: string;
  name: string;
  weight: number; // 0-100%
  isActive: boolean;
  description: string;
}

export interface RankingSettings {
  isPublicVisible: boolean;
  updateInterval: number; // in seconds
  maxDisplayCount: number;
  criteria: RankingCriteria[];
  lastUpdated: string;
}

export interface RankingEntry {
  userId: string;
  username: string;
  firstName?: string;
  lastName?: string;
  profileImage?: string;
  role: 'admin' | 'konfi' | 'teamer' | 'pastor' | 'parent';
  konfiRole?: 'KU4' | 'KUZ' | 'KU8';
  scores: {
    quiz: number;
    attendance: number;
    participation: number;
    learning: number;
  };
  totalScore: number;
  rank: number;
  previousRank?: number;
  trend: 'up' | 'down' | 'same';
  lastActive: string;
}

export interface RankingAuditLog {
  id: string;
  timestamp: string;
  action: 'score_update' | 'criteria_change' | 'visibility_toggle' | 'manual_override';
  adminUser: string;
  details: string;
  affectedUser?: string;
  oldValue?: any;
  newValue?: any;
}

// Erweiterte Typen für Profilbilder
export interface ProfileImageUpload {
  file: File;
  preview: string;
  cropData?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  filters?: {
    brightness: number;
    contrast: number;
    saturation: number;
    blur: number;
  };
  metadata?: {
    originalSize: number;
    compressedSize: number;
    format: string;
    dimensions: {
      width: number;
      height: number;
    };
  };
}

export interface ProfileImageSettings {
  maxFileSize: number; // in bytes
  allowedFormats: string[];
  minDimensions: {
    width: number;
    height: number;
  };
  maxDimensions: {
    width: number;
    height: number;
  };
  compressionQuality: number; // 0-100
  enableFilters: boolean;
  autoResize: boolean;
}

export interface ProfileImageAuditLog {
  id: string;
  userId: string;
  action: 'upload' | 'update' | 'delete' | 'reset';
  timestamp: string;
  adminUser?: string;
  oldImageUrl?: string;
  newImageUrl?: string;
  fileSize?: number;
  reason?: string;
}

// Neue Typen für die Fachbezeichnung-Verwaltung
export interface FachbezeichnungSettings {
  id: string;
  ku4ToKuzDate: string; // Datum für KU4 → KUZ Wechsel
  kuzToKu8Date: string; // Datum für KUZ → KU8 Wechsel
  isActive: boolean;
  lastUpdated: string;
  createdBy: string;
}

export interface FachbezeichnungHistory {
  id: string;
  userId: string;
  oldDesignation: string;
  newDesignation: string;
  changeDate: string;
  reason: 'automatic' | 'manual';
  changedBy: string;
}

export type KonfiRoleExtended = 'KU4' | 'KUZ5' | 'KUZ6' | 'KUZ7' | 'KU8';

export interface UserExtended extends Omit<User, 'konfiRole'> {
  konfiRole?: KonfiRoleExtended;
  originalKonfiRole?: 'KU4' | 'KUZ' | 'KU8'; // Ursprüngliche Rolle für Tracking
  enrollmentDate?: string; // Einschreibungsdatum
  gradeLevel?: number; // Aktuelle Klassenstufe (4-8)
}

// Notfall-Chat System Typen
export interface EmergencyChat {
  id: string;
  initiatorId: string; // Konfirmand
  supervisorId: string; // Teamer oder Pastor
  category: 'mobbing' | 'family' | 'health' | 'safety' | 'spiritual' | 'other';
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'active' | 'escalated' | 'resolved' | 'closed';
  createdAt: string;
  lastActivity: string;
  encryptionKey: string;
  isEncrypted: boolean;
  escalatedTo?: string; // Pastor ID bei Eskalation
  escalatedAt?: string;
  escalationReason?: string;
  escalatedBy?: string; // Teamer der eskaliert hat
  metadata: {
    autoDeleteAt: string; // 30 Tage nach Erstellung
    participantCount: number;
    messageCount: number;
    hasBeenEscalated: boolean;
  };
}

export interface EmergencyMessage {
  id: string;
  chatId: string;
  senderId: string;
  content: string; // Verschlüsselter Inhalt
  timestamp: string;
  isRead: boolean;
  messageType: 'text' | 'system' | 'escalation';
  encryptedContent?: string;
  iv?: string; // Initialization Vector für Verschlüsselung
}

export interface EmergencySupervisor {
  id: string;
  userId: string;
  role: 'teamer' | 'pastor';
  isAvailable: boolean;
  currentChats: string[]; // Chat IDs
  maxConcurrentChats: number;
  specializations: string[];
  workingHours: {
    start: string;
    end: string;
    days: number[]; // 0-6 (Sonntag-Samstag)
  };
  emergencyContact: {
    phone?: string;
    email?: string;
    isAvailable24h: boolean;
  };
  lastSeen: string;
  status: 'available' | 'busy' | 'offline' | 'emergency_only';
}

export interface EmergencyEscalation {
  id: string;
  chatId: string;
  fromSupervisorId: string; // Teamer
  toPastorId: string; // Pastor
  reason: string;
  escalatedAt: string;
  priority: 'high' | 'critical';
  context: string; // Zusammenfassung für Pastor
  isAccepted: boolean;
  acceptedAt?: string;
  handoverNotes?: string;
}

export interface EmergencyAuditLog {
  id: string;
  chatId: string;
  action: 'chat_created' | 'message_sent' | 'chat_escalated' | 'chat_closed' | 'supervisor_joined' | 'auto_deleted';
  userId: string;
  timestamp: string;
  details: string;
  ipAddress?: string; // Nur für Sicherheitsanalyse
  userAgent?: string;
}

export interface EmergencySettings {
  autoDeleteDays: number; // Standard: 30 Tage
  maxConcurrentChatsPerSupervisor: number;
  enableEncryption: boolean;
  requireEscalationApproval: boolean;
  emergencyHotlines: {
    name: string;
    phone: string;
    description: string;
    available24h: boolean;
  }[];
  notificationSettings: {
    emailNotifications: boolean;
    smsNotifications: boolean;
    pushNotifications: boolean;
  };
}

// Neue Typen für Eltern-Funktionen
export interface ParentNotification {
  id: string;
  parentId: string;
  childId: string;
  type: 'attendance' | 'quiz' | 'event' | 'general';
  title: string;
  message: string;
  date: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
  actionRequired: boolean;
  actionUrl?: string;
}

export interface ParentMessage {
  id: string;
  parentId: string;
  teacherId: string;
  subject: string;
  content: string;
  sentAt: string;
  isRead: boolean;
  attachments?: {
    name: string;
    url: string;
    type: string;
    size: number;
  }[];
}

export interface ParentSettings {
  id: string;
  parentId: string;
  emailNotifications: boolean;
  smsNotifications: boolean;
  attendanceAlerts: boolean;
  quizAlerts: boolean;
  eventReminders: boolean;
  reminderDays: number; // Tage vor einem Ereignis
  language: 'de' | 'en';
}

export interface ParentChildLink {
  id: string;
  parentId: string;
  childId: string;
  relationship: 'mother' | 'father' | 'guardian' | 'other';
  isPrimary: boolean;
  hasFullAccess: boolean;
  createdAt: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

// Neue Typen für das Bewertungssystem
export interface KonfiRating {
  id: string;
  konfiId: string;
  lessonDate: string;
  participation: number; // 1-5 Sterne
  socialBehavior: number; // 1-5 Sterne
  customCategory?: {
    name: string;
    rating: number; // 1-5 Sterne
  };
  comment: string;
  createdBy: string;
  createdAt: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface RatingAuditLog {
  id: string;
  ratingId: string;
  action: 'create' | 'update' | 'delete';
  userId: string;
  timestamp: string;
  details: string;
  oldValues?: Partial<KonfiRating>;
  newValues?: Partial<KonfiRating>;
}

export interface RatingStats {
  konfiId: string;
  averageParticipation: number;
  averageSocialBehavior: number;
  customCategoryAverages: {
    [category: string]: number;
  };
  totalRatings: number;
  lastRatingDate: string;
  trend: 'improving' | 'stable' | 'declining';
}