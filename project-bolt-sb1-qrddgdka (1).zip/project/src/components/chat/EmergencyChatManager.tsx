import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  MessageSquare, Plus, Clock, User as UserIcon, Shield, AlertTriangle, 
  Heart, Phone, Users, ArrowUp, CheckCircle, X, Crown,
  UserCheck, Mail, Calendar, Star, Bell, Timer, Eye, Trash2
} from 'lucide-react';
import { EmergencyChatInterface } from './EmergencyChatInterface';
import { EmergencyChatEncryption } from '@/utils/emergencyChatEncryption';
import type { 
  EmergencyChat, 
  EmergencyMessage, 
  EmergencySupervisor, 
  User,
  EmergencyEscalation 
} from '@/types';

interface EmergencyChatManagerProps {
  currentUser: User;
  users: User[];
  onBack: () => void;
}

interface ChatRequest {
  id: string;
  initiatorId: string;
  category: string;
  priority: string;
  description: string;
  createdAt: string;
  status: 'waiting' | 'accepted' | 'expired';
  acceptedBy?: string;
  acceptedAt?: string;
  expiresAt: string;
}

export function EmergencyChatManager({ currentUser, users, onBack }: EmergencyChatManagerProps) {
  const [chats, setChats] = useState<EmergencyChat[]>([]);
  const [messages, setMessages] = useState<EmergencyMessage[]>([]);
  const [supervisors, setSupervisors] = useState<EmergencySupervisor[]>([]);
  const [selectedChat, setSelectedChat] = useState<EmergencyChat | null>(null);
  const [showNewChatForm, setShowNewChatForm] = useState(false);
  const [escalations, setEscalations] = useState<EmergencyEscalation[]>([]);
  const [chatRequests, setChatRequests] = useState<ChatRequest[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedPriority, setSelectedPriority] = useState('medium');
  const [requestDescription, setRequestDescription] = useState('');
  
  const encryption = new EmergencyChatEncryption();

  // Initialisiere Supervisors basierend auf Benutzern
  useEffect(() => {
    const supervisorUsers = users.filter(u => u.role === 'teamer' || u.role === 'pastor');
    const supervisorData: EmergencySupervisor[] = supervisorUsers.map(user => ({
      id: user.id,
      userId: user.id,
      role: user.role as 'teamer' | 'pastor',
      isAvailable: user.isAvailableForEmergency || false,
      currentChats: [],
      maxConcurrentChats: user.role === 'pastor' ? 5 : 3,
      specializations: user.specializations || [],
      workingHours: {
        start: '09:00',
        end: '17:00',
        days: [1, 2, 3, 4, 5] // Mo-Fr
      },
      emergencyContact: {
        phone: user.emergencyContactInfo?.phone,
        email: user.emergencyContactInfo?.email,
        isAvailable24h: user.role === 'pastor'
      },
      lastSeen: user.lastActive || new Date().toISOString(),
      status: user.isAvailableForEmergency ? 'available' : 'offline'
    }));
    
    setSupervisors(supervisorData);
  }, [users]);

  // Automatisches Ablaufen von Chat-Anfragen nach 10 Minuten
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setChatRequests(prev => prev.map(request => 
        new Date(request.expiresAt) < now && request.status === 'waiting'
          ? { ...request, status: 'expired' }
          : request
      ));
    }, 30000); // Alle 30 Sekunden prüfen

    return () => clearInterval(interval);
  }, []);

  const handleCreateChatRequest = () => {
    if (!selectedCategory || !requestDescription.trim()) return;

    const newRequest: ChatRequest = {
      id: Date.now().toString(),
      initiatorId: currentUser.id,
      category: selectedCategory,
      priority: selectedPriority,
      description: requestDescription,
      createdAt: new Date().toISOString(),
      status: 'waiting',
      expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString() // 10 Minuten
    };

    setChatRequests(prev => [...prev, newRequest]);
    setShowNewChatForm(false);
    setSelectedCategory('');
    setRequestDescription('');
    setSelectedPriority('medium');

    // Simuliere Benachrichtigung an alle Teamer
    console.log('🔔 Benachrichtigung an alle verfügbaren Teamer gesendet!');
  };

  const handleAcceptChatRequest = (requestId: string) => {
    const request = chatRequests.find(r => r.id === requestId);
    if (!request || request.status !== 'waiting') return;

    // Markiere Anfrage als akzeptiert
    setChatRequests(prev => prev.map(r => 
      r.id === requestId 
        ? { ...r, status: 'accepted', acceptedBy: currentUser.id, acceptedAt: new Date().toISOString() }
        : r
    ));

    // Erstelle neuen Chat
    const newChat: EmergencyChat = {
      id: Date.now().toString(),
      initiatorId: request.initiatorId,
      supervisorId: currentUser.id,
      category: request.category as any,
      priority: request.priority as any,
      status: 'active',
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      encryptionKey: encryption.generateKey(),
      isEncrypted: true,
      metadata: {
        autoDeleteAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 Tage
        participantCount: 2,
        messageCount: 0,
        hasBeenEscalated: false
      }
    };

    setChats(prev => [...prev, newChat]);
    setSelectedChat(newChat);

    // System-Nachricht hinzufügen
    const systemMessage: EmergencyMessage = {
      id: Date.now().toString(),
      chatId: newChat.id,
      senderId: 'system',
      content: `${currentUser.firstName} ${currentUser.lastName} (Teamer) hat Ihre Anfrage angenommen. Alle Nachrichten sind Ende-zu-Ende verschlüsselt.`,
      timestamp: new Date().toISOString(),
      isRead: false,
      messageType: 'system'
    };

    setMessages(prev => [...prev, systemMessage]);
  };

  const handleDeleteRequest = (requestId: string) => {
    setChatRequests(prev => prev.filter(r => r.id !== requestId));
  };

  const handleSendMessage = (content: string) => {
    if (!selectedChat) return;

    const newMessage: EmergencyMessage = {
      id: Date.now().toString(),
      chatId: selectedChat.id,
      senderId: currentUser.id,
      content,
      timestamp: new Date().toISOString(),
      isRead: false,
      messageType: 'text'
    };

    setMessages(prev => [...prev, newMessage]);
    
    // Update chat metadata
    setChats(prev => prev.map(chat => 
      chat.id === selectedChat.id 
        ? { 
            ...chat, 
            lastActivity: new Date().toISOString(),
            metadata: { 
              ...chat.metadata, 
              messageCount: chat.metadata.messageCount + 1 
            }
          }
        : chat
    ));
  };

  const handleEscalateChat = (escalation: Omit<EmergencyEscalation, 'id'>) => {
    const newEscalation: EmergencyEscalation = {
      ...escalation,
      id: Date.now().toString()
    };

    setEscalations(prev => [...prev, newEscalation]);

    // Update chat status
    setChats(prev => prev.map(chat => 
      chat.id === escalation.chatId 
        ? { 
            ...chat, 
            status: 'escalated',
            escalatedTo: escalation.toPastorId,
            escalatedAt: escalation.escalatedAt,
            escalationReason: escalation.reason,
            escalatedBy: escalation.fromSupervisorId,
            metadata: { 
              ...chat.metadata, 
              hasBeenEscalated: true 
            }
          }
        : chat
    ));

    // System-Nachricht für Eskalation
    const escalationMessage: EmergencyMessage = {
      id: Date.now().toString(),
      chatId: escalation.chatId,
      senderId: 'system',
      content: `Chat wurde an Pastor weitergeleitet. Grund: ${escalation.reason}`,
      timestamp: new Date().toISOString(),
      isRead: false,
      messageType: 'escalation'
    };

    setMessages(prev => [...prev, escalationMessage]);
  };

  const handleCloseChat = () => {
    if (!selectedChat) return;

    setChats(prev => prev.map(chat => 
      chat.id === selectedChat.id 
        ? { ...chat, status: 'closed' }
        : chat
    ));

    setSelectedChat(null);
  };

  const getOtherParticipant = (chat: EmergencyChat): User => {
    const otherUserId = chat.initiatorId === currentUser.id ? chat.supervisorId : chat.initiatorId;
    return users.find(u => u.id === otherUserId) || currentUser;
  };

  const getChatMessages = (chatId: string) => {
    return messages.filter(m => m.chatId === chatId);
  };

  const userChats = chats.filter(chat => 
    chat.initiatorId === currentUser.id || chat.supervisorId === currentUser.id
  );

  // Für Teamer: Zeige wartende Anfragen
  const waitingRequests = chatRequests.filter(r => r.status === 'waiting');
  const myAcceptedRequests = chatRequests.filter(r => r.acceptedBy === currentUser.id);

  // Für Konfirmanden: Zeige eigene Anfragen
  const myRequests = chatRequests.filter(r => r.initiatorId === currentUser.id);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'mobbing': return <Users className="w-4 h-4" />;
      case 'family': return <Heart className="w-4 h-4" />;
      case 'health': return <Heart className="w-4 h-4" />;
      case 'safety': return <Shield className="w-4 h-4" />;
      case 'spiritual': return <Star className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'mobbing': return 'Mobbing/Konflikte';
      case 'family': return 'Familie/Zuhause';
      case 'health': return 'Gesundheit/Wohlbefinden';
      case 'safety': return 'Sicherheit/Gefahr';
      case 'spiritual': return 'Glaube/Spiritualität';
      default: return 'Sonstiges';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();
    
    if (diff <= 0) return 'Abgelaufen';
    
    const minutes = Math.floor(diff / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (selectedChat) {
    return (
      <EmergencyChatInterface
        chat={selectedChat}
        messages={getChatMessages(selectedChat.id)}
        currentUser={currentUser}
        otherParticipant={getOtherParticipant(selectedChat)}
        supervisors={supervisors}
        onSendMessage={handleSendMessage}
        onEscalateChat={handleEscalateChat}
        onCloseChat={handleCloseChat}
        onBack={() => setSelectedChat(null)}
      />
    );
  }

  if (showNewChatForm && currentUser.role === 'konfi') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="outline" onClick={() => setShowNewChatForm(false)} className="gap-2">
              <X className="w-4 h-4" />
              Zurück
            </Button>
            <h1 className="text-2xl font-bold">Hilfe anfordern</h1>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Kategorie-Auswahl */}
            <Card>
              <CardHeader>
                <CardTitle>Worum geht es?</CardTitle>
                <p className="text-sm text-gray-600">
                  Alle verfügbaren Teamer werden benachrichtigt und können Ihnen helfen
                </p>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { id: 'mobbing', label: 'Mobbing/Konflikte', icon: Users, description: 'Probleme mit anderen Personen' },
                  { id: 'family', label: 'Familie/Zuhause', icon: Heart, description: 'Familiäre Schwierigkeiten' },
                  { id: 'health', label: 'Gesundheit/Wohlbefinden', icon: Heart, description: 'Körperliche oder seelische Probleme' },
                  { id: 'safety', label: 'Sicherheit/Gefahr', icon: Shield, description: 'Bedrohung oder Gefahr' },
                  { id: 'spiritual', label: 'Glaube/Spiritualität', icon: Star, description: 'Glaubensfragen oder spirituelle Themen' },
                  { id: 'other', label: 'Sonstiges', icon: MessageSquare, description: 'Andere Anliegen' }
                ].map((category) => (
                  <Card 
                    key={category.id}
                    className={`cursor-pointer transition-colors border-2 ${
                      selectedCategory === category.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <category.icon className="w-5 h-5 text-blue-600" />
                        <div>
                          <h4 className="font-semibold">{category.label}</h4>
                          <p className="text-sm text-gray-600">{category.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            {/* Anfrage-Details */}
            <Card>
              <CardHeader>
                <CardTitle>Ihre Anfrage</CardTitle>
                <p className="text-sm text-gray-600">
                  Beschreiben Sie kurz, womit Sie Hilfe benötigen
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Priorität */}
                <div>
                  <label className="block text-sm font-medium mb-2">Dringlichkeit</label>
                  <div className="grid gap-2">
                    {[
                      { id: 'low', label: 'Niedrig', description: 'Kann warten', color: 'green' },
                      { id: 'medium', label: 'Normal', description: 'Zeitnah', color: 'yellow' },
                      { id: 'high', label: 'Hoch', description: 'Dringend', color: 'orange' },
                      { id: 'critical', label: 'Kritisch', description: 'Sofort', color: 'red' }
                    ].map((priority) => (
                      <Card 
                        key={priority.id}
                        className={`cursor-pointer transition-colors border-2 ${
                          selectedPriority === priority.id 
                            ? `border-${priority.color}-500 bg-${priority.color}-50` 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedPriority(priority.id)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full bg-${priority.color}-500`}></div>
                            <div>
                              <h5 className="font-medium">{priority.label}</h5>
                              <p className="text-xs text-gray-600">{priority.description}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Beschreibung */}
                <div>
                  <label className="block text-sm font-medium mb-2">Kurze Beschreibung</label>
                  <textarea
                    value={requestDescription}
                    onChange={(e) => setRequestDescription(e.target.value)}
                    placeholder="Beschreiben Sie kurz, womit Sie Hilfe benötigen..."
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Teamer-Info */}
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Bell className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-blue-800 mb-1">So funktioniert es</h4>
                        <div className="text-sm text-blue-700 space-y-1">
                          <p>• Alle verfügbaren Teamer erhalten eine Benachrichtigung</p>
                          <p>• Der erste verfügbare Teamer übernimmt Ihre Anfrage</p>
                          <p>• Sie werden automatisch verbunden</p>
                          <p>• Bei Bedarf kann an einen Pastor weitergeleitet werden</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Button 
                  onClick={handleCreateChatRequest}
                  disabled={!selectedCategory || !requestDescription.trim()}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Hilfe anfordern
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {currentUser.role === 'konfi' ? 'Vertrauliche Gespräche' : 'Notfall-Chat System'}
            </h1>
            <p className="text-gray-600 mt-1">
              {currentUser.role === 'konfi' 
                ? 'Sichere, verschlüsselte Chats für persönliche Anliegen'
                : 'Betreuung von Konfirmanden in schwierigen Situationen'
              }
            </p>
          </div>
          <div className="flex items-center gap-4">
            {currentUser.role === 'konfi' && (
              <Button 
                onClick={() => setShowNewChatForm(true)}
                className="gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                <Plus className="w-4 h-4" />
                Hilfe anfordern
              </Button>
            )}
            <Button variant="outline" onClick={onBack} className="gap-2">
              <X className="w-4 h-4" />
              Zurück
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Für Teamer: Wartende Anfragen */}
          {(currentUser.role === 'teamer' || currentUser.role === 'pastor') && (
            <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  <Bell className="w-5 h-5" />
                  Wartende Hilfe-Anfragen ({waitingRequests.length})
                </CardTitle>
                <p className="text-sm text-orange-600">
                  Konfirmanden warten auf Unterstützung
                </p>
              </CardHeader>
              <CardContent>
                {waitingRequests.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Keine wartenden Anfragen</p>
                    <p className="text-sm">Sie werden benachrichtigt, wenn Hilfe benötigt wird</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {waitingRequests.map((request) => {
                      const initiator = users.find(u => u.id === request.initiatorId);
                      if (!initiator) return null;

                      return (
                        <Card 
                          key={request.id}
                          className="border-2 border-orange-300 bg-white"
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-3">
                                {initiator.profileImage ? (
                                  <img
                                    src={initiator.profileImage}
                                    alt={`${initiator.firstName} ${initiator.lastName}`}
                                    className="w-10 h-10 rounded-full object-cover border-2 border-white shadow"
                                  />
                                ) : (
                                  <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                                    {initiator.firstName?.[0]}{initiator.lastName?.[0]}
                                  </div>
                                )}
                                <div>
                                  <h4 className="font-semibold">
                                    {initiator.firstName} {initiator.lastName}
                                  </h4>
                                  <p className="text-sm text-gray-600">
                                    {initiator.konfiRole} • Konfirmand
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge variant="outline" className={`${getPriorityColor(request.priority)} text-white`}>
                                  {request.priority === 'critical' ? 'Kritisch' : 
                                   request.priority === 'high' ? 'Hoch' : 
                                   request.priority === 'medium' ? 'Normal' : 'Niedrig'}
                                </Badge>
                                <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                                  <Timer className="w-3 h-3" />
                                  <span>{getTimeRemaining(request.expiresAt)}</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 mb-3">
                              {getCategoryIcon(request.category)}
                              <span className="text-sm font-medium">
                                {getCategoryLabel(request.category)}
                              </span>
                            </div>

                            <p className="text-sm text-gray-700 mb-4 bg-gray-50 p-3 rounded">
                              {request.description}
                            </p>

                            <div className="flex items-center justify-between">
                              <div className="text-xs text-gray-500">
                                Angefragt: {new Date(request.createdAt).toLocaleTimeString('de-DE')}
                              </div>
                              <Button 
                                onClick={() => handleAcceptChatRequest(request.id)}
                                className="gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                              >
                                <UserCheck className="w-4 h-4" />
                                Übernehmen
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Für Konfirmanden: Meine Anfragen */}
          {currentUser.role === 'konfi' && (
            <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-800">
                  <Timer className="w-5 h-5" />
                  Meine Anfragen ({myRequests.length})
                </CardTitle>
                <p className="text-sm text-yellow-600">
                  Ihre Hilfe-Anfragen und deren Status
                </p>
              </CardHeader>
              <CardContent>
                {myRequests.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    <Timer className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                    <p className="text-sm">Keine Anfragen gestellt</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myRequests.map((request) => (
                      <Card key={request.id} className="border-yellow-300 bg-white">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getCategoryIcon(request.category)}
                              <span className="font-medium">
                                {getCategoryLabel(request.category)}
                              </span>
                              <Badge variant="outline" className={`${getPriorityColor(request.priority)} text-white text-xs`}>
                                {request.priority === 'critical' ? 'Kritisch' : 
                                 request.priority === 'high' ? 'Hoch' : 
                                 request.priority === 'medium' ? 'Normal' : 'Niedrig'}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              {request.status === 'waiting' && (
                                <div className="flex items-center gap-1 text-sm text-orange-600">
                                  <Timer className="w-4 h-4" />
                                  <span>{getTimeRemaining(request.expiresAt)}</span>
                                </div>
                              )}
                              {request.status === 'waiting' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteRequest(request.id)}
                                  className="h-6 w-6 p-0 text-red-500"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{request.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">
                              {new Date(request.createdAt).toLocaleString('de-DE')}
                            </span>
                            <Badge variant={
                              request.status === 'waiting' ? 'secondary' :
                              request.status === 'accepted' ? 'default' : 'destructive'
                            }>
                              {request.status === 'waiting' ? 'Warten auf Teamer...' :
                               request.status === 'accepted' ? 'Angenommen' : 'Abgelaufen'}
                            </Badge>
                          </div>
                          {request.status === 'accepted' && request.acceptedBy && (
                            <div className="mt-2 text-xs text-green-600">
                              Angenommen von {users.find(u => u.id === request.acceptedBy)?.firstName} um{' '}
                              {request.acceptedAt ? new Date(request.acceptedAt).toLocaleTimeString('de-DE') : ''}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Aktive Chats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                {currentUser.role === 'konfi' ? 'Meine Gespräche' : 'Aktive Betreuungen'} ({userChats.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {userChats.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>
                    {currentUser.role === 'konfi' 
                      ? 'Noch keine Gespräche gestartet' 
                      : 'Keine aktiven Betreuungen'
                    }
                  </p>
                  {currentUser.role === 'konfi' && (
                    <p className="text-sm">Fordern Sie Hilfe an, wenn Sie Unterstützung benötigen</p>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  {userChats.map((chat) => {
                    const otherParticipant = getOtherParticipant(chat);
                    const chatMessages = getChatMessages(chat.id);
                    const lastMessage = chatMessages[chatMessages.length - 1];
                    
                    return (
                      <Card 
                        key={chat.id}
                        className="cursor-pointer hover:shadow-md transition-all border-l-4 border-l-blue-500"
                        onClick={() => setSelectedChat(chat)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            {otherParticipant.profileImage ? (
                              <img
                                src={otherParticipant.profileImage}
                                alt={`${otherParticipant.firstName} ${otherParticipant.lastName}`}
                                className="w-10 h-10 rounded-full object-cover border-2 border-white shadow"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                                {otherParticipant.firstName?.[0]}{otherParticipant.lastName?.[0]}
                              </div>
                            )}
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold">
                                  {otherParticipant.firstName} {otherParticipant.lastName}
                                </h4>
                                {otherParticipant.role === 'pastor' && (
                                  <Crown className="w-4 h-4 text-purple-600" />
                                )}
                                <Badge variant="outline" className={`${getPriorityColor(chat.priority)} text-white text-xs`}>
                                  {chat.priority === 'critical' ? 'Kritisch' : 
                                   chat.priority === 'high' ? 'Hoch' : 
                                   chat.priority === 'medium' ? 'Normal' : 'Niedrig'}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2 mb-2">
                                {getCategoryIcon(chat.category)}
                                <span className="text-sm text-gray-600">
                                  {getCategoryLabel(chat.category)}
                                </span>
                                <Badge variant="outline" className="text-xs">
                                  {chat.status === 'active' ? 'Aktiv' : 
                                   chat.status === 'escalated' ? 'Weitergeleitet' : 
                                   chat.status === 'resolved' ? 'Gelöst' : 'Geschlossen'}
                                </Badge>
                              </div>
                              {lastMessage && (
                                <p className="text-sm text-gray-600 truncate">
                                  {lastMessage.content}
                                </p>
                              )}
                              <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                <div className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  <span>{new Date(chat.lastActivity).toLocaleString('de-DE')}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Shield className="w-3 h-3" />
                                  <span>Verschlüsselt</span>
                                </div>
                                <span>{chat.metadata.messageCount} Nachrichten</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Informationen und Hilfe */}
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-800">
                <Shield className="w-5 h-5" />
                Sicherheit & Datenschutz
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                <span>Ende-zu-Ende-Verschlüsselung aller Nachrichten</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                <span>Automatische Löschung nach 30 Tagen</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                <span>Nur Sie und Ihr Gesprächspartner haben Zugriff</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                <span>Keine Speicherung auf Servern</span>
              </div>
              {currentUser.role === 'konfi' && (
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>Anfragen laufen nach 10 Minuten automatisch ab</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notfall-Kontakte */}
          <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-800">
                <Phone className="w-5 h-5" />
                24/7 Notfall-Kontakte
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-600" />
                <div>
                  <p className="font-medium">Telefonseelsorge</p>
                  <p className="text-red-700">0800 111 0 111 (24/7 kostenlos)</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-600" />
                <div>
                  <p className="font-medium">Nummer gegen Kummer</p>
                  <p className="text-red-700">116 111 (Mo-Sa 14-20 Uhr)</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-600" />
                <div>
                  <p className="font-medium">Polizei Notruf</p>
                  <p className="text-red-700">110 (bei akuter Gefahr)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}