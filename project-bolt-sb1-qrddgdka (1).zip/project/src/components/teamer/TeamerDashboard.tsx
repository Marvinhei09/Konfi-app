import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, BookOpen, BarChart3, LogOut, QrCode, Brain, FileText, Shield, Church } from 'lucide-react';
import { UserProfile } from '../common/UserProfile';
import { QuestionManager } from '../admin/QuestionManager';
import { CalendarManager } from '../admin/CalendarManager';
import { QuizHistoryView } from '../admin/QuizHistoryView';
import { PassManager } from '../pass/PassManager';
import { AdminStatusMessage } from '../admin/AdminStatusMessage';
import { ChurchLogoUploader } from '../admin/ChurchLogoUploader';
import type { Question, QuizHistory, CalendarEvent, KonfiContact, KonfiPass, Flashcard, LearningMaterial, User } from '@/types';

interface TeamerDashboardProps {
  questions: Question[];
  onQuestionsChange: (questions: Question[]) => void;
  history: QuizHistory[];
  events: CalendarEvent[];
  onEventsChange: (events: CalendarEvent[]) => void;
  contacts: KonfiContact[];
  passes: KonfiPass[];
  onPassesChange: (passes: KonfiPass[]) => void;
  flashcards: Flashcard[];
  onFlashcardsChange: (flashcards: Flashcard[]) => void;
  learningMaterials: LearningMaterial[];
  onLearningMaterialsChange: (materials: LearningMaterial[]) => void;
  users: User[];
  onNavigateToLearning: () => void;
  onEmergencyChat?: () => void;
  onLogout: () => void;
}

export function TeamerDashboard({ 
  questions, 
  onQuestionsChange, 
  history, 
  events, 
  onEventsChange,
  contacts,
  passes,
  onPassesChange,
  flashcards,
  onFlashcardsChange,
  learningMaterials,
  onLearningMaterialsChange,
  users,
  onNavigateToLearning,
  onEmergencyChat,
  onLogout 
}: TeamerDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isAvailableForEmergency, setIsAvailableForEmergency] = useState(true);
  const [showLogoUploader, setShowLogoUploader] = useState(false);
  const [churchLogo, setChurchLogo] = useState<string | undefined>(undefined);

  const totalSignatures = passes.reduce((sum, pass) => sum + pass.signatures.length, 0);
  const currentUser = users.find(u => u.role === 'teamer' || u.role === 'pastor') || users[0];

  const handleToggleAvailability = () => {
    setIsAvailableForEmergency(!isAvailableForEmergency);
    
    // Update user availability in a real app
    // onUsersChange(users.map(u => 
    //   u.id === currentUser.id ? { ...u, isAvailableForEmergency: !isAvailableForEmergency } : u
    // ));
  };

  const handleSaveLogo = (logoUrl: string) => {
    setChurchLogo(logoUrl);
    setShowLogoUploader(false);
    // In a real app, you would save this to a database or localStorage
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            {/* Church Logo */}
            <div 
              className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg cursor-pointer"
              onClick={() => setShowLogoUploader(true)}
            >
              {churchLogo ? (
                <img 
                  src={churchLogo} 
                  alt="Kirchenlogo" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-green-500 flex items-center justify-center">
                  <Church className="w-8 h-8 text-white" />
                </div>
              )}
            </div>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {currentUser.role === 'pastor' ? 'Pastor' : 'Teamer'} Dashboard
              </h1>
              <p className="text-gray-600 mt-1">
                Verwalten Sie Quiz, Termine, Pässe und Lernmaterialien
                {currentUser.role === 'pastor' && ' - Erweiterte Berechtigungen'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button onClick={onNavigateToLearning} variant="outline" className="gap-2">
              <Brain className="w-4 h-4" />
              Lernplattform
            </Button>
            {onEmergencyChat && (
              <Button onClick={onEmergencyChat} variant="outline" className="gap-2 border-red-300 text-red-700 hover:bg-red-50">
                <Shield className="w-4 h-4" />
                Notfall-Chats
              </Button>
            )}
            <UserProfile user={currentUser} onLogout={onLogout} onEmergencyChat={onEmergencyChat} />
          </div>
        </div>

        {/* Teamer/Pastor Status Message */}
        {onEmergencyChat && (
          <div className="mb-6">
            <AdminStatusMessage 
              isAvailable={isAvailableForEmergency} 
              onToggleAvailability={handleToggleAvailability}
            />
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Übersicht
            </TabsTrigger>
            <TabsTrigger value="questions" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Fragen
            </TabsTrigger>
            <TabsTrigger value="calendar" className="gap-2">
              <Calendar className="w-4 h-4" />
              Termine
            </TabsTrigger>
            <TabsTrigger value="passes" className="gap-2">
              <QrCode className="w-4 h-4" />
              Pässe
            </TabsTrigger>
            <TabsTrigger value="learning" className="gap-2">
              <Brain className="w-4 h-4" />
              Lernplattform
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Statistiken
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid gap-6 mb-8 md:grid-cols-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Fragen</p>
                      <p className="text-3xl font-bold">{questions.length}</p>
                    </div>
                    <BookOpen className="w-8 h-8 text-blue-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">Termine</p>
                      <p className="text-3xl font-bold">{events.length}</p>
                    </div>
                    <Calendar className="w-8 h-8 text-green-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-indigo-100">Pässe</p>
                      <p className="text-3xl font-bold">{passes.length}</p>
                    </div>
                    <QrCode className="w-8 h-8 text-indigo-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Unterschriften</p>
                      <p className="text-3xl font-bold">{totalSignatures}</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-purple-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 mb-8 md:grid-cols-2">
              <Card className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-teal-100">Karteikarten</p>
                      <p className="text-3xl font-bold">{flashcards.length}</p>
                    </div>
                    <Brain className="w-8 h-8 text-teal-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-cyan-100">Materialien</p>
                      <p className="text-3xl font-bold">{learningMaterials.length}</p>
                    </div>
                    <FileText className="w-8 h-8 text-cyan-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid gap-6 lg:grid-cols-2">
              {onEmergencyChat && (
                <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-800">
                      <Shield className="w-5 h-5" />
                      Notfall-Chat System
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700">
                      {currentUser.role === 'pastor' 
                        ? 'Übernehmen Sie eskalierte Fälle und bieten Sie professionelle Seelsorge.'
                        : 'Unterstützen Sie Konfirmanden in schwierigen Situationen und leiten Sie bei Bedarf an Pastoren weiter.'
                      }
                    </p>
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between">
                        <span>Ihre Rolle:</span>
                        <span className="font-semibold">
                          {currentUser.role === 'pastor' ? 'Pastor (Eskalationsebene)' : 'Teamer (Erste Hilfe)'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Verfügbarkeitsstatus:</span>
                        <span className={isAvailableForEmergency ? 'text-green-600' : 'text-red-600'}>
                          {isAvailableForEmergency ? '✓ Verfügbar' : '✗ Nicht verfügbar'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Spezialisierungen:</span>
                        <span>{currentUser.specializations?.length || 0}</span>
                      </div>
                    </div>
                    <Button 
                      onClick={onEmergencyChat} 
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      {currentUser.role === 'pastor' ? 'Eskalierte Fälle bearbeiten' : 'Notfall-Chats betreuen'}
                    </Button>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-blue-600" />
                    Lernplattform
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Erstellen und verwalten Sie digitale Karteikarten und Lernmaterialien.
                  </p>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Karteikarten:</span>
                      <span>{flashcards.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Lernmaterialien:</span>
                      <span>{learningMaterials.length}</span>
                    </div>
                  </div>
                  <Button 
                    onClick={onNavigateToLearning} 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Lernplattform öffnen
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-indigo-600" />
                    Konfirmationspässe
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Verwalten Sie die digitalen Pässe und erfassen Sie Aktivitäten.
                  </p>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Aktive Pässe:</span>
                      <span>{passes.filter(p => p.isActive).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Gesamte Unterschriften:</span>
                      <span>{totalSignatures}</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setActiveTab('passes')} 
                    variant="outline"
                    className="w-full"
                  >
                    <QrCode className="w-4 h-4 mr-2" />
                    Pässe verwalten
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Church className="w-5 h-5 text-blue-600" />
                    Kirchenlogo
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Passen Sie das Logo Ihrer Kirche an, das in der Anwendung angezeigt wird.
                  </p>
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-gray-200">
                      {churchLogo ? (
                        <img 
                          src={churchLogo} 
                          alt="Kirchenlogo" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-green-500 flex items-center justify-center">
                          <Church className="w-12 h-12 text-white" />
                        </div>
                      )}
                    </div>
                  </div>
                  <Button 
                    onClick={() => setShowLogoUploader(true)} 
                    className="w-full"
                  >
                    <Church className="w-4 h-4 mr-2" />
                    {churchLogo ? 'Logo ändern' : 'Logo hochladen'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="questions" className="mt-6">
            <QuestionManager 
              questions={questions}
              onQuestionsChange={onQuestionsChange}
            />
          </TabsContent>
          
          <TabsContent value="calendar" className="mt-6">
            <CalendarManager 
              events={events}
              onEventsChange={onEventsChange}
            />
          </TabsContent>

          <TabsContent value="passes" className="mt-6">
            <PassManager 
              passes={passes}
              onPassesChange={onPassesChange}
              contacts={contacts}
            />
          </TabsContent>

          <TabsContent value="learning" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    Lernplattform Übersicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Digitale Karteikarten</h3>
                      <div className="grid gap-2 text-sm">
                        <div className="flex justify-between">
                          <span>Gesamt:</span>
                          <span>{flashcards.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Einfach:</span>
                          <span>{flashcards.filter(f => f.difficulty === 'easy').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Mittel:</span>
                          <span>{flashcards.filter(f => f.difficulty === 'medium').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Schwer:</span>
                          <span>{flashcards.filter(f => f.difficulty === 'hard').length}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">Lernmaterialien</h3>
                      <div className="grid gap-2 text-sm">
                        <div className="flex justify-between">
                          <span>Gesamt:</span>
                          <span>{learningMaterials.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>PDF-Dokumente:</span>
                          <span>{learningMaterials.filter(m => m.type === 'pdf').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Zusammenfassungen:</span>
                          <span>{learningMaterials.filter(m => m.type === 'summary').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Bilder:</span>
                          <span>{learningMaterials.filter(m => m.type === 'image').length}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t">
                    <Button 
                      onClick={onNavigateToLearning} 
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    >
                      <Brain className="w-4 h-4 mr-2" />
                      Zur Lernplattform wechseln
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="history" className="mt-6">
            <QuizHistoryView history={history} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Church Logo Uploader Modal */}
      {showLogoUploader && (
        <ChurchLogoUploader
          currentLogo={churchLogo}
          onSave={handleSaveLogo}
          onClose={() => setShowLogoUploader(false)}
        />
      )}
    </div>
  );
}