import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Camera, Edit, User, Crown, Medal, Star } from 'lucide-react';
import { ProfileImageManager } from '@/utils/profileImageUtils';
import type { User as UserType } from '@/types';

interface ProfileImageDisplayProps {
  user: UserType;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showEditButton?: boolean;
  showRoleBadge?: boolean;
  showRankBadge?: boolean;
  onEditClick?: () => void;
  className?: string;
}

export function ProfileImageDisplay({ 
  user, 
  size = 'md', 
  showEditButton = false,
  showRoleBadge = false,
  showRankBadge = false,
  onEditClick,
  className = ''
}: ProfileImageDisplayProps) {
  const [imageError, setImageError] = useState(false);
  const profileManager = ProfileImageManager.getInstance();

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  const badgeSizes = {
    sm: 'text-xs',
    md: 'text-xs',
    lg: 'text-sm',
    xl: 'text-sm'
  };

  const editButtonSizes = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
    xl: 'w-12 h-12'
  };

  const getDisplayName = () => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user.username;
  };

  const getInitials = () => {
    return profileManager.generateInitials(user.firstName, user.lastName, user.username);
  };

  const getRoleBadgeColor = () => {
    switch (user.role) {
      case 'admin': return 'default';
      case 'teamer': return 'secondary';
      case 'konfi':
        switch (user.konfiRole) {
          case 'KU4': return 'secondary';
          case 'KUZ': return 'outline';
          case 'KU8': return 'destructive';
          default: return 'secondary';
        }
      default: return 'secondary';
    }
  };

  const getRoleLabel = () => {
    switch (user.role) {
      case 'admin': return 'Admin';
      case 'teamer': return 'Teamer';
      case 'konfi': return user.konfiRole || 'Konfi';
      default: return user.role;
    }
  };

  const getRankIcon = () => {
    if (!user.rank) return null;
    
    switch (user.rank) {
      case 1: return <Crown className="w-3 h-3 text-yellow-500" />;
      case 2: return <Medal className="w-3 h-3 text-gray-400" />;
      case 3: return <Medal className="w-3 h-3 text-orange-600" />;
      default: return <Star className="w-3 h-3 text-blue-500" />;
    }
  };

  const canEdit = profileManager.canEditProfileImage(user.role) && showEditButton;

  // Verwende Standard-Profilbild wenn kein Custom-Bild oder Fehler
  const shouldUseDefault = !user.profileImage || !user.hasCustomProfileImage || imageError;
  const defaultImage = profileManager.generateDefaultProfileImage(getInitials(), 150);

  return (
    <div className={`relative inline-block ${className}`}>
      {/* Profilbild */}
      <div className={`${sizeClasses[size]} rounded-full overflow-hidden border-2 border-white shadow-lg relative group`}>
        {shouldUseDefault ? (
          <div className="w-full h-full bg-gray-400 flex items-center justify-center">
            <span className="text-white font-bold text-sm">
              {getInitials()}
            </span>
          </div>
        ) : (
          <img
            src={user.profileImage}
            alt={getDisplayName()}
            className="w-full h-full object-cover"
            onError={() => setImageError(true)}
          />
        )}

        {/* Hover-Overlay für Edit-Button */}
        {canEdit && (
          <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
            <Camera className="w-4 h-4 text-white" />
          </div>
        )}
      </div>

      {/* Edit-Button */}
      {canEdit && onEditClick && (
        <Button
          size="sm"
          variant="secondary"
          onClick={onEditClick}
          className={`absolute -bottom-1 -right-1 ${editButtonSizes[size]} p-0 rounded-full border-2 border-white shadow-lg`}
        >
          <Edit className="w-3 h-3" />
        </Button>
      )}

      {/* Rang-Badge */}
      {showRankBadge && user.rank && (
        <div className="absolute -top-1 -left-1 bg-white rounded-full p-1 shadow-lg">
          <div className="flex items-center gap-1">
            {getRankIcon()}
            <span className="text-xs font-bold">#{user.rank}</span>
          </div>
        </div>
      )}

      {/* Rollen-Badge */}
      {showRoleBadge && (
        <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
          <Badge variant={getRoleBadgeColor()} className={badgeSizes[size]}>
            {getRoleLabel()}
          </Badge>
        </div>
      )}

      {/* Online-Indikator */}
      {user.lastActive && new Date(user.lastActive) > new Date(Date.now() - 5 * 60 * 1000) && (
        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
      )}
    </div>
  );
}