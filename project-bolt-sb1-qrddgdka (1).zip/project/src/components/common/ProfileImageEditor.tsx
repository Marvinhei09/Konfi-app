import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, Camera, Save, X, RotateCcw, Crop, Download, 
  AlertCircle, CheckCircle, Sparkles, Zap, Palette, 
  Brightness4, Contrast, Droplets, Blur
} from 'lucide-react';
import { ProfileImageManager } from '@/utils/profileImageUtils';
import type { User, ProfileImageUpload } from '@/types';

interface ProfileImageEditorProps {
  user: User;
  onSave: (updatedUser: User) => void;
  onClose: () => void;
}

export function ProfileImageEditor({ user, onSave, onClose }: ProfileImageEditorProps) {
  const [uploadData, setUploadData] = useState<ProfileImageUpload | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const profileManager = ProfileImageManager.getInstance();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setError('');
    setSuccess('');

    // Validiere Datei
    const validation = profileManager.validateImage(file);
    if (!validation.isValid) {
      setError(validation.error || 'Ungültige Datei');
      return;
    }

    setIsProcessing(true);
    setUploadProgress(20);

    try {
      // Verarbeite Bild
      const processedUpload = await profileManager.processImage(file);
      setUploadProgress(60);
      
      setUploadData(processedUpload);
      setUploadProgress(100);
      setSuccess('Bild erfolgreich geladen und optimiert');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Fehler beim Verarbeiten des Bildes');
    } finally {
      setIsProcessing(false);
      setTimeout(() => setUploadProgress(0), 1000);
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        } 
      });
      
      // Hier würde eine Kamera-Aufnahme-Komponente implementiert
      setSuccess('Kamera-Funktion wird implementiert...');
      stream.getTracks().forEach(track => track.stop());
    } catch (err) {
      setError('Kamera-Zugriff nicht möglich');
    }
  };

  const updateFilter = (filterName: keyof NonNullable<ProfileImageUpload['filters']>, value: number) => {
    if (!uploadData) return;

    setUploadData({
      ...uploadData,
      filters: {
        ...uploadData.filters!,
        [filterName]: value
      }
    });

    // Aktualisiere Vorschau
    updatePreview();
  };

  const updatePreview = () => {
    if (!uploadData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = 200;
      canvas.height = 200;

      const filters = uploadData.filters!;
      ctx.filter = `
        brightness(${filters.brightness}%) 
        contrast(${filters.contrast}%) 
        saturate(${filters.saturation}%) 
        blur(${filters.blur}px)
      `;
      
      ctx.drawImage(img, 0, 0, 200, 200);
    };
    img.src = uploadData.preview;
  };

  const handleSave = async () => {
    if (!uploadData) return;

    setIsProcessing(true);
    setUploadProgress(20);

    try {
      // Simuliere Upload-Prozess
      await new Promise(resolve => setTimeout(resolve, 1000));
      setUploadProgress(60);

      // In einer echten Implementierung würde hier das Bild hochgeladen werden
      const imageUrl = uploadData.preview; // Placeholder
      setUploadProgress(80);

      const updatedUser: User = {
        ...user,
        profileImage: imageUrl,
        hasCustomProfileImage: true,
        profileImageUploadedAt: new Date().toISOString(),
        profileImageSize: uploadData.metadata?.compressedSize
      };

      setUploadProgress(100);
      setSuccess('Profilbild erfolgreich gespeichert!');
      
      setTimeout(() => {
        onSave(updatedUser);
      }, 1000);
    } catch (err) {
      setError('Fehler beim Speichern des Bildes');
      setIsProcessing(false);
      setUploadProgress(0);
    }
  };

  const handleReset = () => {
    const defaultImage = profileManager.generateDefaultProfileImage(
      profileManager.generateInitials(user.firstName, user.lastName, user.username)
    );

    const updatedUser: User = {
      ...user,
      profileImage: defaultImage,
      hasCustomProfileImage: false,
      profileImageUploadedAt: undefined,
      profileImageSize: undefined
    };

    onSave(updatedUser);
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;

    const link = document.createElement('a');
    link.download = `${user.username}_profilbild.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Profilbild bearbeiten
              <Badge variant="outline" className="ml-2">
                {user.role === 'admin' ? 'Administrator' : 'Teamer'}
              </Badge>
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Upload-Fortschritt */}
          {uploadProgress > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Verarbeitung...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          {/* Benachrichtigungen */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          {/* Upload-Bereich */}
          {!uploadData && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center bg-gradient-to-br from-blue-50 to-indigo-50">
                <div className="relative">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <Sparkles className="absolute -top-1 -right-1 w-4 h-4 text-blue-500 animate-pulse" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Profilbild hochladen</h3>
                <p className="text-gray-600 mb-4">
                  Wählen Sie ein Bild aus oder nutzen Sie die Kamera für ein neues Foto
                </p>
                <div className="flex gap-4 justify-center">
                  <Button 
                    onClick={() => fileInputRef.current?.click()} 
                    className="gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    disabled={isProcessing}
                  >
                    <Upload className="w-4 h-4" />
                    Datei auswählen
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={handleCameraCapture} 
                    className="gap-2"
                    disabled={isProcessing}
                  >
                    <Camera className="w-4 h-4" />
                    Kamera verwenden
                  </Button>
                </div>
                <div className="mt-4 space-y-1 text-xs text-gray-500">
                  <p>• Unterstützte Formate: JPG, PNG, WebP</p>
                  <p>• Maximale Größe: 5MB</p>
                  <p>• Empfohlene Auflösung: 500x500px oder höher</p>
                  <p>• Automatische Optimierung und Komprimierung</p>
                </div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileSelect}
                className="hidden"
              />

              {/* Aktuelles Profilbild */}
              <Card className="bg-gray-50">
                <CardHeader>
                  <CardTitle className="text-sm">Aktuelles Profilbild</CardTitle>
                </CardHeader>
                <CardContent className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-gray-300">
                    {user.profileImage && user.hasCustomProfileImage ? (
                      <img
                        src={user.profileImage}
                        alt="Aktuelles Profilbild"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-400 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">
                          {profileManager.generateInitials(user.firstName, user.lastName, user.username)}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">
                      {user.hasCustomProfileImage ? 'Benutzerdefiniertes Bild' : 'Standard-Platzhalter'}
                    </p>
                    <p className="text-sm text-gray-600">
                      {user.profileImageUploadedAt 
                        ? `Hochgeladen am ${new Date(user.profileImageUploadedAt).toLocaleDateString('de-DE')}`
                        : 'Automatisch generiert'
                      }
                    </p>
                    {user.profileImageSize && (
                      <p className="text-xs text-gray-500">
                        Größe: {profileManager.formatFileSize(user.profileImageSize)}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReset}
                    className="gap-2"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Zurücksetzen
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Bearbeitungsbereich */}
          {uploadData && (
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Vorschau */}
              <div className="space-y-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <Zap className="w-4 h-4 text-blue-500" />
                  Live-Vorschau
                </h3>
                
                <div className="relative bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg p-6">
                  <canvas
                    ref={canvasRef}
                    width="200"
                    height="200"
                    className="rounded-full mx-auto border-4 border-white shadow-lg"
                  />
                  
                  {/* Metadaten */}
                  <div className="mt-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Original:</span>
                      <span>{profileManager.formatFileSize(uploadData.metadata?.originalSize || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Optimiert:</span>
                      <span className="text-green-600">
                        {profileManager.formatFileSize(uploadData.metadata?.compressedSize || 0)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Auflösung:</span>
                      <span>
                        {uploadData.metadata?.dimensions.width}x{uploadData.metadata?.dimensions.height}px
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Format:</span>
                      <span>{uploadData.metadata?.format}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Filter-Steuerung */}
              <div className="space-y-6">
                <h3 className="font-semibold flex items-center gap-2">
                  <Palette className="w-4 h-4 text-purple-500" />
                  Bildbearbeitung
                </h3>

                <div className="space-y-4">
                  {/* Helligkeit */}
                  <div>
                    <Label className="flex items-center gap-2 mb-2">
                      <Brightness4 className="w-4 h-4" />
                      Helligkeit: {uploadData.filters?.brightness}%
                    </Label>
                    <Input
                      type="range"
                      min="50"
                      max="150"
                      value={uploadData.filters?.brightness || 100}
                      onChange={(e) => updateFilter('brightness', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Kontrast */}
                  <div>
                    <Label className="flex items-center gap-2 mb-2">
                      <Contrast className="w-4 h-4" />
                      Kontrast: {uploadData.filters?.contrast}%
                    </Label>
                    <Input
                      type="range"
                      min="50"
                      max="150"
                      value={uploadData.filters?.contrast || 100}
                      onChange={(e) => updateFilter('contrast', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Sättigung */}
                  <div>
                    <Label className="flex items-center gap-2 mb-2">
                      <Droplets className="w-4 h-4" />
                      Sättigung: {uploadData.filters?.saturation}%
                    </Label>
                    <Input
                      type="range"
                      min="0"
                      max="200"
                      value={uploadData.filters?.saturation || 100}
                      onChange={(e) => updateFilter('saturation', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Unschärfe */}
                  <div>
                    <Label className="flex items-center gap-2 mb-2">
                      <Blur className="w-4 h-4" />
                      Unschärfe: {uploadData.filters?.blur}px
                    </Label>
                    <Input
                      type="range"
                      min="0"
                      max="10"
                      value={uploadData.filters?.blur || 0}
                      onChange={(e) => updateFilter('blur', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Reset-Button für Filter */}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setUploadData({
                        ...uploadData,
                        filters: {
                          brightness: 100,
                          contrast: 100,
                          saturation: 100,
                          blur: 0
                        }
                      });
                      updatePreview();
                    }}
                    className="w-full gap-2"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Filter zurücksetzen
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Aktionen */}
          {uploadData && (
            <div className="flex gap-4 pt-6 border-t">
              <Button 
                onClick={handleSave} 
                disabled={isProcessing}
                className="gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                <Save className="w-4 h-4" />
                {isProcessing ? 'Speichere...' : 'Profilbild speichern'}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={handleDownload}
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Herunterladen
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => setUploadData(null)}
                className="gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Neues Bild
              </Button>
              
              <Button variant="ghost" onClick={onClose}>
                Abbrechen
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}