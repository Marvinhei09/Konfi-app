import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, LogOut, Settings, MessageSquare, Shield } from 'lucide-react';
import type { User as UserType } from '@/types';

interface UserProfileProps {
  user: UserType;
  onLogout: () => void;
  onSettings?: () => void;
  onEmergencyChat?: () => void;
}

export function UserProfile({ user, onLogout, onSettings, onEmergencyChat }: UserProfileProps) {
  const [showDropdown, setShowDropdown] = useState(false);

  const getDisplayName = () => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user.username;
  };

  const getRoleLabel = () => {
    switch (user.role) {
      case 'admin': return 'Administrator';
      case 'teamer': return 'Teamer';
      case 'pastor': return 'Pastor';
      case 'konfi': return `Konfirmand ${user.konfiRole || ''}`;
      default: return user.role;
    }
  };

  const getInitials = () => {
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.username) {
      const parts = user.username.split('.');
      if (parts.length >= 2) {
        return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
      }
      return user.username.slice(0, 2).toUpperCase();
    }
    return 'KU';
  };

  return (
    <div className="relative">
      <div
        className="flex items-center gap-3 cursor-pointer group"
        onClick={() => setShowDropdown(!showDropdown)}
      >
        {/* Graues Standard-Profilbild */}
        <div className="relative">
          <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center text-white font-semibold text-sm border-2 border-white shadow-lg group-hover:shadow-xl transition-all duration-200 group-hover:scale-105">
            {getInitials()}
          </div>
          
          {/* Online-Indikator */}
          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
        </div>

        {/* Name und Rolle (nur auf größeren Bildschirmen) */}
        <div className="hidden md:block text-right">
          <p className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
            {getDisplayName()}
          </p>
          <p className="text-xs text-gray-500">
            {getRoleLabel()}
          </p>
        </div>
      </div>

      {/* Dropdown-Menü */}
      {showDropdown && (
        <>
          {/* Overlay zum Schließen */}
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setShowDropdown(false)}
          />
          
          {/* Dropdown-Inhalt */}
          <Card className="absolute right-0 top-16 z-20 w-64 shadow-xl border-0 bg-white/95 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-4 pb-4 border-b">
                <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center text-white font-semibold">
                  {getInitials()}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{getDisplayName()}</p>
                  <p className="text-sm text-gray-500">{getRoleLabel()}</p>
                  <p className="text-xs text-gray-400">@{user.username}</p>
                </div>
              </div>

              <div className="space-y-2">
                {/* Notfall-Chat für Konfirmanden */}
                {user.role === 'konfi' && onEmergencyChat && (
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-2 text-gray-700 hover:text-gray-900 hover:bg-blue-50"
                    onClick={() => {
                      onEmergencyChat();
                      setShowDropdown(false);
                    }}
                  >
                    <MessageSquare className="w-4 h-4" />
                    Vertraulicher Chat
                  </Button>
                )}

                {/* Notfall-Chat für Teamer und Pastoren */}
                {(user.role === 'teamer' || user.role === 'pastor') && onEmergencyChat && (
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-2 text-gray-700 hover:text-gray-900 hover:bg-green-50"
                    onClick={() => {
                      onEmergencyChat();
                      setShowDropdown(false);
                    }}
                  >
                    <Shield className="w-4 h-4" />
                    Notfall-Chats
                  </Button>
                )}

                {onSettings && (
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-2 text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                    onClick={() => {
                      onSettings();
                      setShowDropdown(false);
                    }}
                  >
                    <Settings className="w-4 h-4" />
                    Einstellungen
                  </Button>
                )}
                
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                  onClick={() => {
                    onLogout();
                    setShowDropdown(false);
                  }}
                >
                  <LogOut className="w-4 h-4" />
                  Abmelden
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}