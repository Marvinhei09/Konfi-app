import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { QrCode, Calendar, Clock, MapPin, User, CheckCircle } from 'lucide-react';
import { QRCodeGenerator } from '../pass/QRCodeGenerator';
import { activityRequirements } from '@/data/activities';
import type { KonfiPass, KonfiContact } from '@/types';

interface StudentPassProps {
  pass: KonfiPass;
  contact: KonfiContact;
}

export function StudentPass({ pass, contact }: StudentPassProps) {
  const getProgressStats = () => {
    return activityRequirements.map(req => {
      const count = pass.signatures.filter(sig => sig.activityType === req.type).length;
      return {
        ...req,
        current: count,
        percentage: Math.min((count / req.required) * 100, 100),
        completed: count >= req.required
      };
    });
  };

  const getActivityTypeLabel = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'Konfirmationsunterricht';
      case 'gottesdienst': return 'Gottesdienst';
      case 'kirchliche_aktivitaet': return 'Kirchliche Aktivität';
      default: return type;
    }
  };

  const getActivityTypeColor = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'bg-blue-500';
      case 'gottesdienst': return 'bg-green-500';
      case 'kirchliche_aktivitaet': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const stats = getProgressStats();
  const totalProgress = stats.reduce((sum, stat) => sum + stat.percentage, 0) / stats.length;
  const allCompleted = stats.every(stat => stat.completed);

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5" />
              Mein Konfirmationspass
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <QRCodeGenerator value={pass.qrCode} size={180} />
              <div className="mt-4">
                <h3 className="font-semibold text-xl">
                  {contact.firstName} {contact.lastName}
                </h3>
                <p className="text-gray-600">@{contact.username}</p>
                <Badge 
                  variant={allCompleted ? "default" : "secondary"}
                  className="mt-2"
                >
                  {allCompleted ? "Bereit zur Konfirmation" : "In Vorbereitung"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fortschritt</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Gesamtfortschritt</span>
                <span>{Math.round(totalProgress)}%</span>
              </div>
              <Progress value={totalProgress} className="h-3" />
            </div>

            <div className="space-y-3">
              {stats.map((stat) => (
                <div key={stat.type} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{stat.title}</span>
                    <div className="flex items-center gap-2">
                      <span className={`text-sm ${stat.completed ? 'text-green-600 font-semibold' : 'text-gray-600'}`}>
                        {stat.current}/{stat.required}
                      </span>
                      {stat.completed && <CheckCircle className="w-4 h-4 text-green-600" />}
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all ${getActivityTypeColor(stat.type)}`}
                      style={{ width: `${stat.percentage}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600">{stat.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Meine Aktivitäten ({pass.signatures.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {pass.signatures.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <QrCode className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Noch keine Aktivitäten erfasst</p>
              <p className="text-sm">Deine Teilnahmen werden hier angezeigt</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {pass.signatures
                .sort((a, b) => new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime())
                .map((signature) => (
                  <Card key={signature.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <Badge 
                            variant="secondary" 
                            className={`${getActivityTypeColor(signature.activityType)} text-white`}
                          >
                            {getActivityTypeLabel(signature.activityType)}
                          </Badge>
                          <h4 className="font-semibold mt-1">{signature.activityTitle}</h4>
                        </div>
                        <div className="text-right text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(signature.date).toLocaleDateString('de-DE')}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <Clock className="w-3 h-3" />
                            {signature.time}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-600 space-y-1">
                        {signature.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{signature.location}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span>Bestätigt von: {signature.adminSignature}</span>
                        </div>
                        {signature.comments && (
                          <p className="mt-2 p-2 bg-gray-50 rounded text-xs">
                            {signature.comments}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}