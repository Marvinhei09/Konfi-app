import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Star, Calendar, Search, Filter, ArrowLeft, 
  ArrowRight, AlertCircle, Lock, Unlock, Eye, EyeOff
} from 'lucide-react';
import type { KonfiRating, User } from '@/types';

interface RatingViewProps {
  ratings: KonfiRating[];
  users: User[];
  currentUser: User;
  onBack: () => void;
}

export function RatingView({ 
  ratings, 
  users, 
  currentUser,
  onBack
}: RatingViewProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState<string>('');
  const [filterDateTo, setFilterDateTo] = useState<string>('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);

  // Authentifizierung prüfen
  const handleAuthenticate = () => {
    if (!currentUser.parentPassword) {
      setError('Für dich wurde kein Eltern-Passwort eingerichtet. Bitte wende dich an deinen Betreuer.');
      return;
    }
    
    if (password === currentUser.parentPassword) {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Ungültiges Passwort. Bitte versuche es erneut.');
    }
  };

  // Bewertungen für den aktuellen Benutzer filtern
  const userRatings = ratings.filter(rating => rating.konfiId === currentUser.id);
  
  // Bewertungen filtern
  const filteredRatings = userRatings.filter(rating => {
    const matchesSearch = rating.comment.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDateFrom = !filterDateFrom || rating.lessonDate >= filterDateFrom;
    const matchesDateTo = !filterDateTo || rating.lessonDate <= filterDateTo;
    
    return matchesSearch && matchesDateFrom && matchesDateTo;
  });
  
  // Bewertungen sortieren (neueste zuerst)
  const sortedRatings = [...filteredRatings].sort((a, b) => 
    new Date(b.lessonDate).getTime() - new Date(a.lessonDate).getTime()
  );
  
  // Paginierung
  const totalPages = Math.ceil(sortedRatings.length / itemsPerPage);
  const currentRatings = sortedRatings.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  const getCreatorName = (userId: string): string => {
    const user = users.find(u => u.id === userId);
    if (!user) return 'Unbekannt';
    
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    
    return user.username;
  };

  // Wenn nicht authentifiziert, zeige Login-Formular
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onBack} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Zurück
          </Button>
          <h1 className="text-2xl font-bold">Meine Bewertungen</h1>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Passwort-Schutz
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Um deine Bewertungen einzusehen, gib bitte das Eltern-Passwort ein.
            </p>
            
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="Eltern-Passwort"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <Button 
                onClick={handleAuthenticate} 
                className="w-full"
                disabled={!password.trim()}
              >
                <Unlock className="w-4 h-4 mr-2" />
                Bewertungen anzeigen
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Zurück
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Meine Bewertungen</h1>
            <p className="text-gray-600 text-sm mt-1">
              Übersicht deiner Bewertungen für Mitarbeit und Sozialverhalten
            </p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          onClick={() => setIsAuthenticated(false)}
          className="gap-2"
        >
          <Lock className="w-4 h-4" />
          Sperren
        </Button>
      </div>

      {/* Übersichtskarte */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Bewertungsübersicht
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <h3 className="font-semibold">Durchschnittliche Bewertungen</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium mb-1">Mitarbeit</p>
                  <div className="flex items-center gap-2">
                    {renderStars(Math.round(
                      userRatings.reduce((sum, r) => sum + r.participation, 0) / 
                      (userRatings.length || 1)
                    ))}
                    <span className="text-sm text-gray-600">
                      {(userRatings.reduce((sum, r) => sum + r.participation, 0) / 
                      (userRatings.length || 1)).toFixed(1)}
                    </span>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium mb-1">Sozialverhalten</p>
                  <div className="flex items-center gap-2">
                    {renderStars(Math.round(
                      userRatings.reduce((sum, r) => sum + r.socialBehavior, 0) / 
                      (userRatings.length || 1)
                    ))}
                    <span className="text-sm text-gray-600">
                      {(userRatings.reduce((sum, r) => sum + r.socialBehavior, 0) / 
                      (userRatings.length || 1)).toFixed(1)}
                    </span>
                  </div>
                </div>
                
                {/* Benutzerdefinierte Kategorien */}
                {Array.from(new Set(userRatings
                  .filter(r => r.customCategory)
                  .map(r => r.customCategory?.name)))
                  .map(categoryName => {
                    if (!categoryName) return null;
                    
                    const categoryRatings = userRatings.filter(r => 
                      r.customCategory?.name === categoryName
                    );
                    
                    const average = categoryRatings.reduce(
                      (sum, r) => sum + (r.customCategory?.rating || 0), 0
                    ) / categoryRatings.length;
                    
                    return (
                      <div key={categoryName}>
                        <p className="text-sm font-medium mb-1">{categoryName}</p>
                        <div className="flex items-center gap-2">
                          {renderStars(Math.round(average))}
                          <span className="text-sm text-gray-600">
                            {average.toFixed(1)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold">Statistik</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Anzahl Bewertungen:</span>
                  <Badge variant="secondary">{userRatings.length}</Badge>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-sm">Erste Bewertung:</span>
                  <span className="text-sm">
                    {userRatings.length > 0 
                      ? new Date(Math.min(...userRatings.map(r => new Date(r.lessonDate).getTime()))).toLocaleDateString('de-DE')
                      : 'Noch keine Bewertungen'}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-sm">Letzte Bewertung:</span>
                  <span className="text-sm">
                    {userRatings.length > 0 
                      ? new Date(Math.max(...userRatings.map(r => new Date(r.lessonDate).getTime()))).toLocaleDateString('de-DE')
                      : 'Noch keine Bewertungen'}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-sm">Beste Bewertung:</span>
                  <span className="text-sm">
                    {userRatings.length > 0 
                      ? Math.max(...userRatings.map(r => Math.max(r.participation, r.socialBehavior)))
                      : 'N/A'} / 5
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filter und Suche */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="In Kommentaren suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div>
              <Input
                type="date"
                placeholder="Von Datum"
                value={filterDateFrom}
                onChange={(e) => setFilterDateFrom(e.target.value)}
              />
            </div>
            
            <div>
              <Input
                type="date"
                placeholder="Bis Datum"
                value={filterDateTo}
                onChange={(e) => setFilterDateTo(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {filteredRatings.length} von {userRatings.length} Bewertungen
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bewertungsliste */}
      <div className="space-y-4">
        {currentRatings.map((rating) => (
          <Card key={rating.id} className="transition-all hover:shadow-md">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-3">
                    <Calendar className="w-4 h-4 text-blue-600" />
                    <h3 className="font-semibold">
                      Unterricht vom {new Date(rating.lessonDate).toLocaleDateString('de-DE')}
                    </h3>
                  </div>
                  
                  <div className="grid gap-4 md:grid-cols-2 mb-3">
                    <div>
                      <p className="text-sm font-medium mb-1">Mitarbeit</p>
                      <div className="flex items-center gap-2">
                        {renderStars(rating.participation)}
                        <span className="text-sm text-gray-600">{rating.participation}/5</span>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">Sozialverhalten</p>
                      <div className="flex items-center gap-2">
                        {renderStars(rating.socialBehavior)}
                        <span className="text-sm text-gray-600">{rating.socialBehavior}/5</span>
                      </div>
                    </div>
                  </div>
                  
                  {rating.customCategory && (
                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">{rating.customCategory.name}</p>
                      <div className="flex items-center gap-2">
                        {renderStars(rating.customCategory.rating)}
                        <span className="text-sm text-gray-600">{rating.customCategory.rating}/5</span>
                      </div>
                    </div>
                  )}
                  
                  {rating.comment && (
                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">Kommentar</p>
                      <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                        {rating.comment}
                      </p>
                    </div>
                  )}
                  
                  <div className="text-xs text-gray-500">
                    <p>
                      Erstellt von {getCreatorName(rating.createdBy)} am {new Date(rating.createdAt).toLocaleString('de-DE')}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Paginierung */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          
          <span className="py-2 px-4 text-sm">
            Seite {currentPage} von {totalPages}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}

      {sortedRatings.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <Star className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Keine Bewertungen gefunden.</p>
            <p className="text-sm text-gray-500">
              {userRatings.length === 0 
                ? 'Es wurden noch keine Bewertungen für dich erstellt.' 
                : 'Passe deine Filterkriterien an, um Ergebnisse zu sehen.'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}