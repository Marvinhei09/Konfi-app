import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { UserProfile } from '../common/UserProfile';
import { QuizInterface } from '../quiz/QuizInterface';
import { CategorySelector } from '../quiz/CategorySelector';
import { StudentPass } from './StudentPass';
import { PasswordChangeForm } from './PasswordChangeForm';
import { RankingDashboard } from '../ranking/RankingDashboard';
import { TrueFalseQuiz } from '../quiz/TrueFalseQuiz';
import { SequenceQuiz } from '../quiz/SequenceQuiz';
import { Play, History, Calendar, LogOut, Trophy, Clock, QrCode, Settings, Key, Brain, BookOpen, MessageSquare, Shield, User as UserIcon, Check, ListOrdered } from 'lucide-react';
import type { User, Question, QuizHistory, CalendarEvent, KonfiPass, KonfiContact } from '@/types';

interface StudentDashboardProps {
  user: User;
  questions: Question[];
  history: QuizHistory[];
  events: CalendarEvent[];
  passes: KonfiPass[];
  contacts: KonfiContact[];
  users: User[];
  onUsersChange: (users: User[]) => void;
  onQuizComplete: (result: Omit<QuizHistory, 'id'>) => void;
  onPasswordChange: (newPassword: string) => void;
  onNavigateToLearning: () => void;
  onEmergencyChat?: () => void;
  onLogout: () => void;
}

export function StudentDashboard({ 
  user,
  questions, 
  history, 
  events, 
  passes,
  contacts,
  users,
  onUsersChange,
  onQuizComplete, 
  onPasswordChange,
  onNavigateToLearning,
  onEmergencyChat,
  onLogout 
}: StudentDashboardProps) {
  const [currentView, setCurrentView] = useState<'dashboard' | 'category-select' | 'quiz' | 'history' | 'calendar' | 'pass' | 'password' | 'ranking' | 'true-false' | 'sequence'>('dashboard');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [categoryQuestions, setCategoryQuestions] = useState<Question[]>([]);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);

  const userHistory = history.filter(h => h.user === user.username);
  const averageScore = userHistory.length > 0 
    ? Math.round((userHistory.reduce((sum, h) => sum + (h.points / h.max), 0) / userHistory.length) * 100)
    : 0;

  const userPass = passes.find(p => p.konfiUsername === user.username);
  const userContact = contacts.find(c => c.username === user.username);

  // Filter events based on user's role
  const availableEvents = events.filter(event => {
    if (user.role === 'admin') return true;
    if (!event.allowedRoles) return true;
    
    // Für Teamer: Zeige Termine die für Teamer oder alle Rollen sind
    if (user.role === 'teamer') {
      return event.allowedRoles.includes('teamer');
    }
    
    // Für Pastoren: Zeige Termine die für Pastoren oder alle Rollen sind
    if (user.role === 'pastor') {
      return event.allowedRoles.includes('pastor');
    }
    
    // Für Konfis: Zeige Termine für ihre spezifische Rolle
    if (user.role === 'konfi' && user.konfiRole) {
      return event.allowedRoles.includes(user.konfiRole);
    }
    
    return false;
  });

  const upcomingEvents = availableEvents
    .filter(e => new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 3);

  // Filter questions based on user's konfi role
  const availableQuestions = questions.filter(question => {
    if (user.role === 'admin') return true;
    if (!question.allowedRoles) return true;
    return question.allowedRoles.includes(user.konfiRole!);
  });

  // Spezielle Fragetypen filtern
  const trueFalseQuestions = availableQuestions.filter(q => q.type === 'true-false');
  const sequenceQuestions = availableQuestions.filter(q => q.type === 'sequence');

  const getScoreBadge = (points: number, max: number) => {
    const percentage = (points / max) * 100;
    if (percentage >= 80) return { variant: "default" as const, text: "Ausgezeichnet", color: "text-green-600" };
    if (percentage >= 60) return { variant: "secondary" as const, text: "Gut", color: "text-blue-600" };
    return { variant: "destructive" as const, text: "Übung nötig", color: "text-red-600" };
  };

  const handleCategorySelect = (category: string, questions: Question[]) => {
    setSelectedCategory(category);
    setCategoryQuestions(questions);
    setCurrentView('quiz');
  };

  const handleQuizComplete = (result: Omit<QuizHistory, 'id'>) => {
    const resultWithCategory = {
      ...result,
      category: selectedCategory
    };
    onQuizComplete(resultWithCategory);
    setCurrentView('dashboard');
  };

  const handleSpecialQuizComplete = (score: number, total: number) => {
    const result: Omit<QuizHistory, 'id'> = {
      user: user.username,
      date: new Date().toLocaleString('de-DE'),
      points: score,
      max: total,
      category: selectedQuestion?.topic || 'Spezial-Quiz'
    };
    
    onQuizComplete(result);
    setCurrentView('dashboard');
    setSelectedQuestion(null);
  };

  const handlePasswordChange = (newPassword: string) => {
    onPasswordChange(newPassword);
    setCurrentView('dashboard');
  };

  if (currentView === 'category-select') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <CategorySelector 
            questions={questions}
            user={user}
            onCategorySelect={handleCategorySelect}
            onBack={() => setCurrentView('dashboard')}
          />
        </div>
      </div>
    );
  }

  if (currentView === 'quiz') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Quiz: {selectedCategory}</h1>
              <p className="text-gray-600">{categoryQuestions.length} Fragen</p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => setCurrentView('dashboard')}
            >
              Zurück zum Dashboard
            </Button>
          </div>
          <QuizInterface 
            questions={categoryQuestions}
            onComplete={handleQuizComplete}
            username={user.username}
          />
        </div>
      </div>
    );
  }

  if (currentView === 'true-false' && selectedQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Wahr/Falsch Quiz: {selectedQuestion.topic}</h1>
              <p className="text-gray-600">{selectedQuestion.statements?.length || 0} Aussagen</p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => {
                setCurrentView('dashboard');
                setSelectedQuestion(null);
              }}
            >
              Abbrechen
            </Button>
          </div>
          <TrueFalseQuiz 
            question={selectedQuestion}
            onComplete={handleSpecialQuizComplete}
            onBack={() => {
              setCurrentView('dashboard');
              setSelectedQuestion(null);
            }}
          />
        </div>
      </div>
    );
  }

  if (currentView === 'sequence' && selectedQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Sequenz-Quiz: {selectedQuestion.topic}</h1>
              <p className="text-gray-600">{selectedQuestion.sequence?.length || 0} Elemente</p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => {
                setCurrentView('dashboard');
                setSelectedQuestion(null);
              }}
            >
              Abbrechen
            </Button>
          </div>
          <SequenceQuiz 
            question={selectedQuestion}
            onComplete={handleSpecialQuizComplete}
            onBack={() => {
              setCurrentView('dashboard');
              setSelectedQuestion(null);
            }}
          />
        </div>
      </div>
    );
  }

  if (currentView === 'pass' && userPass && userContact) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Mein Konfirmationspass</h1>
            <Button 
              variant="outline" 
              onClick={() => setCurrentView('dashboard')}
            >
              Zurück zum Dashboard
            </Button>
          </div>
          <StudentPass pass={userPass} contact={userContact} />
        </div>
      </div>
    );
  }

  if (currentView === 'password') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto max-w-2xl">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setCurrentView('dashboard')}
              className="mb-4"
            >
              Zurück zum Dashboard
            </Button>
          </div>
          <PasswordChangeForm 
            user={user}
            onPasswordChange={handlePasswordChange}
            onClose={() => setCurrentView('dashboard')}
          />
        </div>
      </div>
    );
  }

  if (currentView === 'ranking') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Ranking & Leistung</h1>
            <Button 
              variant="outline" 
              onClick={() => setCurrentView('dashboard')}
            >
              Zurück zum Dashboard
            </Button>
          </div>
          <RankingDashboard
            users={users}
            onUsersChange={onUsersChange}
            currentUser={user}
            isAdminView={false}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Willkommen, {userContact?.firstName || user.firstName || user.username.split('.')[0]}!
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-gray-600">Bereit für das nächste Quiz?</p>
              {user.role === 'konfi' && (
                <Badge variant="outline">
                  {user.konfiRole}
                </Badge>
              )}
              {user.rank && (
                <Badge variant="default" className="bg-yellow-500">
                  Rang #{user.rank}
                </Badge>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              onClick={() => setCurrentView('password')} 
              variant="outline" 
              className="gap-2"
            >
              <Key className="w-4 h-4" />
              Passwort ändern
            </Button>
            <UserProfile 
              user={user} 
              onLogout={onLogout}
              onSettings={() => setCurrentView('password')}
              onEmergencyChat={onEmergencyChat}
            />
          </div>
        </div>

        {currentView === 'dashboard' && (
          <>
            <div className="grid gap-6 mb-8 md:grid-cols-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Quiz absolviert</p>
                      <p className="text-3xl font-bold">{userHistory.length}</p>
                    </div>
                    <Trophy className="w-8 h-8 text-blue-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">Durchschnitt</p>
                      <p className="text-3xl font-bold">{averageScore}%</p>
                    </div>
                    <div className="text-green-200">📊</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-indigo-100">Aktivitäten</p>
                      <p className="text-3xl font-bold">{userPass?.signatures.length || 0}</p>
                    </div>
                    <QrCode className="w-8 h-8 text-indigo-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Mein Rang</p>
                      <p className="text-3xl font-bold">#{user.rank || '?'}</p>
                    </div>
                    <Trophy className="w-8 h-8 text-purple-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Play className="w-5 h-5 text-blue-600" />
                    Quiz starten
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Wählen Sie eine Kategorie und testen Sie Ihr Wissen mit verschiedenen Fragetypen.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>Verfügbare Fragen für Ihre Rolle ({user.konfiRole}): {availableQuestions.length}</p>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="outline" className="gap-1">
                        <BookOpen className="w-3 h-3" />
                        Multiple-Choice: {availableQuestions.filter(q => !q.type || q.type === 'multiple-choice').length}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <Check className="w-3 h-3" />
                        Wahr/Falsch: {trueFalseQuestions.length}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <ListOrdered className="w-3 h-3" />
                        Sequenz: {sequenceQuestions.length}
                      </Badge>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setCurrentView('category-select')} 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    disabled={availableQuestions.length === 0}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Kategorie wählen
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-600" />
                    Lernplattform
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Zugriff auf digitale Karteikarten, Lernmaterialien und interaktive Übungen.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>• Digitale Karteikarten zum Wiederholen</p>
                    <p>• PDF-Dokumente und Zusammenfassungen</p>
                    <p>• Selbsttest-Funktionen</p>
                  </div>
                  <Button 
                    onClick={onNavigateToLearning} 
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Lernplattform öffnen
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Spezielle Quiztypen */}
            <div className="grid gap-6 lg:grid-cols-2 mt-6">
              <Card className="bg-gradient-to-br from-green-50 to-teal-50 border-green-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-800">
                    <Check className="w-5 h-5" />
                    Wahr/Falsch Quiz
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-700">
                    Testen Sie Ihr Wissen mit Wahr/Falsch-Fragen zu verschiedenen Themen.
                  </p>
                  
                  {trueFalseQuestions.length > 0 ? (
                    <div className="space-y-3">
                      {trueFalseQuestions.slice(0, 3).map(question => (
                        <Button
                          key={question.id}
                          variant="outline"
                          className="w-full justify-start text-left h-auto py-3"
                          onClick={() => {
                            setSelectedQuestion(question);
                            setCurrentView('true-false');
                          }}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span className="font-medium">{question.topic}</span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              {question.question}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {question.statements?.length || 0} Aussagen
                            </p>
                          </div>
                        </Button>
                      ))}
                      
                      {trueFalseQuestions.length > 3 && (
                        <p className="text-xs text-center text-gray-500">
                          +{trueFalseQuestions.length - 3} weitere Wahr/Falsch-Quizze
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic">
                      Keine Wahr/Falsch-Fragen für Ihre Rolle verfügbar.
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-800">
                    <ListOrdered className="w-5 h-5" />
                    Sequenz-Rätsel
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-700">
                    Bringen Sie Ereignisse, Begriffe oder Konzepte in die richtige Reihenfolge.
                  </p>
                  
                  {sequenceQuestions.length > 0 ? (
                    <div className="space-y-3">
                      {sequenceQuestions.slice(0, 3).map(question => (
                        <Button
                          key={question.id}
                          variant="outline"
                          className="w-full justify-start text-left h-auto py-3"
                          onClick={() => {
                            setSelectedQuestion(question);
                            setCurrentView('sequence');
                          }}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <ListOrdered className="w-4 h-4 text-purple-600" />
                              <span className="font-medium">{question.topic}</span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              {question.question}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {question.sequence?.length || 0} Elemente
                            </p>
                          </div>
                        </Button>
                      ))}
                      
                      {sequenceQuestions.length > 3 && (
                        <p className="text-xs text-center text-gray-500">
                          +{sequenceQuestions.length - 3} weitere Sequenz-Rätsel
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic">
                      Keine Sequenz-Fragen für Ihre Rolle verfügbar.
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2 mt-6">
              {/* Vertraulicher Chat für Konfirmanden - nur anzeigen wenn verfügbar */}
              {user.role === 'konfi' && onEmergencyChat && (
                <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-800">
                      <MessageSquare className="w-5 h-5" />
                      Vertraulicher Chat
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700">
                      Haben Sie Sorgen oder Probleme? Sprechen Sie vertraulich mit einem Betreuer oder Pastor.
                    </p>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-green-600" />
                        <span>Ende-zu-Ende verschlüsselt</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-blue-600" />
                        <span>Automatische Löschung nach 5 Tagen</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <UserIcon className="w-4 h-4 text-purple-600" />
                        <span>Nur Sie und Ihr Gesprächspartner</span>
                      </div>
                    </div>
                    <Button 
                      onClick={onEmergencyChat}
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Vertraulichen Chat starten
                    </Button>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                    Meine Leistung & Ranking
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold text-yellow-600">Rang #{user.rank || '?'}</p>
                      <p className="text-sm text-gray-600">
                        Gesamtpunktzahl: {user.totalScore || 0}%
                      </p>
                    </div>
                    <Trophy className="w-12 h-12 text-yellow-500" />
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Quiz-Leistung:</span>
                      <span>{user.quizScore || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Anwesenheit:</span>
                      <span>{user.attendanceScore || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mitarbeit:</span>
                      <span>{user.participationScore || 0}%</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setCurrentView('ranking')} 
                    className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
                  >
                    <Trophy className="w-4 h-4 mr-2" />
                    Vollständiges Ranking anzeigen
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-indigo-600" />
                    Mein Konfirmationspass
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {userPass ? (
                    <>
                      <p className="text-gray-600">
                        Verfolge deinen Fortschritt zur Konfirmation mit {userPass.signatures.length} erfassten Aktivitäten.
                      </p>
                      <Button 
                        onClick={() => setCurrentView('pass')} 
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                      >
                        <QrCode className="w-4 h-4 mr-2" />
                        Pass anzeigen
                      </Button>
                    </>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-gray-500">Noch kein Konfirmationspass erstellt.</p>
                      <p className="text-sm text-gray-400">Wende dich an deinen Betreuer.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-green-600" />
                    Nächste Termine
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upcomingEvents.length === 0 ? (
                    <p className="text-gray-500">Keine bevorstehenden Termine für Ihre Rolle</p>
                  ) : (
                    <div className="space-y-3">
                      {upcomingEvents.map((event) => (
                        <div key={event.id} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                          <Calendar className="w-4 h-4 text-green-600 mt-1" />
                          <div className="flex-1">
                            <p className="font-semibold text-sm">{event.title}</p>
                            <p className="text-xs text-gray-600">
                              {new Date(event.date).toLocaleDateString('de-DE', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </p>
                            {event.description && (
                              <p className="text-xs text-gray-500 mt-1">{event.description}</p>
                            )}
                            {event.allowedRoles && (
                              <div className="flex gap-1 mt-1">
                                {event.allowedRoles.map(role => (
                                  <Badge key={role} variant="outline" className="text-xs">
                                    {role === 'teamer' ? 'Teamer' : role === 'pastor' ? 'Pastor' : role}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentView('calendar')}
                    className="w-full mt-4"
                  >
                    Alle Termine anzeigen
                  </Button>
                </CardContent>
              </Card>

              {userHistory.length > 0 && (
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="flex items-center gap-2">
                        <History className="w-5 h-5 text-purple-600" />
                        Letzte Ergebnisse
                      </CardTitle>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setCurrentView('history')}
                      >
                        Alle anzeigen
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {userHistory.slice(0, 3).map((result) => {
                        const badge = getScoreBadge(result.points, result.max);
                        const percentage = Math.round((result.points / result.max) * 100);
                        
                        return (
                          <div key={result.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                              <Badge variant={badge.variant} className="mb-1">{badge.text}</Badge>
                              <p className="text-sm text-gray-600">{result.date}</p>
                              <p className="text-xs text-gray-500">{result.category}</p>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold">{result.points}/{result.max}</div>
                              <div className="text-sm text-gray-600">{percentage}%</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </>
        )}

        {currentView === 'history' && (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Deine Quiz-Historie</CardTitle>
                <Button 
                  variant="outline" 
                  onClick={() => setCurrentView('dashboard')}
                >
                  Zurück
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {userHistory.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Trophy className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Du hast noch kein Quiz abgeschlossen</p>
                  <p className="text-sm">Starte dein erstes Quiz, um hier Ergebnisse zu sehen</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {userHistory.map((result) => {
                    const badge = getScoreBadge(result.points, result.max);
                    const percentage = Math.round((result.points / result.max) * 100);
                    
                    return (
                      <Card key={result.id} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <Badge variant={badge.variant}>{badge.text}</Badge>
                                <Badge variant="outline">{result.category}</Badge>
                              </div>
                              <p className="text-sm text-gray-600">{result.date}</p>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold">{result.points}/{result.max}</div>
                              <div className="text-sm text-gray-600">{percentage}%</div>
                
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {currentView === 'calendar' && (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Terminkalender</CardTitle>
                <Button 
                  variant="outline" 
                  onClick={() => setCurrentView('dashboard')}
                >
                  Zurück
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {availableEvents.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Keine Termine für Ihre Rolle verfügbar</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {availableEvents
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map((event) => (
                      <Card key={event.id} className="border-l-4 border-l-green-500">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <Calendar className="w-5 h-5 text-green-600 mt-1" />
                            <div>
                              <h4 className="font-semibold">{event.title}</h4>
                              <p className="text-sm text-gray-600 mb-1">
                                {new Date(event.date).toLocaleDateString('de-DE', {
                                  weekday: 'long',
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}
                              </p>
                              {event.description && (
                                <p className="text-sm text-gray-700">{event.description}</p>
                              )}
                              {event.allowedRoles && (
                                <div className="mt-2">
                                  <div className="flex gap-1">
                                    {event.allowedRoles.map(role => (
                                      <Badge key={role} variant="outline" className="text-xs">
                                        {role === 'teamer' ? 'Teamer' : role === 'pastor' ? 'Pastor' : role}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}