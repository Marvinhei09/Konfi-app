import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, Search, Filter, Download, Eye, Play, Clock, 
  Target, TrendingUp, Award, FileText, Image, Video, Music, File
} from 'lucide-react';
import type { Flashcard, LearningMaterial, User, StudySession } from '@/types';

interface StudentLearningViewProps {
  flashcards: Flashcard[];
  materials: LearningMaterial[];
  studySessions: StudySession[];
  currentUser: User;
  onStartFlashcardStudy: () => void;
}

export function StudentLearningView({ 
  flashcards, 
  materials, 
  studySessions, 
  currentUser,
  onStartFlashcardStudy 
}: StudentLearningViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');

  // Filter content based on user role
  const availableFlashcards = flashcards.filter(card => {
    if (!card.allowedRoles) return true;
    return currentUser.konfiRole && card.allowedRoles.includes(currentUser.konfiRole);
  });

  const availableMaterials = materials.filter(material => {
    if (!material.allowedRoles) return true;
    return currentUser.konfiRole && material.allowedRoles.includes(currentUser.konfiRole);
  });

  // Filter materials based on search and filters
  const filteredMaterials = availableMaterials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesTopic = selectedTopic === 'all' || material.topic === selectedTopic;
    const matchesType = selectedType === 'all' || material.type === selectedType;
    
    return matchesSearch && matchesTopic && matchesType;
  });

  // Get user statistics
  const userSessions = studySessions.filter(s => s.userId === currentUser.username);
  const totalStudyTime = userSessions.reduce((sum, s) => sum + s.duration, 0);
  const totalCardsStudied = userSessions.reduce((sum, s) => sum + s.flashcardsStudied.length, 0);
  const averageAccuracy = userSessions.length > 0 
    ? Math.round(userSessions.reduce((sum, s) => sum + (s.correctAnswers / s.totalAnswers), 0) / userSessions.length * 100)
    : 0;

  // Get topics
  const topics = [...new Set([...availableFlashcards.map(f => f.topic), ...availableMaterials.map(m => m.topic)])];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="w-4 h-4" />;
      case 'image': return <Image className="w-4 h-4" />;
      case 'summary': return <BookOpen className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'audio': return <Music className="w-4 h-4" />;
      default: return <File className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'pdf': return 'PDF-Dokument';
      case 'image': return 'Bild/Grafik';
      case 'summary': return 'Zusammenfassung';
      case 'video': return 'Video';
      case 'audio': return 'Audio';
      default: return type;
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      {/* Lernstatistiken */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Karteikarten</p>
                <p className="text-2xl font-bold">{availableFlashcards.length}</p>
              </div>
              <BookOpen className="w-6 h-6 text-blue-200" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Lernzeit</p>
                <p className="text-2xl font-bold">{totalStudyTime}</p>
                <p className="text-xs text-green-200">Minuten</p>
              </div>
              <Clock className="w-6 h-6 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Gelernte Karten</p>
                <p className="text-2xl font-bold">{totalCardsStudied}</p>
              </div>
              <Target className="w-6 h-6 text-purple-200" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">Genauigkeit</p>
                <p className="text-2xl font-bold">{averageAccuracy}%</p>
              </div>
              <Award className="w-6 h-6 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Karteikarten-Bereich */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            Digitale Karteikarten
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600">
            Lernen Sie mit interaktiven Karteikarten und verfolgen Sie Ihren Fortschritt.
          </p>
          
          <div className="grid gap-4 md:grid-cols-3">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{availableFlashcards.length}</div>
              <div className="text-sm text-gray-600">Verfügbare Karten</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{userSessions.length}</div>
              <div className="text-sm text-gray-600">Lernsessions</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{topics.length}</div>
              <div className="text-sm text-gray-600">Themen</div>
            </div>
          </div>

          <Button 
            onClick={onStartFlashcardStudy}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            disabled={availableFlashcards.length === 0}
          >
            <Play className="w-4 h-4 mr-2" />
            Karteikarten lernen
          </Button>
        </CardContent>
      </Card>

      {/* Such- und Filterbereich */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Materialien suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Alle Themen</option>
              {topics.map(topic => (
                <option key={topic} value={topic}>{topic}</option>
              ))}
            </select>
            
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Alle Typen</option>
              <option value="pdf">PDF-Dokumente</option>
              <option value="image">Bilder/Grafiken</option>
              <option value="summary">Zusammenfassungen</option>
              <option value="video">Videos</option>
              <option value="audio">Audio</option>
            </select>
            
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {filteredMaterials.length} von {availableMaterials.length}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lernmaterialien */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredMaterials.map((material) => (
          <Card key={material.id} className="transition-all hover:shadow-lg border-l-4 border-l-blue-500">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  {getTypeIcon(material.type)}
                  <Badge variant="secondary">{material.topic}</Badge>
                </div>
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={() => {
                      if (material.type === 'summary') {
                        // Zeige Zusammenfassung in einem Modal
                        alert('Zusammenfassung: ' + material.title);
                      } else if (material.fileUrl) {
                        window.open(material.fileUrl, '_blank');
                      }
                    }}
                    className="h-6 w-6 p-0"
                    title="Anzeigen"
                  >
                    <Eye className="w-3 h-3" />
                  </Button>
                  {material.fileUrl && material.type !== 'summary' && (
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = material.fileUrl!;
                        link.download = material.fileName || material.title;
                        link.click();
                      }}
                      className="h-6 w-6 p-0"
                      title="Herunterladen"
                    >
                      <Download className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold">{material.title}</h4>
                <p className="text-sm text-gray-600 line-clamp-2">{material.description}</p>
                
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Badge variant="outline" className="text-xs">
                    {getTypeLabel(material.type)}
                  </Badge>
                  {material.fileSize && (
                    <span>{formatFileSize(material.fileSize)}</span>
                  )}
                </div>
              </div>

              <div className="mt-3 pt-3 border-t">
                {material.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {material.tags.slice(0, 3).map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                    {material.tags.length > 3 && (
                      <span className="text-xs text-gray-500">+{material.tags.length - 3}</span>
                    )}
                  </div>
                )}
                
                <p className="text-xs text-gray-500">
                  Von {material.uploadedBy} • {new Date(material.uploadedAt).toLocaleDateString('de-DE')}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMaterials.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {availableMaterials.length === 0 
                ? 'Noch keine Lernmaterialien für Ihre Rolle verfügbar.' 
                : 'Keine Materialien entsprechen den Suchkriterien.'
              }
            </p>
            <p className="text-sm text-gray-500">
              Warten Sie auf neue Materialien von Ihren Lehrern.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Fortschrittsübersicht */}
      {userSessions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              Mein Lernfortschritt
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Gesamtfortschritt</span>
                    <span>{averageAccuracy}%</span>
                  </div>
                  <Progress value={averageAccuracy} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Lernzeit diese Woche</span>
                    <span>{totalStudyTime} Min</span>
                  </div>
                  <Progress value={Math.min((totalStudyTime / 120) * 100, 100)} className="h-2" />
                </div>
              </div>

              <div className="text-sm text-gray-600">
                <p>Letzte Lernsession: {userSessions.length > 0 ? new Date(userSessions[userSessions.length - 1].date).toLocaleDateString('de-DE') : 'Noch keine'}</p>
                <p>Durchschnittliche Genauigkeit: {averageAccuracy}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}