import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Trophy, Users } from 'lucide-react';
import type { QuizHistory } from '@/types';

interface QuizHistoryViewProps {
  history: QuizHistory[];
}

export function QuizHistoryView({ history }: QuizHistoryViewProps) {
  const uniqueUsers = new Set(history.map(h => h.user)).size;
  const averageScore = history.length > 0 
    ? Math.round((history.reduce((sum, h) => sum + (h.points / h.max), 0) / history.length) * 100)
    : 0;
  
  const sortedHistory = [...history].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const getScoreBadge = (points: number, max: number) => {
    const percentage = (points / max) * 100;
    if (percentage >= 80) return { variant: "default" as const, text: "Ausgezeichnet" };
    if (percentage >= 60) return { variant: "secondary" as const, text: "Gut" };
    return { variant: "destructive" as const, text: "Übung nötig" };
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Gesamt Quiz</p>
                <p className="text-3xl font-bold">{history.length}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aktive Konfis</p>
                <p className="text-3xl font-bold">{uniqueUsers}</p>
              </div>
              <Users className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Durchschnitt</p>
                <p className="text-3xl font-bold">{averageScore}%</p>
              </div>
              <Trophy className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quiz Verlauf</CardTitle>
        </CardHeader>
        <CardContent>
          {history.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <BarChart3 className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Noch keine Quiz durchgeführt</p>
              <p className="text-sm">Die Ergebnisse werden hier angezeigt</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {sortedHistory.map((result) => {
                const badge = getScoreBadge(result.points, result.max);
                const percentage = Math.round((result.points / result.max) * 100);
                
                return (
                  <Card key={result.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">{result.user}</span>
                            <Badge variant={badge.variant}>{badge.text}</Badge>
                          </div>
                          <p className="text-sm text-gray-600">{result.date}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">
                            {result.points}/{result.max}
                          </div>
                          <div className="text-sm text-gray-600">
                            {percentage}%
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}