import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Plus, Edit, Trash2, Save, X, Phone, Mail, MapPin, Calendar, User, Key, CheckCircle } from 'lucide-react';
import type { KonfiContact, User as UserType } from '@/types';

interface ContactManagerProps {
  contacts: KonfiContact[];
  onContactsChange: (contacts: KonfiContact[]) => void;
  users?: UserType[];
  onUsersChange?: (users: UserType[]) => void;
}

export function ContactManager({ contacts, onContactsChange, users = [], onUsersChange }: ContactManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedContact, setSelectedContact] = useState<KonfiContact | null>(null);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  // Form state
  const [formData, setFormData] = useState<Omit<KonfiContact, 'id'>>({
    username: '',
    firstName: '',
    lastName: '',
    birthDate: '',
    address: {
      street: '',
      postalCode: '',
      city: ''
    },
    phone: '',
    email: '',
    parentName: '',
    parentPhone: '',
    notes: '',
    konfiRole: 'KU4'
  });

  const generateSecurePassword = () => {
    const uppercase = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowercase = 'abcdefghijkmnpqrstuvwxyz';
    const numbers = '23456789';
    const symbols = '!@#$%&*';
    
    let password = '';
    password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
    password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
    password += numbers.charAt(Math.floor(Math.random() * numbers.length));
    password += symbols.charAt(Math.floor(Math.random() * symbols.length));
    
    const allChars = uppercase + lowercase + numbers + symbols;
    for (let i = 4; i < 10; i++) {
      password += allChars.charAt(Math.floor(Math.random() * allChars.length));
    }
    
    return password.split('').sort(() => Math.random() - 0.5).join('');
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleAdd = () => {
    if (!formData.firstName || !formData.lastName || !formData.username) {
      showNotification('error', 'Vorname, Nachname und Benutzername sind erforderlich');
      return;
    }

    // Check if username already exists
    if (users.some(u => u.username === formData.username) || 
        contacts.some(c => c.username === formData.username)) {
      showNotification('error', 'Benutzername bereits vergeben');
      return;
    }

    const newContact: KonfiContact = {
      id: Date.now().toString(),
      ...formData
    };

    onContactsChange([...contacts, newContact]);

    // Automatically create user account if onUsersChange is provided
    if (onUsersChange) {
      const generatedPassword = generateSecurePassword();
      const newUser: UserType = {
        id: (Date.now() + 1).toString(),
        username: formData.username,
        password: generatedPassword,
        role: 'konfi',
        konfiRole: formData.konfiRole
      };

      onUsersChange([...users, newUser]);
      
      showNotification('success', 
        `Konfi und Benutzerkonto erfolgreich erstellt!\nBenutzername: ${formData.username}\nPasswort: ${generatedPassword}\n(Passwort wurde automatisch generiert)`
      );
    } else {
      showNotification('success', 'Konfi erfolgreich hinzugefügt');
    }

    resetForm();
    setShowAddForm(false);
  };

  const handleEdit = (contact: KonfiContact) => {
    setEditingId(contact.id);
    setFormData({
      username: contact.username,
      firstName: contact.firstName,
      lastName: contact.lastName,
      birthDate: contact.birthDate,
      address: { ...contact.address },
      phone: contact.phone,
      email: contact.email || '',
      parentName: contact.parentName || '',
      parentPhone: contact.parentPhone || '',
      notes: contact.notes || '',
      konfiRole: contact.konfiRole || 'KU4'
    });
  };

  const handleSave = () => {
    if (!editingId) return;

    const updatedContacts = contacts.map(c => 
      c.id === editingId 
        ? { ...c, ...formData }
        : c
    );

    onContactsChange(updatedContacts);
    
    // Update corresponding user if exists
    if (onUsersChange) {
      const updatedUsers = users.map(u => 
        u.username === formData.username 
          ? { ...u, konfiRole: formData.konfiRole }
          : u
      );
      onUsersChange(updatedUsers);
    }

    showNotification('success', 'Konfi erfolgreich aktualisiert');
    setEditingId(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    const contactToDelete = contacts.find(c => c.id === id);
    if (contactToDelete) {
      onContactsChange(contacts.filter(c => c.id !== id));
      
      // Also delete corresponding user account
      if (onUsersChange) {
        const updatedUsers = users.filter(u => u.username !== contactToDelete.username);
        onUsersChange(updatedUsers);
      }
      
      showNotification('success', `Konfi "${contactToDelete.firstName} ${contactToDelete.lastName}" wurde gelöscht`);
    }
  };

  const resetForm = () => {
    setFormData({
      username: '',
      firstName: '',
      lastName: '',
      birthDate: '',
      address: {
        street: '',
        postalCode: '',
        city: ''
      },
      phone: '',
      email: '',
      parentName: '',
      parentPhone: '',
      notes: '',
      konfiRole: 'KU4'
    });
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  const getRoleBadgeColor = (role?: string) => {
    switch (role) {
      case 'KU4': return 'secondary';
      case 'KUZ': return 'outline';
      case 'KU8': return 'destructive';
      default: return 'secondary';
    }
  };

  // Auto-generate username from first and last name
  const generateUsername = () => {
    if (formData.firstName && formData.lastName) {
      const username = `${formData.firstName.toLowerCase()}.${formData.lastName.toLowerCase()}`;
      setFormData({ ...formData, username });
    }
  };

  if (selectedContact) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Konfi Details</h2>
          <Button 
            onClick={() => setSelectedContact(null)} 
            variant="outline"
            className="gap-2"
          >
            <X className="w-4 h-4" />
            Zurück zur Übersicht
          </Button>
        </div>

        <Card className="max-w-2xl">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <CardTitle className="text-2xl">
                  {selectedContact.firstName} {selectedContact.lastName}
                </CardTitle>
                <p className="text-gray-600">@{selectedContact.username}</p>
                <div className="flex gap-2 mt-1">
                  <Badge variant="secondary">
                    {calculateAge(selectedContact.birthDate)} Jahre alt
                  </Badge>
                  <Badge variant={getRoleBadgeColor(selectedContact.konfiRole)}>
                    {selectedContact.konfiRole}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold">Geburtstag</p>
                    <p className="text-gray-600">
                      {new Date(selectedContact.birthDate).toLocaleDateString('de-DE', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-green-600 mt-1" />
                  <div>
                    <p className="font-semibold">Telefon</p>
                    <p className="text-gray-600">{selectedContact.phone}</p>
                  </div>
                </div>

                {selectedContact.email && (
                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 text-purple-600 mt-1" />
                    <div>
                      <p className="font-semibold">E-Mail</p>
                      <p className="text-gray-600">{selectedContact.email}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-red-600 mt-1" />
                  <div>
                    <p className="font-semibold">Adresse</p>
                    <p className="text-gray-600">
                      {selectedContact.address.street}<br />
                      {selectedContact.address.postalCode} {selectedContact.address.city}
                    </p>
                  </div>
                </div>

                {selectedContact.parentName && (
                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 text-orange-600 mt-1" />
                    <div>
                      <p className="font-semibold">Eltern</p>
                      <p className="text-gray-600">{selectedContact.parentName}</p>
                      {selectedContact.parentPhone && (
                        <p className="text-gray-600 text-sm">{selectedContact.parentPhone}</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {selectedContact.notes && (
              <div className="border-t pt-4">
                <p className="font-semibold mb-2">Notizen</p>
                <p className="text-gray-600 bg-gray-50 p-3 rounded-lg">
                  {selectedContact.notes}
                </p>
              </div>
            )}

            <div className="flex gap-2 pt-4 border-t">
              <Button 
                onClick={() => handleEdit(selectedContact)}
                className="gap-2"
              >
                <Edit className="w-4 h-4" />
                Bearbeiten
              </Button>
              <Button 
                variant="destructive"
                onClick={() => {
                  handleDelete(selectedContact.id);
                  setSelectedContact(null);
                }}
                className="gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Löschen
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Konfi Kontakte</h2>
        <Button 
          onClick={() => setShowAddForm(true)} 
          className="gap-2"
          disabled={showAddForm || editingId}
        >
          <Plus className="w-4 h-4" />
          Neuer Konfi
        </Button>
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          {notification.type === 'error' ? (
            <X className="h-4 w-4" />
          ) : (
            <CheckCircle className="h-4 w-4" />
          )}
          <AlertDescription className="whitespace-pre-line">
            {notification.message}
          </AlertDescription>
        </Alert>
      )}

      {(showAddForm || editingId) && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>
              {editingId ? 'Konfi bearbeiten' : 'Neuen Konfi hinzufügen'}
              {onUsersChange && !editingId && (
                <span className="text-sm font-normal text-gray-600 block mt-1">
                  Ein Benutzerkonto wird automatisch erstellt
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="firstName">Vorname *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  placeholder="Vorname"
                  onBlur={generateUsername}
                />
              </div>
              <div>
                <Label htmlFor="lastName">Nachname *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  placeholder="Nachname"
                  onBlur={generateUsername}
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="username">Benutzername *</Label>
                <div className="flex gap-2">
                  <Input
                    id="username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    placeholder="z.B. max.mustermann"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={generateUsername}
                    className="gap-2 whitespace-nowrap"
                  >
                    <Key className="w-4 h-4" />
                    Generieren
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="konfiRole">Konfirmanden-Rolle *</Label>
                <Select
                  value={formData.konfiRole}
                  onValueChange={(value: 'KU4' | 'KUZ' | 'KU8') => setFormData({ ...formData, konfiRole: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="KU4">KU4 - 4. Klasse</SelectItem>
                    <SelectItem value="KUZ">KUZ - Zwischenjahr</SelectItem>
                    <SelectItem value="KU8">KU8 - 8. Klasse</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="birthDate">Geburtstag *</Label>
              <Input
                id="birthDate"
                type="date"
                value={formData.birthDate}
                onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="street">Straße und Hausnummer *</Label>
              <Input
                id="street"
                value={formData.address.street}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  address: { ...formData.address, street: e.target.value }
                })}
                placeholder="Musterstraße 123"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="postalCode">Postleitzahl *</Label>
                <Input
                  id="postalCode"
                  value={formData.address.postalCode}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    address: { ...formData.address, postalCode: e.target.value }
                  })}
                  placeholder="12345"
                />
              </div>
              <div>
                <Label htmlFor="city">Stadt *</Label>
                <Input
                  id="city"
                  value={formData.address.city}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    address: { ...formData.address, city: e.target.value }
                  })}
                  placeholder="Musterstadt"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="phone">Telefon *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="0123 456789"
                />
              </div>
              <div>
                <Label htmlFor="email">E-Mail (optional)</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="max@example.com"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="parentName">Name der Eltern (optional)</Label>
                <Input
                  id="parentName"
                  value={formData.parentName}
                  onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                  placeholder="Maria und Hans Mustermann"
                />
              </div>
              <div>
                <Label htmlFor="parentPhone">Telefon der Eltern (optional)</Label>
                <Input
                  id="parentPhone"
                  value={formData.parentPhone}
                  onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                  placeholder="0123 987654"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notizen (optional)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Zusätzliche Informationen..."
                rows={3}
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={editingId ? handleSave : handleAdd} className="gap-2">
                <Save className="w-4 h-4" />
                {editingId ? 'Speichern' : 'Hinzufügen'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                  resetForm();
                }}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {contacts.map((contact) => (
          <Card 
            key={contact.id} 
            className="transition-all hover:shadow-lg cursor-pointer border-l-4 border-l-blue-500"
            onClick={() => setSelectedContact(contact)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{contact.firstName} {contact.lastName}</h3>
                    <p className="text-sm text-gray-600">@{contact.username}</p>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <Badge variant="secondary">
                    {calculateAge(contact.birthDate)} Jahre
                  </Badge>
                  <Badge variant={getRoleBadgeColor(contact.konfiRole)}>
                    {contact.konfiRole}
                  </Badge>
                </div>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Phone className="w-3 h-3" />
                  <span>{contact.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="w-3 h-3" />
                  <span>{contact.address.city}</span>
                </div>
                {contact.email && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Mail className="w-3 h-3" />
                    <span className="truncate">{contact.email}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2 mt-4 pt-3 border-t">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleEdit(contact);
                  }}
                  disabled={editingId === contact.id || showAddForm}
                  className="gap-1 flex-1"
                >
                  <Edit className="w-3 h-3" />
                  Bearbeiten
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(contact.id);
                  }}
                  disabled={editingId === contact.id || showAddForm}
                  className="gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {contacts.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Noch keine Konfis erfasst.</p>
            <p className="text-sm text-gray-500">Fügen Sie den ersten Konfi hinzu, um zu beginnen.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}