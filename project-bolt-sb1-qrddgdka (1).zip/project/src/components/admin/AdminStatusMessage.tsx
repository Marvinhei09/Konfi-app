import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Shield, Clock, Bell, CheckCircle, Plane } from 'lucide-react';

interface AdminStatusMessageProps {
  isAvailable: boolean;
  onToggleAvailability?: () => void;
}

export function AdminStatusMessage({ isAvailable, onToggleAvailability }: AdminStatusMessageProps) {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  
  // Update time every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 60000);
    
    return () => clearInterval(interval);
  }, []);
  
  const formattedDate = currentDateTime.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  
  const formattedTime = currentDateTime.toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <Card className={`border-l-4 ${isAvailable ? 'border-l-green-500 bg-green-50' : 'border-l-red-500 bg-red-50'}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full ${isAvailable ? 'bg-green-100' : 'bg-red-100'} flex items-center justify-center`}>
              <Shield className={`w-5 h-5 ${isAvailable ? 'text-green-600' : 'text-red-600'}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold">
                  {isAvailable ? 'Verfügbar für Notfälle' : 'Nicht verfügbar für Notfälle'}
                </h3>
                <Badge variant={isAvailable ? 'default' : 'outline'} className="text-xs">
                  {isAvailable ? 'Aktiv' : 'Inaktiv'}
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="w-3 h-3" />
                <span>{formattedDate}, {formattedTime} Uhr</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-sm">
              {isAvailable ? (
                <div className="flex items-center gap-1 text-green-600">
                  <CheckCircle className="w-4 h-4" />
                  <span>Bei dringenden Anliegen über den Notfall-Chat erreichbar</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-gray-500">
                  <Plane className="w-4 h-4" />
                  <span>Benachrichtigungen für Notfälle deaktiviert (z.B. Urlaub, unterwegs)</span>
                </div>
              )}
            </div>
            
            {onToggleAvailability && (
              <div className="flex items-center gap-2">
                <Label htmlFor="availability-toggle" className="text-sm">Verfügbarkeit:</Label>
                <Switch 
                  id="availability-toggle" 
                  checked={isAvailable} 
                  onCheckedChange={onToggleAvailability}
                />
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}