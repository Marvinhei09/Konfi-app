import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Calendar, BookOpen, BarChart3, LogOut, Users, QrCode, UserCog, Brain, FileText, Trophy, Award, MessageSquare, Shield, Church, Image as ImageIcon, Star } from 'lucide-react';
import { UserProfile } from '../common/UserProfile';
import { QuestionManager } from './QuestionManager';
import { CalendarManager } from './CalendarManager';
import { QuizHistoryView } from './QuizHistoryView';
import { ContactManager } from './ContactManager';
import { PassManager } from '../pass/PassManager';
import { UserManager } from './UserManager';
import { RankingDashboard } from '../ranking/RankingDashboard';
import { AwardSystem } from '../ranking/AwardSystem';
import { AdminStatusMessage } from './AdminStatusMessage';
import { ChurchLogoUploader } from './ChurchLogoUploader';
import { RatingManager } from './RatingManager';
import type { Question, QuizHistory, CalendarEvent, KonfiContact, KonfiPass, User, Flashcard, LearningMaterial, KonfiRating, RatingAuditLog } from '@/types';

interface AdminDashboardProps {
  questions: Question[];
  onQuestionsChange: (questions: Question[]) => void;
  history: QuizHistory[];
  events: CalendarEvent[];
  onEventsChange: (events: CalendarEvent[]) => void;
  contacts: KonfiContact[];
  onContactsChange: (contacts: KonfiContact[]) => void;
  passes: KonfiPass[];
  onPassesChange: (passes: KonfiPass[]) => void;
  users: User[];
  onUsersChange: (users: User[]) => void;
  flashcards: Flashcard[];
  onFlashcardsChange: (flashcards: Flashcard[]) => void;
  learningMaterials: LearningMaterial[];
  onLearningMaterialsChange: (materials: LearningMaterial[]) => void;
  ratings: KonfiRating[];
  onRatingsChange: (ratings: KonfiRating[]) => void;
  ratingAuditLog: RatingAuditLog[];
  onRatingAuditLogChange: (auditLog: RatingAuditLog[]) => void;
  onNavigateToLearning: () => void;
  onEmergencyChat: () => void;
  onLogout: () => void;
}

export function AdminDashboard({ 
  questions, 
  onQuestionsChange, 
  history, 
  events, 
  onEventsChange,
  contacts,
  onContactsChange,
  passes,
  onPassesChange,
  users,
  onUsersChange,
  flashcards,
  onFlashcardsChange,
  learningMaterials,
  onLearningMaterialsChange,
  ratings,
  onRatingsChange,
  ratingAuditLog,
  onRatingAuditLogChange,
  onNavigateToLearning,
  onEmergencyChat,
  onLogout 
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isAvailableForEmergency, setIsAvailableForEmergency] = useState(true);
  const [showLogoUploader, setShowLogoUploader] = useState(false);
  const [churchLogo, setChurchLogo] = useState<string | undefined>(undefined);

  const totalSignatures = passes.reduce((sum, pass) => sum + pass.signatures.length, 0);
  const currentUser = users.find(u => u.role === 'admin') || users[0];

  const handleToggleAvailability = () => {
    setIsAvailableForEmergency(!isAvailableForEmergency);
    
    // Update user availability in a real app
    // onUsersChange(users.map(u => 
    //   u.id === currentUser.id ? { ...u, isAvailableForEmergency: !isAvailableForEmergency } : u
    // ));
  };

  const handleSaveLogo = (logoUrl: string) => {
    setChurchLogo(logoUrl);
    setShowLogoUploader(false);
    // In a real app, you would save this to a database or localStorage
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            {/* Church Logo */}
            <div 
              className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg cursor-pointer"
              onClick={() => setShowLogoUploader(true)}
            >
              {churchLogo ? (
                <img 
                  src={churchLogo} 
                  alt="Kirchenlogo" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-blue-500 flex items-center justify-center">
                  <Church className="w-8 h-8 text-white" />
                </div>
              )}
            </div>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600 mt-1">Verwalten Sie Quiz, Termine, Kontakte, Pässe, Benutzer und Lernmaterialien</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button onClick={onNavigateToLearning} variant="outline" className="gap-2">
              <Brain className="w-4 h-4" />
              Lernplattform
            </Button>
            <Button onClick={onEmergencyChat} variant="outline" className="gap-2 border-red-300 text-red-700 hover:bg-red-50">
              <Shield className="w-4 h-4" />
              Notfall-Chats
            </Button>
            <UserProfile user={currentUser} onLogout={onLogout} onEmergencyChat={onEmergencyChat} />
          </div>
        </div>

        {/* Admin Status Message */}
        <div className="mb-6">
          <AdminStatusMessage 
            isAvailable={isAvailableForEmergency} 
            onToggleAvailability={handleToggleAvailability}
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-11">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Übersicht
            </TabsTrigger>
            <TabsTrigger value="questions" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Fragen
            </TabsTrigger>
            <TabsTrigger value="calendar" className="gap-2">
              <Calendar className="w-4 h-4" />
              Termine
            </TabsTrigger>
            <TabsTrigger value="contacts" className="gap-2">
              <Users className="w-4 h-4" />
              Kontakte
            </TabsTrigger>
            <TabsTrigger value="passes" className="gap-2">
              <QrCode className="w-4 h-4" />
              Pässe
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <UserCog className="w-4 h-4" />
              Benutzer
            </TabsTrigger>
            <TabsTrigger value="learning" className="gap-2">
              <Brain className="w-4 h-4" />
              Lernplattform
            </TabsTrigger>
            <TabsTrigger value="ratings" className="gap-2">
              <Star className="w-4 h-4" />
              Bewertungen
            </TabsTrigger>
            <TabsTrigger value="ranking" className="gap-2">
              <Trophy className="w-4 h-4" />
              Ranking
            </TabsTrigger>
            <TabsTrigger value="awards" className="gap-2">
              <Award className="w-4 h-4" />
              Auszeichnungen
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Statistiken
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid gap-6 mb-8 md:grid-cols-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Fragen</p>
                      <p className="text-3xl font-bold">{questions.length}</p>
                    </div>
                    <BookOpen className="w-8 h-8 text-blue-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">Termine</p>
                      <p className="text-3xl font-bold">{events.length}</p>
                    </div>
                    <Calendar className="w-8 h-8 text-green-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100">Konfis</p>
                      <p className="text-3xl font-bold">{contacts.length}</p>
                    </div>
                    <Users className="w-8 h-8 text-orange-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-indigo-100">Pässe</p>
                      <p className="text-3xl font-bold">{passes.length}</p>
                    </div>
                    <QrCode className="w-8 h-8 text-indigo-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 mb-8 md:grid-cols-4">
              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Benutzer</p>
                      <p className="text-3xl font-bold">{users.length}</p>
                    </div>
                    <UserCog className="w-8 h-8 text-purple-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-teal-100">Karteikarten</p>
                      <p className="text-3xl font-bold">{flashcards.length}</p>
                    </div>
                    <Brain className="w-8 h-8 text-teal-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-cyan-100">Materialien</p>
                      <p className="text-3xl font-bold">{learningMaterials.length}</p>
                    </div>
                    <FileText className="w-8 h-8 text-cyan-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-pink-500 to-pink-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-pink-100">Unterschriften</p>
                      <p className="text-3xl font-bold">{totalSignatures}</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-pink-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Neue Karte für Bewertungen */}
            <div className="grid gap-6 mb-8 md:grid-cols-1">
              <Card className="bg-gradient-to-br from-yellow-500 to-amber-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-yellow-100">Bewertungen</p>
                      <p className="text-3xl font-bold">{ratings.length}</p>
                    </div>
                    <Star className="w-8 h-8 text-yellow-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid gap-6 lg:grid-cols-3">
              <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-800">
                    <Shield className="w-5 h-5" />
                    Notfall-Chat System
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-700">
                    Überwachen und verwalten Sie vertrauliche Gespräche zwischen Konfirmanden und Betreuern.
                  </p>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Verfügbare Teamer:</span>
                      <span>{users.filter(u => u.role === 'teamer' && u.isAvailableForEmergency).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Verfügbare Pastoren:</span>
                      <span>{users.filter(u => u.role === 'pastor' && u.isAvailableForEmergency).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ende-zu-Ende verschlüsselt:</span>
                      <span className="text-green-600">✓ Aktiv</span>
                    </div>
                  </div>
                  <Button 
                    onClick={onEmergencyChat} 
                    className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                  >
                    <Shield className="w-4 h-4 mr-2" />
                    Notfall-Chats verwalten
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-blue-600" />
                    Lernplattform
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Verwalten Sie digitale Karteikarten und Lernmaterialien für den Konfirmationsunterricht.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>Verfügbare Karten: {flashcards.length}</p>
                    <p>PDFs: {learningMaterials.filter(m => m.type === 'pdf').length}</p>
                    <p>Zusammenfassungen: {learningMaterials.filter(m => m.type === 'summary').length}</p>
                  </div>
                  <Button 
                    onClick={onNavigateToLearning} 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Lernplattform öffnen
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-600" />
                    Bewertungssystem
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Bewerten Sie Mitarbeit und Sozialverhalten der Konfirmanden mit detaillierten Anmerkungen.
                  </p>
                  <div className="text-sm text-gray-500">
                    <p>Bewertungen gesamt: {ratings.length}</p>
                    <p>Bewertete Konfirmanden: {new Set(ratings.map(r => r.konfiId)).size}</p>
                    <p>Letzte Bewertung: {ratings.length > 0 ? new Date(Math.max(...ratings.map(r => new Date(r.createdAt).getTime()))).toLocaleDateString('de-DE') : 'Keine'}</p>
                  </div>
                  <Button 
                    onClick={() => setActiveTab('ratings')} 
                    className="w-full bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700"
                  >
                    <Star className="w-4 h-4 mr-2" />
                    Bewertungen verwalten
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-indigo-600" />
                    Konfirmationspässe
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Digitale Pässe für die Konfirmanden mit QR-Code-Funktionalität und Mehrfachauswahl.
                  </p>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Aktive Pässe:</span>
                      <span>{passes.filter(p => p.isActive).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Gesamte Unterschriften:</span>
                      <span>{totalSignatures}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Durchschnitt pro Pass:</span>
                      <span>{passes.length > 0 ? Math.round(totalSignatures / passes.length) : 0}</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setActiveTab('passes')} 
                    variant="outline"
                    className="w-full"
                  >
                    <QrCode className="w-4 h-4 mr-2" />
                    Pässe verwalten
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                    Ranking & Auszeichnungen
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Dynamisches Leistungsranking mit Auszeichnungssystem für jeden Jahrgang.
                  </p>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Aktive Benutzer:</span>
                      <span>{users.filter(u => u.totalScore && u.totalScore > 0).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Durchschnittsscore:</span>
                      <span>{Math.round(users.reduce((sum, u) => sum + (u.totalScore || 0), 0) / users.length)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Top Performer:</span>
                      <span>{users.find(u => u.rank === 1)?.firstName || 'N/A'}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setActiveTab('ranking')} 
                      variant="outline"
                      className="flex-1"
                    >
                      <Trophy className="w-4 h-4 mr-2" />
                      Ranking
                    </Button>
                    <Button 
                      onClick={() => setActiveTab('awards')} 
                      variant="outline"
                      className="flex-1"
                    >
                      <Award className="w-4 h-4 mr-2" />
                      Auszeichnungen
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Church className="w-5 h-5 text-blue-600" />
                    Kirchenlogo
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Passen Sie das Logo Ihrer Kirche an, das in der Anwendung angezeigt wird.
                  </p>
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-gray-200">
                      {churchLogo ? (
                        <img 
                          src={churchLogo} 
                          alt="Kirchenlogo" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-blue-500 flex items-center justify-center">
                          <Church className="w-12 h-12 text-white" />
                        </div>
                      )}
                    </div>
                  </div>
                  <Button 
                    onClick={() => setShowLogoUploader(true)} 
                    className="w-full"
                  >
                    <ImageIcon className="w-4 h-4 mr-2" />
                    {churchLogo ? 'Logo ändern' : 'Logo hochladen'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="questions" className="mt-6">
            <QuestionManager 
              questions={questions}
              onQuestionsChange={onQuestionsChange}
            />
          </TabsContent>
          
          <TabsContent value="calendar" className="mt-6">
            <CalendarManager 
              events={events}
              onEventsChange={onEventsChange}
            />
          </TabsContent>

          <TabsContent value="contacts" className="mt-6">
            <ContactManager 
              contacts={contacts}
              onContactsChange={onContactsChange}
              users={users}
              onUsersChange={onUsersChange}
            />
          </TabsContent>

          <TabsContent value="passes" className="mt-6">
            <PassManager 
              passes={passes}
              onPassesChange={onPassesChange}
              contacts={contacts}
            />
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <UserManager 
              users={users}
              onUsersChange={onUsersChange}
            />
          </TabsContent>

          <TabsContent value="learning" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    Lernplattform Übersicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Digitale Karteikarten</h3>
                      <div className="grid gap-2 text-sm">
                        <div className="flex justify-between">
                          <span>Gesamt:</span>
                          <span>{flashcards.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Für KU4:</span>
                          <span>{flashcards.filter(f => !f.allowedRoles || f.allowedRoles.includes('KU4')).length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Für KUZ:</span>
                          <span>{flashcards.filter(f => !f.allowedRoles || f.allowedRoles.includes('KUZ')).length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Für KU8:</span>
                          <span>{flashcards.filter(f => !f.allowedRoles || f.allowedRoles.includes('KU8')).length}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">Lernmaterialien</h3>
                      <div className="grid gap-2 text-sm">
                        <div className="flex justify-between">
                          <span>Gesamt:</span>
                          <span>{learningMaterials.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>PDF-Dokumente:</span>
                          <span>{learningMaterials.filter(m => m.type === 'pdf').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Bilder/Grafiken:</span>
                          <span>{learningMaterials.filter(m => m.type === 'image').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Zusammenfassungen:</span>
                          <span>{learningMaterials.filter(m => m.type === 'summary').length}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t">
                    <Button 
                      onClick={onNavigateToLearning} 
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    >
                      <Brain className="w-4 h-4 mr-2" />
                      Zur Lernplattform wechseln
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="ratings" className="mt-6">
            <RatingManager
              ratings={ratings}
              onRatingsChange={onRatingsChange}
              users={users}
              contacts={contacts}
              auditLog={ratingAuditLog}
              onAuditLogChange={onRatingAuditLogChange}
              currentUser={currentUser}
            />
          </TabsContent>

          <TabsContent value="ranking" className="mt-6">
            <RankingDashboard
              users={users}
              onUsersChange={onUsersChange}
              currentUser={currentUser}
              isAdminView={true}
            />
          </TabsContent>

          <TabsContent value="awards" className="mt-6">
            <AwardSystem
              users={users}
              onUsersChange={onUsersChange}
              isAdminView={true}
            />
          </TabsContent>
          
          <TabsContent value="history" className="mt-6">
            <QuizHistoryView history={history} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Church Logo Uploader Modal */}
      {showLogoUploader && (
        <ChurchLogoUploader
          currentLogo={churchLogo}
          onSave={handleSaveLogo}
          onClose={() => setShowLogoUploader(false)}
        />
      )}
    </div>
  );
}