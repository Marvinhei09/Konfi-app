import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Star, Plus, Edit, Trash2, Save, X, Calendar, User as UserIcon, 
  Search, Filter, CheckCircle, AlertCircle, FileText, 
  BarChart3, History, ArrowUpDown, Download
} from 'lucide-react';
import type { KonfiRating, User as UserType, KonfiContact, RatingAuditLog, RatingStats } from '@/types';

interface RatingManagerProps {
  ratings: KonfiRating[];
  onRatingsChange: (ratings: KonfiRating[]) => void;
  users: UserType[];
  contacts: KonfiContact[];
  auditLog: RatingAuditLog[];
  onAuditLogChange: (auditLog: RatingAuditLog[]) => void;
  currentUser: UserType;
}

export function RatingManager({ 
  ratings, 
  onRatingsChange, 
  users, 
  contacts,
  auditLog,
  onAuditLogChange,
  currentUser
}: RatingManagerProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKonfiRole, setFilterKonfiRole] = useState<string>('all');
  const [filterDateFrom, setFilterDateFrom] = useState<string>('');
  const [filterDateTo, setFilterDateTo] = useState<string>('');
  const [sortField, setSortField] = useState<string>('lessonDate');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  const [ratingStats, setRatingStats] = useState<RatingStats[]>([]);
  
  const [formData, setFormData] = useState({
    konfiId: '',
    lessonDate: new Date().toISOString().split('T')[0],
    participation: 3,
    socialBehavior: 3,
    customCategoryName: '',
    customCategoryRating: 3,
    comment: ''
  });

  // Berechne Statistiken für jeden Konfirmanden
  useEffect(() => {
    const stats: RatingStats[] = [];
    
    // Hole alle Konfirmanden
    const konfis = users.filter(user => user.role === 'konfi');
    
    konfis.forEach(konfi => {
      const konfiRatings = ratings.filter(rating => rating.konfiId === konfi.id);
      
      if (konfiRatings.length === 0) return;
      
      const avgParticipation = konfiRatings.reduce((sum, r) => sum + r.participation, 0) / konfiRatings.length;
      const avgSocialBehavior = konfiRatings.reduce((sum, r) => sum + r.socialBehavior, 0) / konfiRatings.length;
      
      // Sammle alle benutzerdefinierten Kategorien
      const customCategories: {[key: string]: number[]} = {};
      konfiRatings.forEach(rating => {
        if (rating.customCategory) {
          const { name, rating: value } = rating.customCategory;
          if (!customCategories[name]) {
            customCategories[name] = [];
          }
          customCategories[name].push(value);
        }
      });
      
      // Berechne Durchschnitt für jede benutzerdefinierte Kategorie
      const customCategoryAverages: {[key: string]: number} = {};
      Object.entries(customCategories).forEach(([name, values]) => {
        customCategoryAverages[name] = values.reduce((sum, val) => sum + val, 0) / values.length;
      });
      
      // Bestimme Trend basierend auf den letzten 3 Bewertungen
      let trend: 'improving' | 'stable' | 'declining' = 'stable';
      if (konfiRatings.length >= 3) {
        const sortedRatings = [...konfiRatings].sort((a, b) => 
          new Date(b.lessonDate).getTime() - new Date(a.lessonDate).getTime()
        );
        
        const recent = sortedRatings.slice(0, 3);
        const avgRecent = recent.reduce((sum, r) => sum + r.participation + r.socialBehavior, 0) / (recent.length * 2);
        
        const older = sortedRatings.slice(Math.max(0, sortedRatings.length - 3));
        const avgOlder = older.reduce((sum, r) => sum + r.participation + r.socialBehavior, 0) / (older.length * 2);
        
        if (avgRecent > avgOlder + 0.5) trend = 'improving';
        else if (avgRecent < avgOlder - 0.5) trend = 'declining';
      }
      
      stats.push({
        konfiId: konfi.id,
        averageParticipation: avgParticipation,
        averageSocialBehavior: avgSocialBehavior,
        customCategoryAverages,
        totalRatings: konfiRatings.length,
        lastRatingDate: konfiRatings.sort((a, b) => 
          new Date(b.lessonDate).getTime() - new Date(a.lessonDate).getTime()
        )[0].lessonDate,
        trend
      });
    });
    
    setRatingStats(stats);
  }, [ratings, users]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleAdd = () => {
    if (!formData.konfiId || !formData.lessonDate) {
      showNotification('error', 'Konfirmand und Datum sind erforderlich');
      return;
    }

    const newRating: KonfiRating = {
      id: Date.now().toString(),
      konfiId: formData.konfiId,
      lessonDate: formData.lessonDate,
      participation: formData.participation,
      socialBehavior: formData.socialBehavior,
      ...(formData.customCategoryName && {
        customCategory: {
          name: formData.customCategoryName,
          rating: formData.customCategoryRating
        }
      }),
      comment: formData.comment,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString()
    };

    onRatingsChange([...ratings, newRating]);
    
    // Audit-Log-Eintrag erstellen
    const newAuditLog: RatingAuditLog = {
      id: Date.now().toString(),
      ratingId: newRating.id,
      action: 'create',
      userId: currentUser.id,
      timestamp: new Date().toISOString(),
      details: `Bewertung für ${getKonfiName(formData.konfiId)} erstellt`,
      newValues: newRating
    };
    
    onAuditLogChange([...auditLog, newAuditLog]);
    
    showNotification('success', 'Bewertung erfolgreich hinzugefügt');
    resetForm();
    setShowAddForm(false);
  };

  const handleEdit = (rating: KonfiRating) => {
    setEditingId(rating.id);
    setFormData({
      konfiId: rating.konfiId,
      lessonDate: rating.lessonDate,
      participation: rating.participation,
      socialBehavior: rating.socialBehavior,
      customCategoryName: rating.customCategory?.name || '',
      customCategoryRating: rating.customCategory?.rating || 3,
      comment: rating.comment
    });
  };

  const handleSave = () => {
    if (!editingId) return;

    const oldRating = ratings.find(r => r.id === editingId);
    if (!oldRating) return;

    const updatedRating: KonfiRating = {
      ...oldRating,
      konfiId: formData.konfiId,
      lessonDate: formData.lessonDate,
      participation: formData.participation,
      socialBehavior: formData.socialBehavior,
      customCategory: formData.customCategoryName ? {
        name: formData.customCategoryName,
        rating: formData.customCategoryRating
      } : undefined,
      comment: formData.comment,
      updatedBy: currentUser.id,
      updatedAt: new Date().toISOString()
    };

    const updatedRatings = ratings.map(r => 
      r.id === editingId ? updatedRating : r
    );

    onRatingsChange(updatedRatings);
    
    // Audit-Log-Eintrag erstellen
    const newAuditLog: RatingAuditLog = {
      id: Date.now().toString(),
      ratingId: editingId,
      action: 'update',
      userId: currentUser.id,
      timestamp: new Date().toISOString(),
      details: `Bewertung für ${getKonfiName(formData.konfiId)} aktualisiert`,
      oldValues: oldRating,
      newValues: updatedRating
    };
    
    onAuditLogChange([...auditLog, newAuditLog]);
    
    showNotification('success', 'Bewertung erfolgreich aktualisiert');
    setEditingId(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    const ratingToDelete = ratings.find(r => r.id === id);
    if (!ratingToDelete) return;
    
    onRatingsChange(ratings.filter(r => r.id !== id));
    
    // Audit-Log-Eintrag erstellen
    const newAuditLog: RatingAuditLog = {
      id: Date.now().toString(),
      ratingId: id,
      action: 'delete',
      userId: currentUser.id,
      timestamp: new Date().toISOString(),
      details: `Bewertung für ${getKonfiName(ratingToDelete.konfiId)} gelöscht`,
      oldValues: ratingToDelete
    };
    
    onAuditLogChange([...auditLog, newAuditLog]);
    
    showNotification('success', 'Bewertung erfolgreich gelöscht');
  };

  const resetForm = () => {
    setFormData({
      konfiId: '',
      lessonDate: new Date().toISOString().split('T')[0],
      participation: 3,
      socialBehavior: 3,
      customCategoryName: '',
      customCategoryRating: 3,
      comment: ''
    });
  };

  const getKonfiName = (konfiId: string): string => {
    const user = users.find(u => u.id === konfiId);
    if (!user) return 'Unbekannt';
    
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    
    return user.username;
  };

  const getKonfiRole = (konfiId: string): string | undefined => {
    const user = users.find(u => u.id === konfiId);
    return user?.konfiRole;
  };

  const getCreatorName = (userId: string): string => {
    const user = users.find(u => u.id === userId);
    if (!user) return 'Unbekannt';
    
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    
    return user.username;
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  const handleStarClick = (field: 'participation' | 'socialBehavior' | 'customCategoryRating', value: number) => {
    setFormData({ ...formData, [field]: value });
  };

  const renderStarInput = (field: 'participation' | 'socialBehavior' | 'customCategoryRating', value: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-6 h-6 cursor-pointer ${
              star <= value ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
            }`}
            onClick={() => handleStarClick(field, star)}
          />
        ))}
      </div>
    );
  };

  // Filter und Sortierung
  const filteredRatings = ratings.filter(rating => {
    const konfi = users.find(u => u.id === rating.konfiId);
    if (!konfi) return false;
    
    const matchesSearch = 
      konfi.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      konfi.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      konfi.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rating.comment.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = filterKonfiRole === 'all' || konfi.konfiRole === filterKonfiRole;
    
    const matchesDateFrom = !filterDateFrom || rating.lessonDate >= filterDateFrom;
    const matchesDateTo = !filterDateTo || rating.lessonDate <= filterDateTo;
    
    return matchesSearch && matchesRole && matchesDateFrom && matchesDateTo;
  });
  
  const sortedRatings = [...filteredRatings].sort((a, b) => {
    let comparison = 0;
    
    switch (sortField) {
      case 'lessonDate':
        comparison = new Date(a.lessonDate).getTime() - new Date(b.lessonDate).getTime();
        break;
      case 'konfiName':
        const nameA = getKonfiName(a.konfiId).toLowerCase();
        const nameB = getKonfiName(b.konfiId).toLowerCase();
        comparison = nameA.localeCompare(nameB);
        break;
      case 'participation':
        comparison = a.participation - b.participation;
        break;
      case 'socialBehavior':
        comparison = a.socialBehavior - b.socialBehavior;
        break;
      default:
        comparison = new Date(a.lessonDate).getTime() - new Date(b.lessonDate).getTime();
    }
    
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  // Export als CSV
  const exportToCsv = () => {
    const headers = ['Datum', 'Konfirmand', 'Rolle', 'Mitarbeit', 'Sozialverhalten', 'Zusätzliche Kategorie', 'Bewertung', 'Kommentar', 'Erstellt von', 'Erstellt am'];
    
    const rows = sortedRatings.map(rating => [
      rating.lessonDate,
      getKonfiName(rating.konfiId),
      getKonfiRole(rating.konfiId) || '',
      rating.participation,
      rating.socialBehavior,
      rating.customCategory?.name || '',
      rating.customCategory?.rating || '',
      rating.comment.replace(/"/g, '""'), // Escape quotes
      getCreatorName(rating.createdBy),
      new Date(rating.createdAt).toLocaleString('de-DE')
    ]);
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `konfi-bewertungen-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Bewertungssystem</h2>
          <p className="text-gray-600 text-sm mt-1">
            Verwalten Sie Bewertungen für Mitarbeit und Sozialverhalten der Konfirmanden
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowAddForm(true)} 
            className="gap-2"
            disabled={showAddForm || editingId}
          >
            <Plus className="w-4 h-4" />
            Neue Bewertung
          </Button>
          <Button 
            onClick={exportToCsv} 
            variant="outline"
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Exportieren
          </Button>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          {notification.type === 'error' ? (
            <AlertCircle className="h-4 w-4" />
          ) : (
            <CheckCircle className="h-4 w-4" />
          )}
          <AlertDescription>{notification.message}</AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            Übersicht
          </TabsTrigger>
          <TabsTrigger value="ratings" className="gap-2">
            <Star className="w-4 h-4" />
            Bewertungen
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            Änderungsverlauf
          </TabsTrigger>
        </TabsList>

        {/* Übersicht Tab */}
        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Bewertungsstatistiken
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">Gesamtbewertungen</h3>
                      <Badge variant="outline">{ratings.length}</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Durchschnitt Mitarbeit:</span>
                        <span className="font-medium">
                          {ratings.length > 0 
                            ? (ratings.reduce((sum, r) => sum + r.participation, 0) / ratings.length).toFixed(1)
                            : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Durchschnitt Sozialverhalten:</span>
                        <span className="font-medium">
                          {ratings.length > 0 
                            ? (ratings.reduce((sum, r) => sum + r.socialBehavior, 0) / ratings.length).toFixed(1)
                            : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Letzte Bewertung:</span>
                        <span>
                          {ratings.length > 0 
                            ? new Date(Math.max(...ratings.map(r => new Date(r.createdAt).getTime()))).toLocaleDateString('de-DE')
                            : 'N/A'}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">Bewertete Konfirmanden</h3>
                      <Badge variant="outline">
                        {new Set(ratings.map(r => r.konfiId)).size}
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>KU4:</span>
                        <span>
                          {new Set(ratings
                            .filter(r => getKonfiRole(r.konfiId) === 'KU4')
                            .map(r => r.konfiId)).size}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>KUZ:</span>
                        <span>
                          {new Set(ratings
                            .filter(r => getKonfiRole(r.konfiId) === 'KUZ')
                            .map(r => r.konfiId)).size}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>KU8:</span>
                        <span>
                          {new Set(ratings
                            .filter(r => getKonfiRole(r.konfiId) === 'KU8')
                            .map(r => r.konfiId)).size}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">Benutzerdefinierte Kategorien</h3>
                      <Badge variant="outline">
                        {new Set(ratings
                          .filter(r => r.customCategory)
                          .map(r => r.customCategory?.name)).size}
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm max-h-32 overflow-y-auto">
                      {Array.from(new Set(ratings
                        .filter(r => r.customCategory)
                        .map(r => r.customCategory?.name)))
                        .map(category => (
                          <div key={category} className="flex justify-between">
                            <span>{category}</span>
                            <span>
                              {ratings.filter(r => r.customCategory?.name === category).length}x
                            </span>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Konfirmanden-Statistiken */}
              <div className="mt-6">
                <h3 className="font-semibold mb-4">Konfirmanden-Statistiken</h3>
                <div className="space-y-4">
                  {ratingStats.map(stat => {
                    const konfi = users.find(u => u.id === stat.konfiId);
                    if (!konfi) return null;
                    
                    return (
                      <Card key={stat.konfiId} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-semibold">
                                {konfi.firstName} {konfi.lastName}
                              </h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline">{konfi.konfiRole}</Badge>
                                <Badge 
                                  variant={
                                    stat.trend === 'improving' ? 'default' : 
                                    stat.trend === 'declining' ? 'destructive' : 
                                    'secondary'
                                  }
                                  className="text-xs"
                                >
                                  {stat.trend === 'improving' ? 'Verbesserung' : 
                                   stat.trend === 'declining' ? 'Verschlechterung' : 
                                   'Stabil'}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-600">
                                {stat.totalRatings} Bewertungen
                              </p>
                              <p className="text-xs text-gray-500">
                                Letzte: {new Date(stat.lastRatingDate).toLocaleDateString('de-DE')}
                              </p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                              <p className="text-sm font-medium mb-1">Mitarbeit</p>
                              <div className="flex items-center gap-2">
                                {renderStars(Math.round(stat.averageParticipation))}
                                <span className="text-sm text-gray-600">
                                  {stat.averageParticipation.toFixed(1)}
                                </span>
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium mb-1">Sozialverhalten</p>
                              <div className="flex items-center gap-2">
                                {renderStars(Math.round(stat.averageSocialBehavior))}
                                <span className="text-sm text-gray-600">
                                  {stat.averageSocialBehavior.toFixed(1)}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          {Object.keys(stat.customCategoryAverages).length > 0 && (
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-sm font-medium mb-2">Benutzerdefinierte Kategorien</p>
                              <div className="grid grid-cols-2 gap-4">
                                {Object.entries(stat.customCategoryAverages).map(([category, average]) => (
                                  <div key={category}>
                                    <p className="text-xs text-gray-600 mb-1">{category}</p>
                                    <div className="flex items-center gap-2">
                                      {renderStars(Math.round(average))}
                                      <span className="text-sm text-gray-600">
                                        {average.toFixed(1)}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bewertungen Tab */}
        <TabsContent value="ratings" className="space-y-6">
          {/* Filter und Suche */}
          <Card>
            <CardContent className="p-4">
              <div className="grid gap-4 md:grid-cols-5">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Konfirmand suchen..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={filterKonfiRole} onValueChange={setFilterKonfiRole}>
                  <SelectTrigger>
                    <SelectValue placeholder="Rolle filtern" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Rollen</SelectItem>
                    <SelectItem value="KU4">KU4</SelectItem>
                    <SelectItem value="KUZ">KUZ</SelectItem>
                    <SelectItem value="KU8">KU8</SelectItem>
                  </SelectContent>
                </Select>
                
                <div>
                  <Input
                    type="date"
                    placeholder="Von Datum"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e.target.value)}
                  />
                </div>
                
                <div>
                  <Input
                    type="date"
                    placeholder="Bis Datum"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e.target.value)}
                  />
                </div>
                
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">
                    {filteredRatings.length} von {ratings.length} Bewertungen
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Add/Edit Form */}
          {(showAddForm || editingId) && (
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle>
                  {editingId ? 'Bewertung bearbeiten' : 'Neue Bewertung hinzufügen'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="konfiId">Konfirmand *</Label>
                    <Select
                      value={formData.konfiId}
                      onValueChange={(value) => setFormData({ ...formData, konfiId: value })}
                    >
                      <SelectTrigger id="konfiId">
                        <SelectValue placeholder="Konfirmand auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {users
                          .filter(user => user.role === 'konfi')
                          .map(konfi => (
                            <SelectItem key={konfi.id} value={konfi.id}>
                              {konfi.firstName} {konfi.lastName} ({konfi.konfiRole})
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="lessonDate">Datum des Unterrichts *</Label>
                    <Input
                      id="lessonDate"
                      type="date"
                      value={formData.lessonDate}
                      onChange={(e) => setFormData({ ...formData, lessonDate: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <Label htmlFor="participation" className="mb-2 block">Mitarbeit *</Label>
                    {renderStarInput('participation', formData.participation)}
                  </div>
                  
                  <div>
                    <Label htmlFor="socialBehavior" className="mb-2 block">Sozialverhalten *</Label>
                    {renderStarInput('socialBehavior', formData.socialBehavior)}
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="customCategoryName">Benutzerdefinierte Kategorie (optional)</Label>
                    <Input
                      id="customCategoryName"
                      value={formData.customCategoryName}
                      onChange={(e) => setFormData({ ...formData, customCategoryName: e.target.value })}
                      placeholder="z.B. Bibelkenntnisse, Kreativität, Teamarbeit"
                    />
                  </div>
                  
                  {formData.customCategoryName && (
                    <div>
                      <Label htmlFor="customCategoryRating" className="mb-2 block">Bewertung für {formData.customCategoryName}</Label>
                      {renderStarInput('customCategoryRating', formData.customCategoryRating)}
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="comment">Kommentar</Label>
                  <Textarea
                    id="comment"
                    value={formData.comment}
                    onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                    placeholder="Detaillierte Anmerkungen zur Bewertung..."
                    rows={4}
                  />
                </div>

                <div className="flex gap-2 pt-4">
                  <Button onClick={editingId ? handleSave : handleAdd} className="gap-2">
                    <Save className="w-4 h-4" />
                    {editingId ? 'Speichern' : 'Hinzufügen'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingId(null);
                      resetForm();
                    }}
                    className="gap-2"
                  >
                    <X className="w-4 h-4" />
                    Abbrechen
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Sortieroptionen */}
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium">Sortieren nach:</span>
            <div className="flex gap-2">
              <Button
                variant={sortField === 'lessonDate' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setSortField('lessonDate');
                  if (sortField === 'lessonDate') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortDirection('desc');
                  }
                }}
                className="gap-1"
              >
                <Calendar className="w-3 h-3" />
                Datum
                <ArrowUpDown className="w-3 h-3" />
              </Button>
              
              <Button
                variant={sortField === 'konfiName' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setSortField('konfiName');
                  if (sortField === 'konfiName') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortDirection('asc');
                  }
                }}
                className="gap-1"
              >
                <UserIcon className="w-3 h-3" />
                Name
                <ArrowUpDown className="w-3 h-3" />
              </Button>
              
              <Button
                variant={sortField === 'participation' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setSortField('participation');
                  if (sortField === 'participation') {
                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                  } else {
                    setSortDirection('desc');
                  }
                }}
                className="gap-1"
              >
                <Star className="w-3 h-3" />
                Mitarbeit
                <ArrowUpDown className="w-3 h-3" />
              </Button>
            </div>
          </div>

          {/* Bewertungsliste */}
          <div className="space-y-4">
            {sortedRatings.map((rating) => {
              const konfi = users.find(u => u.id === rating.konfiId);
              
              return (
                <Card key={rating.id} className="transition-all hover:shadow-md">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">
                            {getKonfiName(rating.konfiId)}
                          </h3>
                          <Badge variant="outline">{konfi?.konfiRole}</Badge>
                          <Badge variant="secondary" className="text-xs">
                            {new Date(rating.lessonDate).toLocaleDateString('de-DE')}
                          </Badge>
                        </div>
                        
                        <div className="grid gap-4 md:grid-cols-2 mb-3">
                          <div>
                            <p className="text-sm font-medium mb-1">Mitarbeit</p>
                            <div className="flex items-center gap-2">
                              {renderStars(rating.participation)}
                              <span className="text-sm text-gray-600">{rating.participation}/5</span>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium mb-1">Sozialverhalten</p>
                            <div className="flex items-center gap-2">
                              {renderStars(rating.socialBehavior)}
                              <span className="text-sm text-gray-600">{rating.socialBehavior}/5</span>
                            </div>
                          </div>
                        </div>
                        
                        {rating.customCategory && (
                          <div className="mb-3">
                            <p className="text-sm font-medium mb-1">{rating.customCategory.name}</p>
                            <div className="flex items-center gap-2">
                              {renderStars(rating.customCategory.rating)}
                              <span className="text-sm text-gray-600">{rating.customCategory.rating}/5</span>
                            </div>
                          </div>
                        )}
                        
                        {rating.comment && (
                          <div className="mb-3">
                            <p className="text-sm font-medium mb-1">Kommentar</p>
                            <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                              {rating.comment}
                            </p>
                          </div>
                        )}
                        
                        <div className="text-xs text-gray-500">
                          <p>
                            Erstellt von {getCreatorName(rating.createdBy)} am {new Date(rating.createdAt).toLocaleString('de-DE')}
                          </p>
                          {rating.updatedAt && (
                            <p>
                              Aktualisiert von {getCreatorName(rating.updatedBy || '')} am {new Date(rating.updatedAt).toLocaleString('de-DE')}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleEdit(rating)}
                          disabled={editingId === rating.id || showAddForm}
                          className="gap-1"
                        >
                          <Edit className="w-3 h-3" />
                          Bearbeiten
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleDelete(rating.id)}
                          disabled={editingId === rating.id || showAddForm}
                          className="gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          Löschen
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {sortedRatings.length === 0 && (
            <Card className="p-12 text-center bg-gray-50">
              <CardContent>
                <Star className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Keine Bewertungen gefunden.</p>
                <p className="text-sm text-gray-500">
                  {ratings.length === 0 
                    ? 'Fügen Sie die erste Bewertung hinzu, um zu beginnen.' 
                    : 'Passen Sie Ihre Filterkriterien an, um Ergebnisse zu sehen.'}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Änderungsverlauf Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                Änderungsverlauf
              </CardTitle>
            </CardHeader>
            <CardContent>
              {auditLog.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <History className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Noch keine Änderungen protokolliert</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {auditLog
                    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .map((entry) => {
                      const actionColor = 
                        entry.action === 'create' ? 'text-green-600' :
                        entry.action === 'update' ? 'text-blue-600' :
                        'text-red-600';
                      
                      const actionIcon = 
                        entry.action === 'create' ? <Plus className="w-4 h-4" /> :
                        entry.action === 'update' ? <Edit className="w-4 h-4" /> :
                        <Trash2 className="w-4 h-4" />;
                      
                      return (
                        <Card key={entry.id} className="border-l-4 border-l-blue-500">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={`font-semibold ${actionColor} flex items-center gap-1`}>
                                    {actionIcon}
                                    {entry.action === 'create' ? 'Erstellt' :
                                     entry.action === 'update' ? 'Aktualisiert' :
                                     'Gelöscht'}
                                  </span>
                                  <Badge variant="outline" className="text-xs">
                                    {new Date(entry.timestamp).toLocaleString('de-DE')}
                                  </Badge>
                                </div>
                                <p className="text-sm">{entry.details}</p>
                                <p className="text-xs text-gray-600 mt-1">
                                  Durchgeführt von {getCreatorName(entry.userId)}
                                </p>
                              </div>
                              
                              {entry.action === 'update' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-xs"
                                  onClick={() => {
                                    console.log('Änderungen anzeigen:', {
                                      alt: entry.oldValues,
                                      neu: entry.newValues
                                    });
                                    // Hier könnte ein Modal mit den Änderungen angezeigt werden
                                  }}
                                >
                                  <FileText className="w-3 h-3 mr-1" />
                                  Details
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}