import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Upload, Camera, Save, X, RotateCcw, Church, 
  AlertCircle, CheckCircle, Image as ImageIcon
} from 'lucide-react';

interface ChurchLogoUploaderProps {
  currentLogo?: string;
  onSave: (logoUrl: string) => void;
  onClose: () => void;
}

export function ChurchLogoUploader({ 
  currentLogo, 
  onSave, 
  onClose 
}: ChurchLogoUploaderProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentLogo || null);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      setError('Datei ist zu groß. Maximale Größe: 5MB');
      return;
    }

    if (!['image/jpeg', 'image/png', 'image/svg+xml'].includes(file.type)) {
      setError('Ungültiger Dateityp. Nur JPG, PNG und SVG sind erlaubt.');
      return;
    }

    setError('');
    setSelectedFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!previewUrl) return;
    
    setIsProcessing(true);
    
    try {
      // In a real implementation, you would upload the file to a server
      // For this demo, we'll just use the data URL
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      onSave(previewUrl);
      setSuccess('Kirchenlogo erfolgreich gespeichert!');
      
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err) {
      setError('Fehler beim Speichern des Logos');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRemoveLogo = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Church className="w-5 h-5" />
              Kirchenlogo hochladen
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {success && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}
          
          <div className="flex flex-col items-center gap-4">
            <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-gray-200 flex items-center justify-center bg-gray-100">
              {previewUrl ? (
                <img 
                  src={previewUrl} 
                  alt="Kirchenlogo Vorschau" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <Church className="w-16 h-16 text-gray-400" />
              )}
            </div>
            
            <div className="text-center">
              <h3 className="font-medium">Kirchenlogo</h3>
              <p className="text-sm text-gray-500">
                Wird oben links in der Anwendung angezeigt
              </p>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="logo">Logo auswählen</Label>
            <div className="flex gap-2">
              <Input
                id="logo"
                type="file"
                accept="image/jpeg,image/png,image/svg+xml"
                onChange={handleFileSelect}
                className="flex-1"
                ref={fileInputRef}
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="gap-2"
              >
                <Upload className="w-4 h-4" />
                Durchsuchen
              </Button>
            </div>
            <p className="text-xs text-gray-500">
              Empfohlene Größe: 200x200 Pixel. Maximale Größe: 5MB. Erlaubte Formate: JPG, PNG, SVG
            </p>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button 
              onClick={handleSave} 
              disabled={!previewUrl || isProcessing}
              className="flex-1 gap-2"
            >
              <Save className="w-4 h-4" />
              {isProcessing ? 'Wird gespeichert...' : 'Speichern'}
            </Button>
            
            {previewUrl && (
              <Button 
                variant="outline" 
                onClick={handleRemoveLogo}
                className="gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Entfernen
              </Button>
            )}
            
            <Button variant="ghost" onClick={onClose}>
              Abbrechen
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}