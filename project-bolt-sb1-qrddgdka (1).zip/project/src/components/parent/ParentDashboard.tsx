import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { UserProfile } from '../common/UserProfile';
import { ParentRatingView } from './ParentRatingView';
import { 
  Calendar, BookOpen, BarChart3, LogOut, Users, 
  Clock, MessageSquare, User, Eye, FileText, 
  Bell, CheckCircle, AlertTriangle, Phone, Mail, Star
} from 'lucide-react';
import type { User as UserType, Question, QuizHistory, CalendarEvent, KonfiPass, KonfiContact, KonfiRating } from '@/types';

interface ParentDashboardProps {
  user: UserType;
  children: KonfiContact[];
  questions: Question[];
  history: QuizHistory[];
  events: CalendarEvent[];
  passes: KonfiPass[];
  contacts: KonfiContact[];
  users: UserType[];
  ratings: KonfiRating[];
  onEmergencyChat?: () => void;
  onLogout: () => void;
}

export function ParentDashboard({ 
  user,
  children,
  questions, 
  history, 
  events, 
  passes,
  contacts,
  users,
  ratings,
  onEmergencyChat,
  onLogout 
}: ParentDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedChild, setSelectedChild] = useState<KonfiContact | null>(
    children.length > 0 ? children[0] : null
  );
  const [showRatings, setShowRatings] = useState(false);

  // Filter events based on selected child's role
  const childEvents = events.filter(event => {
    if (!selectedChild) return false;
    if (!event.allowedRoles) return true;
    return event.allowedRoles.includes(selectedChild.konfiRole || 'KU4');
  });

  // Get upcoming events
  const upcomingEvents = childEvents
    .filter(e => new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 3);

  // Get child's pass
  const childPass = selectedChild 
    ? passes.find(p => p.konfiUsername === selectedChild.username)
    : null;

  // Get child's quiz history
  const childHistory = selectedChild
    ? history.filter(h => h.user === selectedChild.username)
    : [];

  // Get child's ratings
  const childUser = selectedChild 
    ? users.find(u => u.username === selectedChild.username)
    : null;
    
  const childRatings = childUser
    ? ratings.filter(r => r.konfiId === childUser.id)
    : [];

  // Calculate child's progress
  const calculateProgress = (childUsername: string) => {
    const childPass = passes.find(p => p.konfiUsername === childUsername);
    if (!childPass) return { attendance: 0, quizzes: 0, overall: 0 };

    const attendanceCount = childPass.signatures.length;
    const quizCount = history.filter(h => h.user === childUsername).length;
    
    // Calculate average quiz score
    const quizScores = history
      .filter(h => h.user === childUsername)
      .map(h => (h.points / h.max) * 100);
    
    const averageQuizScore = quizScores.length > 0
      ? quizScores.reduce((sum, score) => sum + score, 0) / quizScores.length
      : 0;

    // Calculate overall progress (50% attendance, 50% quiz performance)
    const attendanceProgress = Math.min((attendanceCount / 20) * 100, 100); // Assuming 20 required attendances
    const quizProgress = averageQuizScore;
    const overallProgress = (attendanceProgress * 0.5) + (quizProgress * 0.5);

    return {
      attendance: attendanceProgress,
      quizzes: quizProgress,
      overall: overallProgress
    };
  };

  // Get teachers/pastors
  const teachers = users.filter(u => u.role === 'teamer' || u.role === 'pastor');

  if (showRatings && selectedChild && childUser) {
    return (
      <ParentRatingView
        ratings={ratings}
        users={users}
        contacts={contacts}
        childId={childUser.id}
        onBack={() => setShowRatings(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Eltern-Dashboard</h1>
            <p className="text-gray-600 mt-1">
              Verfolgen Sie den Fortschritt Ihres Kindes im Konfirmationsunterricht
            </p>
          </div>
          <div className="flex items-center gap-4">
            {onEmergencyChat && (
              <Button onClick={onEmergencyChat} variant="outline" className="gap-2 border-red-300 text-red-700 hover:bg-red-50">
                <MessageSquare className="w-4 h-4" />
                Betreuer kontaktieren
              </Button>
            )}
            <UserProfile user={user} onLogout={onLogout} onEmergencyChat={onEmergencyChat} />
          </div>
        </div>

        {/* Child Selector */}
        {children.length > 0 && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-2">
                <span className="text-sm font-medium text-gray-700 mr-2 py-2">Kind auswählen:</span>
                {children.map(child => (
                  <Button
                    key={child.id}
                    variant={selectedChild?.id === child.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedChild(child)}
                    className="gap-2"
                  >
                    <User className="w-4 h-4" />
                    {child.firstName} {child.lastName}
                    <Badge variant="outline" className="ml-1 text-xs">
                      {child.konfiRole}
                    </Badge>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {children.length === 0 ? (
          <Card className="p-12 text-center bg-gray-50">
            <CardContent>
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Keine Kinder mit diesem Konto verknüpft.</p>
              <p className="text-sm text-gray-500">Bitte wenden Sie sich an einen Administrator, um Ihr Kind zu verknüpfen.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview" className="gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Übersicht
                </TabsTrigger>
                <TabsTrigger value="attendance" className="gap-2">
                  <Calendar className="w-4 h-4" />
                  Anwesenheit
                </TabsTrigger>
                <TabsTrigger value="progress" className="gap-2">
                  <BookOpen className="w-4 h-4" />
                  Lernfortschritt
                </TabsTrigger>
                <TabsTrigger value="ratings" className="gap-2">
                  <Star className="w-4 h-4" />
                  Bewertungen
                </TabsTrigger>
                <TabsTrigger value="contact" className="gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Kontakt
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6">
                {selectedChild && (
                  <>
                    <div className="grid gap-6 mb-8 md:grid-cols-3">
                      <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-blue-100">Gesamtfortschritt</p>
                              <p className="text-3xl font-bold">
                                {Math.round(calculateProgress(selectedChild.username).overall)}%
                              </p>
                            </div>
                            <BarChart3 className="w-8 h-8 text-blue-200" />
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-green-100">Anwesenheit</p>
                              <p className="text-3xl font-bold">
                                {childPass?.signatures.length || 0}
                              </p>
                            </div>
                            <Calendar className="w-8 h-8 text-green-200" />
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-purple-100">Quiz-Durchschnitt</p>
                              <p className="text-3xl font-bold">
                                {childHistory.length > 0 
                                  ? Math.round(childHistory.reduce((sum, h) => sum + (h.points / h.max * 100), 0) / childHistory.length)
                                  : 0}%
                              </p>
                            </div>
                            <BookOpen className="w-8 h-8 text-purple-200" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid gap-6 lg:grid-cols-2">
                      {/* Child Information */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <User className="w-5 h-5 text-blue-600" />
                            Informationen zu {selectedChild.firstName}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-2">
                              <p className="text-sm font-medium text-gray-500">Name</p>
                              <p>{selectedChild.firstName} {selectedChild.lastName}</p>
                            </div>
                            <div className="space-y-2">
                              <p className="text-sm font-medium text-gray-500">Geburtsdatum</p>
                              <p>{new Date(selectedChild.birthDate).toLocaleDateString('de-DE')}</p>
                            </div>
                            <div className="space-y-2">
                              <p className="text-sm font-medium text-gray-500">Konfirmanden-Gruppe</p>
                              <p>{selectedChild.konfiRole}</p>
                            </div>
                            <div className="space-y-2">
                              <p className="text-sm font-medium text-gray-500">Telefon</p>
                              <p>{selectedChild.phone}</p>
                            </div>
                          </div>
                          
                          <div className="pt-4 border-t">
                            <p className="text-sm font-medium text-gray-500 mb-2">Fortschritt zur Konfirmation</p>
                            <div className="space-y-3">
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Anwesenheit</span>
                                  <span>{Math.round(calculateProgress(selectedChild.username).attendance)}%</span>
                                </div>
                                <Progress value={calculateProgress(selectedChild.username).attendance} className="h-2" />
                              </div>
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Quiz-Leistung</span>
                                  <span>{Math.round(calculateProgress(selectedChild.username).quizzes)}%</span>
                                </div>
                                <Progress value={calculateProgress(selectedChild.username).quizzes} className="h-2" />
                              </div>
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Gesamtfortschritt</span>
                                  <span>{Math.round(calculateProgress(selectedChild.username).overall)}%</span>
                                </div>
                                <Progress value={calculateProgress(selectedChild.username).overall} className="h-2" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Bewertungen und Termine */}
                      <div className="space-y-6">
                        {/* Bewertungen Karte */}
                        <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-yellow-800">
                              <Star className="w-5 h-5" />
                              Bewertungen
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {childUser && childRatings.length > 0 ? (
                              <>
                                <div className="grid gap-4 md:grid-cols-2">
                                  <div>
                                    <p className="text-sm font-medium mb-1">Mitarbeit (Durchschnitt)</p>
                                    <div className="flex">
                                      {[1, 2, 3, 4, 5].map((star) => (
                                        <Star
                                          key={star}
                                          className={`w-4 h-4 ${
                                            star <= Math.round(childRatings.reduce((sum, r) => sum + r.participation, 0) / childRatings.length) 
                                              ? 'text-yellow-500 fill-yellow-500' 
                                              : 'text-gray-300'
                                          }`}
                                        />
                                      ))}
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <p className="text-sm font-medium mb-1">Sozialverhalten (Durchschnitt)</p>
                                    <div className="flex">
                                      {[1, 2, 3, 4, 5].map((star) => (
                                        <Star
                                          key={star}
                                          className={`w-4 h-4 ${
                                            star <= Math.round(childRatings.reduce((sum, r) => sum + r.socialBehavior, 0) / childRatings.length) 
                                              ? 'text-yellow-500 fill-yellow-500' 
                                              : 'text-gray-300'
                                          }`}
                                        />
                                      ))}
                                    </div>
                                  </div>
                                </div>
                                
                                <p className="text-sm text-gray-600">
                                  {childRatings.length} Bewertungen insgesamt, letzte vom {new Date(Math.max(...childRatings.map(r => new Date(r.lessonDate).getTime()))).toLocaleDateString('de-DE')}
                                </p>
                                
                                <Button 
                                  onClick={() => setShowRatings(true)} 
                                  className="w-full"
                                >
                                  <Eye className="w-4 h-4 mr-2" />
                                  Alle Bewertungen anzeigen
                                </Button>
                              </>
                            ) : (
                              <div className="text-center py-4">
                                <Star className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                                <p className="text-sm text-gray-500">
                                  Noch keine Bewertungen für {selectedChild.firstName} vorhanden
                                </p>
                              </div>
                            )}
                          </CardContent>
                        </Card>

                        {/* Upcoming Events */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <Calendar className="w-5 h-5 text-green-600" />
                              Anstehende Termine
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            {upcomingEvents.length === 0 ? (
                              <p className="text-gray-500">Keine anstehenden Termine für {selectedChild.firstName}</p>
                            ) : (
                              <div className="space-y-3">
                                {upcomingEvents.map((event) => (
                                  <div key={event.id} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                                    <Calendar className="w-4 h-4 text-green-600 mt-1" />
                                    <div className="flex-1">
                                      <p className="font-semibold text-sm">{event.title}</p>
                                      <p className="text-xs text-gray-600">
                                        {new Date(event.date).toLocaleDateString('de-DE', {
                                          weekday: 'long',
                                          year: 'numeric',
                                          month: 'long',
                                          day: 'numeric'
                                        })}
                                      </p>
                                      {event.description && (
                                        <p className="text-xs text-gray-500 mt-1">{event.description}</p>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      </div>

                      {/* Recent Activity */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Clock className="w-5 h-5 text-orange-600" />
                            Letzte Aktivitäten
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {childPass && childPass.signatures.length > 0 ? (
                            <div className="space-y-3">
                              {childPass.signatures
                                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                                .slice(0, 3)
                                .map((signature) => (
                                  <div key={signature.id} className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                                    <CheckCircle className="w-4 h-4 text-orange-600 mt-1" />
                                    <div className="flex-1">
                                      <p className="font-semibold text-sm">{signature.activityTitle}</p>
                                      <p className="text-xs text-gray-600">
                                        {new Date(signature.date).toLocaleDateString('de-DE')}
                                      </p>
                                      {signature.location && (
                                        <p className="text-xs text-gray-500 mt-1">Ort: {signature.location}</p>
                                      )}
                                    </div>
                                  </div>
                                ))}
                            </div>
                          ) : (
                            <p className="text-gray-500">Keine Aktivitäten für {selectedChild.firstName} erfasst</p>
                          )}
                        </CardContent>
                      </Card>

                      {/* Notifications */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Bell className="w-5 h-5 text-red-600" />
                            Benachrichtigungen
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {/* Example notifications */}
                          <div className="space-y-3">
                            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                              <AlertTriangle className="w-4 h-4 text-yellow-600 mt-1" />
                              <div className="flex-1">
                                <p className="font-semibold text-sm">Anstehender Termin</p>
                                <p className="text-xs text-gray-600">
                                  Konfirmationsunterricht am {new Date().toLocaleDateString('de-DE', {
                                    weekday: 'long',
                                    day: 'numeric',
                                    month: 'long'
                                  })}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                              <FileText className="w-4 h-4 text-blue-600 mt-1" />
                              <div className="flex-1">
                                <p className="font-semibold text-sm">Neue Lernmaterialien</p>
                                <p className="text-xs text-gray-600">
                                  Neue Materialien zum Thema "Glaubensbekenntnis" verfügbar
                                </p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </>
                )}
              </TabsContent>

              <TabsContent value="attendance" className="mt-6">
                {selectedChild && childPass && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Calendar className="w-5 h-5" />
                          Anwesenheitsübersicht für {selectedChild.firstName}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <h3 className="font-semibold mb-1">Konfirmationsunterricht</h3>
                            <p className="text-2xl font-bold text-blue-600">
                              {childPass.signatures.filter(s => s.activityType === 'konfirmationsunterricht').length}
                            </p>
                            <p className="text-xs text-gray-600">von 20 erforderlichen Einheiten</p>
                            <Progress 
                              value={Math.min((childPass.signatures.filter(s => s.activityType === 'konfirmationsunterricht').length / 20) * 100, 100)} 
                              className="h-2 mt-2" 
                            />
                          </div>
                          
                          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                            <h3 className="font-semibold mb-1">Gottesdienstbesuche</h3>
                            <p className="text-2xl font-bold text-green-600">
                              {childPass.signatures.filter(s => s.activityType === 'gottesdienst').length}
                            </p>
                            <p className="text-xs text-gray-600">von 15 erforderlichen Besuchen</p>
                            <Progress 
                              value={Math.min((childPass.signatures.filter(s => s.activityType === 'gottesdienst').length / 15) * 100, 100)} 
                              className="h-2 mt-2" 
                            />
                          </div>
                          
                          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                            <h3 className="font-semibold mb-1">Kirchliche Aktivitäten</h3>
                            <p className="text-2xl font-bold text-purple-600">
                              {childPass.signatures.filter(s => s.activityType === 'kirchliche_aktivitaet').length}
                            </p>
                            <p className="text-xs text-gray-600">von 5 erforderlichen Aktivitäten</p>
                            <Progress 
                              value={Math.min((childPass.signatures.filter(s => s.activityType === 'kirchliche_aktivitaet').length / 5) * 100, 100)} 
                              className="h-2 mt-2" 
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Anwesenheitsverlauf</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {childPass.signatures.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                            <p>Noch keine Anwesenheiten erfasst</p>
                          </div>
                        ) : (
                          <div className="space-y-3 max-h-96 overflow-y-auto">
                            {childPass.signatures
                              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                              .map((signature) => (
                                <Card key={signature.id} className="border-l-4 border-l-blue-500">
                                  <CardContent className="p-4">
                                    <div className="flex justify-between items-start mb-2">
                                      <div>
                                        <Badge 
                                          variant="secondary" 
                                          className={`
                                            ${signature.activityType === 'konfirmationsunterricht' ? 'bg-blue-500' : 
                                              signature.activityType === 'gottesdienst' ? 'bg-green-500' : 
                                              'bg-purple-500'} text-white
                                          `}
                                        >
                                          {signature.activityType === 'konfirmationsunterricht' ? 'Konfirmationsunterricht' : 
                                           signature.activityType === 'gottesdienst' ? 'Gottesdienst' : 
                                           'Kirchliche Aktivität'}
                                        </Badge>
                                        <h4 className="font-semibold mt-1">{signature.activityTitle}</h4>
                                      </div>
                                      <div className="text-right text-sm text-gray-600">
                                        <div className="flex items-center gap-1">
                                          <Calendar className="w-3 h-3" />
                                          {new Date(signature.date).toLocaleDateString('de-DE')}
                                        </div>
                                        <div className="flex items-center gap-1 mt-1">
                                          <Clock className="w-3 h-3" />
                                          {signature.time}
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div className="text-sm text-gray-600">
                                      {signature.location && (
                                        <p className="text-xs">Ort: {signature.location}</p>
                                      )}
                                      {signature.comments && (
                                        <p className="mt-2 p-2 bg-gray-50 rounded text-xs">
                                          {signature.comments}
                                        </p>
                                      )}
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="progress" className="mt-6">
                {selectedChild && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <BookOpen className="w-5 h-5" />
                          Lernfortschritt für {selectedChild.firstName}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <h3 className="font-semibold mb-1">Quiz-Leistung</h3>
                            <p className="text-2xl font-bold text-blue-600">
                              {childHistory.length > 0 
                                ? Math.round(childHistory.reduce((sum, h) => sum + (h.points / h.max * 100), 0) / childHistory.length)
                                : 0}%
                            </p>
                            <p className="text-xs text-gray-600">Durchschnittliche Punktzahl</p>
                            <div className="mt-2 text-sm">
                              <div className="flex justify-between">
                                <span>Absolvierte Quizze:</span>
                                <span>{childHistory.length}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                            <h3 className="font-semibold mb-1">Lernmaterialien</h3>
                            <p className="text-2xl font-bold text-green-600">
                              {/* Placeholder - would be actual data in a real app */}
                              8
                            </p>
                            <p className="text-xs text-gray-600">Bearbeitete Materialien</p>
                            <div className="mt-2 text-sm">
                              <div className="flex justify-between">
                                <span>Karteikarten:</span>
                                <span>24 von 40</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {childHistory.length > 0 && (
                          <div>
                            <h3 className="font-semibold mb-3">Letzte Quiz-Ergebnisse</h3>
                            <div className="space-y-3">
                              {childHistory
                                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                                .slice(0, 5)
                                .map((result) => {
                                  const percentage = Math.round((result.points / result.max) * 100);
                                  
                                  return (
                                    <div key={result.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                      <div>
                                        <Badge variant={
                                          percentage >= 80 ? "default" : 
                                          percentage >= 60 ? "secondary" : 
                                          "destructive"
                                        } className="mb-1">
                                          {percentage >= 80 ? "Ausgezeichnet" : 
                                           percentage >= 60 ? "Gut" : 
                                           "Übung nötig"}
                                        </Badge>
                                        <p className="text-sm text-gray-600">{result.date}</p>
                                        <p className="text-xs text-gray-500">{result.category}</p>
                                      </div>
                                      <div className="text-right">
                                        <div className="text-xl font-bold">{result.points}/{result.max}</div>
                                        <div className="text-sm text-gray-600">{percentage}%</div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Eye className="w-5 h-5" />
                          Empfehlungen für Eltern
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <h3 className="font-semibold mb-2">Wie Sie Ihr Kind unterstützen können</h3>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 shrink-0" />
                                <span>Sprechen Sie regelmäßig mit Ihrem Kind über die Inhalte des Konfirmationsunterrichts</span>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 shrink-0" />
                                <span>Unterstützen Sie Ihr Kind beim regelmäßigen Besuch des Unterrichts und der Gottesdienste</span>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 shrink-0" />
                                <span>Helfen Sie bei der Vorbereitung auf Quizze und Tests</span>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 shrink-0" />
                                <span>Nehmen Sie an Elternabenden und Informationsveranstaltungen teil</span>
                              </li>
                            </ul>
                          </div>
                          
                          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                            <h3 className="font-semibold mb-2">Anstehende Elterntermine</h3>
                            <div className="space-y-2">
                              <div className="flex items-start gap-2">
                                <Calendar className="w-4 h-4 text-yellow-600 mt-1 shrink-0" />
                                <div>
                                  <p className="text-sm font-medium">Elternabend zur Konfirmation</p>
                                  <p className="text-xs text-gray-600">15. März 2025, 19:00 Uhr</p>
                                </div>
                              </div>
                              <div className="flex items-start gap-2">
                                <Calendar className="w-4 h-4 text-yellow-600 mt-1 shrink-0" />
                                <div>
                                  <p className="text-sm font-medium">Informationsveranstaltung Konfirmationsfeier</p>
                                  <p className="text-xs text-gray-600">10. April 2025, 18:30 Uhr</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="ratings" className="mt-6">
                {selectedChild && childUser && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Star className="w-5 h-5 text-yellow-600" />
                          Bewertungen für {selectedChild.firstName}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {childRatings.length > 0 ? (
                          <>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div>
                                <p className="text-sm font-medium mb-1">Mitarbeit (Durchschnitt)</p>
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`w-5 h-5 ${
                                        star <= Math.round(childRatings.reduce((sum, r) => sum + r.participation, 0) / childRatings.length) 
                                          ? 'text-yellow-500 fill-yellow-500' 
                                          : 'text-gray-300'
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                              
                              <div>
                                <p className="text-sm font-medium mb-1">Sozialverhalten (Durchschnitt)</p>
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`w-5 h-5 ${
                                        star <= Math.round(childRatings.reduce((sum, r) => sum + r.socialBehavior, 0) / childRatings.length) 
                                          ? 'text-yellow-500 fill-yellow-500' 
                                          : 'text-gray-300'
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <p className="text-sm font-medium">Letzte Bewertung</p>
                              <Card className="bg-gray-50">
                                <CardContent className="p-4">
                                  {(() => {
                                    const latestRating = [...childRatings].sort((a, b) => 
                                      new Date(b.lessonDate).getTime() - new Date(a.lessonDate).getTime()
                                    )[0];
                                    
                                    return (
                                      <div className="space-y-3">
                                        <p className="text-sm font-medium">
                                          Unterricht vom {new Date(latestRating.lessonDate).toLocaleDateString('de-DE')}
                                        </p>
                                        
                                        <div className="grid gap-3 md:grid-cols-2">
                                          <div>
                                            <p className="text-xs text-gray-600">Mitarbeit</p>
                                            <div className="flex">
                                              {[1, 2, 3, 4, 5].map((star) => (
                                                <Star
                                                  key={star}
                                                  className={`w-4 h-4 ${
                                                    star <= latestRating.participation 
                                                      ? 'text-yellow-500 fill-yellow-500' 
                                                      : 'text-gray-300'
                                                  }`}
                                                />
                                              ))}
                                            </div>
                                          </div>
                                          
                                          <div>
                                            <p className="text-xs text-gray-600">Sozialverhalten</p>
                                            <div className="flex">
                                              {[1, 2, 3, 4, 5].map((star) => (
                                                <Star
                                                  key={star}
                                                  className={`w-4 h-4 ${
                                                    star <= latestRating.socialBehavior 
                                                      ? 'text-yellow-500 fill-yellow-500' 
                                                      : 'text-gray-300'
                                                  }`}
                                                />
                                              ))}
                                            </div>
                                          </div>
                                        </div>
                                        
                                        {latestRating.comment && (
                                          <div>
                                            <p className="text-xs text-gray-600">Kommentar</p>
                                            <p className="text-sm mt-1">{latestRating.comment}</p>
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })()}
                                </CardContent>
                              </Card>
                            </div>
                            
                            <Button 
                              onClick={() => setShowRatings(true)} 
                              className="w-full"
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Alle Bewertungen anzeigen
                            </Button>
                          </>
                        ) : (
                          <div className="text-center py-8 text-gray-500">
                            <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                            <p>Noch keine Bewertungen für {selectedChild.firstName} vorhanden</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="contact" className="mt-6">
                <div className="grid gap-6 lg:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5" />
                        Kontakt zu Betreuern
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-600">
                        Hier finden Sie die Kontaktdaten der Betreuer und Pastoren, die für den Konfirmationsunterricht verantwortlich sind.
                      </p>
                      
                      <div className="space-y-3">
                        {teachers.map((teacher) => (
                          <Card key={teacher.id} className="border-l-4 border-l-blue-500">
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <div className="w-10 h-10 rounded-full bg-gray-400 flex items-center justify-center text-white font-semibold">
                                  {teacher.firstName?.[0]}{teacher.lastName?.[0]}
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-semibold">{teacher.firstName} {teacher.lastName}</h4>
                                  <p className="text-sm text-gray-600">{teacher.role === 'pastor' ? 'Pastor' : 'Teamer'}</p>
                                  
                                  <div className="mt-2 space-y-1 text-sm">
                                    {teacher.emergencyContactInfo?.email && (
                                      <div className="flex items-center gap-2">
                                        <Mail className="w-3 h-3 text-gray-500" />
                                        <a href={`mailto:${teacher.emergencyContactInfo.email}`} className="text-blue-600 hover:underline">
                                          {teacher.emergencyContactInfo.email}
                                        </a>
                                      </div>
                                    )}
                                    {teacher.emergencyContactInfo?.phone && (
                                      <div className="flex items-center gap-2">
                                        <Phone className="w-3 h-3 text-gray-500" />
                                        <a href={`tel:${teacher.emergencyContactInfo.phone}`} className="text-blue-600 hover:underline">
                                          {teacher.emergencyContactInfo.phone}
                                        </a>
                                      </div>
                                    )}
                                    {teacher.emergencyContactInfo?.availableHours && (
                                      <div className="flex items-center gap-2">
                                        <Clock className="w-3 h-3 text-gray-500" />
                                        <span>{teacher.emergencyContactInfo.availableHours}</span>
                                      </div>
                                    )}
                                  </div>
                                  
                                  {teacher.specializations && teacher.specializations.length > 0 && (
                                    <div className="mt-2 flex flex-wrap gap-1">
                                      {teacher.specializations.map((spec, index) => (
                                        <Badge key={index} variant="outline" className="text-xs">
                                          {spec}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Bell className="w-5 h-5" />
                          Wichtige Mitteilungen
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                            <div className="flex items-start gap-2">
                              <AlertTriangle className="w-4 h-4 text-yellow-600 mt-1 shrink-0" />
                              <div>
                                <h4 className="font-semibold text-sm">Konfirmationstermin festgelegt</h4>
                                <p className="text-xs text-gray-600 mt-1">
                                  Die Konfirmation findet am 25. Mai 2025 um 10:00 Uhr in der Hauptkirche statt.
                                </p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <div className="flex items-start gap-2">
                              <Bell className="w-4 h-4 text-blue-600 mt-1 shrink-0" />
                              <div>
                                <h4 className="font-semibold text-sm">Elternabend zur Konfirmation</h4>
                                <p className="text-xs text-gray-600 mt-1">
                                  Am 15. März 2025 findet ein Elternabend zur Besprechung der Konfirmationsfeier statt.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="w-5 h-5" />
                          Dokumente & Formulare
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="p-3 bg-gray-50 rounded-lg border flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-blue-600" />
                              <span className="text-sm">Anmeldeformular Konfirmationsfeier</span>
                            </div>
                            <Button size="sm" variant="outline" className="h-8">
                              Herunterladen
                            </Button>
                          </div>
                          
                          <div className="p-3 bg-gray-50 rounded-lg border flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-blue-600" />
                              <span className="text-sm">Informationen zur Konfirmation</span>
                            </div>
                            <Button size="sm" variant="outline" className="h-8">
                              Herunterladen
                            </Button>
                          </div>
                          
                          <div className="p-3 bg-gray-50 rounded-lg border flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-blue-600" />
                              <span className="text-sm">Checkliste für Eltern</span>
                            </div>
                            <Button size="sm" variant="outline" className="h-8">
                              Herunterladen
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}