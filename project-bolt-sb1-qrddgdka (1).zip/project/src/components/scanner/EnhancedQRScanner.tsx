import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  Camera, X, Scan, AlertCircle, CheckCircle, RefreshCw, 
  Smartphone, Flashlight, FlashlightOff, Focus, Zap, 
  RotateCcw, CameraOff, Loader2
} from 'lucide-react';
import QrScanner from 'qr-scanner';

interface EnhancedQRScannerProps {
  onScanComplete: (result: string) => void;
  onCancel: () => void;
  settings: {
    enableBeep: boolean;
    enableVibration: boolean;
    enableFlashlight: boolean;
    scanContinuously: boolean;
    preferredCamera: 'environment' | 'user';
    scanTimeout: number;
  };
}

export function EnhancedQRScanner({ 
  onScanComplete, 
  onCancel,
  settings
}: EnhancedQRScannerProps) {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [error, setError] = useState<string>('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [availableCameras, setAvailableCameras] = useState<QrScanner.Camera[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerRef = useRef<QrScanner | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const scanTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Detect mobile device
  useEffect(() => {
    const checkMobile = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      const mobileKeywords = ['mobile', 'android', 'iphone', 'ipad', 'tablet'];
      return mobileKeywords.some(keyword => userAgent.includes(keyword)) || 
             window.innerWidth <= 768 ||
             'ontouchstart' in window;
    };
    
    setIsMobile(checkMobile());
  }, []);

  // Initialize scanner
  useEffect(() => {
    if (!videoRef.current) return;
    
    const initializeScanner = async () => {
      try {
        setError('');
        setIsLoading(true);
        
        // Check if camera is available
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('Kamera wird von diesem Browser nicht unterstützt');
        }
        
        // Get available cameras
        const cameras = await QrScanner.listCameras();
        setAvailableCameras(cameras);
        
        // Select preferred camera
        let preferredCameraId = null;
        if (cameras.length > 0) {
          const preferredCameras = cameras.filter(
            camera => camera.label.toLowerCase().includes(
              settings.preferredCamera === 'environment' ? 'back' : 'front'
            )
          );
          
          preferredCameraId = preferredCameras.length > 0 
            ? preferredCameras[0].id 
            : cameras[0].id;
            
          setSelectedCamera(preferredCameraId);
        }
        
        // Create scanner instance
        const qrScanner = new QrScanner(
          videoRef.current,
          result => {
            if (settings.scanContinuously) {
              onScanComplete(result.data);
            } else {
              stopScanning();
              onScanComplete(result.data);
            }
          },
          {
            preferredCamera: preferredCameraId || settings.preferredCamera,
            highlightScanRegion: true,
            highlightCodeOutline: true,
            returnDetailedScanResult: true,
          }
        );
        
        scannerRef.current = qrScanner;
        
        // Start scanner
        await qrScanner.start();
        setHasPermission(true);
        setIsScanning(true);
        setIsLoading(false);
        
        // Start scan timeout
        if (settings.scanTimeout > 0) {
          startScanTimeout();
        }
      } catch (err) {
        console.error('Scanner initialization error:', err);
        handleScannerError(err);
        setIsLoading(false);
      }
    };
    
    initializeScanner();
    
    // Cleanup
    return () => {
      stopScanning();
    };
  }, []);
  
  const startScanTimeout = () => {
    // Clear any existing timeout
    if (scanTimeoutRef.current) {
      clearTimeout(scanTimeoutRef.current);
      clearInterval(timeoutRef.current!);
      setScanProgress(0);
    }
    
    // Set progress update interval
    const totalTime = settings.scanTimeout * 1000;
    const interval = 100; // Update every 100ms
    const steps = totalTime / interval;
    let currentStep = 0;
    
    timeoutRef.current = setInterval(() => {
      currentStep++;
      setScanProgress((currentStep / steps) * 100);
      
      if (currentStep >= steps) {
        clearInterval(timeoutRef.current!);
      }
    }, interval);
    
    // Set timeout to stop scanning
    scanTimeoutRef.current = setTimeout(() => {
      if (isScanning) {
        stopScanning();
        setError('Zeitüberschreitung beim Scannen. Bitte versuchen Sie es erneut.');
      }
    }, totalTime);
  };
  
  const stopScanning = () => {
    if (scannerRef.current) {
      scannerRef.current.stop();
      setIsScanning(false);
    }
    
    if (timeoutRef.current) {
      clearInterval(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    if (scanTimeoutRef.current) {
      clearTimeout(scanTimeoutRef.current);
      scanTimeoutRef.current = null;
    }
    
    // Turn off flashlight if it's on
    if (flashlightOn) {
      toggleFlashlight();
    }
  };
  
  const handleScannerError = (err: any) => {
    if (err instanceof Error) {
      if (err.name === 'NotAllowedError') {
        setError('Kamera-Zugriff wurde verweigert. Bitte erlauben Sie den Kamera-Zugriff in den Browser-Einstellungen.');
      } else if (err.name === 'NotFoundError') {
        setError('Keine Kamera gefunden. Bitte verwenden Sie ein Gerät mit Kamera oder geben Sie den Code manuell ein.');
      } else if (err.name === 'NotSupportedError') {
        setError('Kamera wird von diesem Browser nicht unterstützt. Versuchen Sie es mit Chrome, Safari oder Firefox.');
      } else if (err.name === 'OverconstrainedError') {
        setError('Kamera-Einstellungen nicht unterstützt. Versuchen Sie es mit der anderen Kamera.');
      } else {
        setError(`Fehler beim Starten der Kamera: ${err.message}`);
      }
    } else {
      setError('Unbekannter Fehler beim Starten der Kamera.');
    }
    setHasPermission(false);
  };
  
  const toggleFlashlight = async () => {
    if (!scannerRef.current) return;
    
    try {
      await scannerRef.current.toggleFlashlight();
      setFlashlightOn(!flashlightOn);
    } catch (err) {
      console.error('Flashlight control error:', err);
      setError('Taschenlampe konnte nicht gesteuert werden. Möglicherweise wird sie von Ihrem Gerät nicht unterstützt.');
    }
  };
  
  const switchCamera = async () => {
    if (!scannerRef.current) return;
    
    try {
      stopScanning();
      
      // Get next camera
      if (availableCameras.length > 1) {
        const currentIndex = availableCameras.findIndex(camera => camera.id === selectedCamera);
        const nextIndex = (currentIndex + 1) % availableCameras.length;
        const nextCamera = availableCameras[nextIndex];
        
        setSelectedCamera(nextCamera.id);
        
        // Restart scanner with new camera
        await scannerRef.current.setCamera(nextCamera.id);
        scannerRef.current.start();
        setIsScanning(true);
        
        // Restart timeout
        if (settings.scanTimeout > 0) {
          startScanTimeout();
        }
      }
    } catch (err) {
      console.error('Camera switch error:', err);
      setError('Fehler beim Wechseln der Kamera.');
    }
  };
  
  const handleRetry = () => {
    setError('');
    setHasPermission(null);
    setScanProgress(0);
    
    if (scannerRef.current) {
      scannerRef.current.start();
      setIsScanning(true);
      
      if (settings.scanTimeout > 0) {
        startScanTimeout();
      }
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Camera className="w-5 h-5" />
            QR-Code Scanner
            {isMobile && <Smartphone className="w-4 h-4 text-blue-500" />}
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              stopScanning();
              onCancel();
            }}
            className="h-8 w-8 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex justify-between items-center">
              <span className="text-sm">{error}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRetry}
                className="ml-2"
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                Erneut versuchen
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-8">
            <Loader2 className="w-12 h-12 mx-auto mb-4 text-blue-500 animate-spin" />
            <p className="text-gray-600">Kamera wird initialisiert...</p>
            <p className="text-sm text-gray-500 mt-2">
              Bitte erlauben Sie den Kamera-Zugriff, wenn Sie dazu aufgefordert werden
            </p>
          </div>
        )}

        {/* Camera View */}
        <div className="relative bg-black rounded-lg overflow-hidden">
          <video
            ref={videoRef}
            className="w-full h-64 object-cover"
            playsInline
            muted
          />
          
          {/* Scanner Overlay */}
          {isScanning && hasPermission && !isLoading && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-48 h-48 border-2 border-blue-500 rounded-lg relative">
                <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-blue-500 rounded-tl"></div>
                <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-blue-500 rounded-tr"></div>
                <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-blue-500 rounded-bl"></div>
                <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-blue-500 rounded-br"></div>
                
                {/* Scan animation */}
                <div className="absolute top-0 left-0 w-full h-1 bg-blue-500 opacity-70 animate-[scanline_2s_ease-in-out_infinite]"></div>
              </div>
            </div>
          )}
          
          {/* Camera controls */}
          {hasPermission && !isLoading && (
            <div className="absolute bottom-2 right-2 flex gap-2">
              {settings.enableFlashlight && (
                <Button
                  size="sm"
                  variant={flashlightOn ? "default" : "secondary"}
                  onClick={toggleFlashlight}
                  className="h-8 w-8 p-0 bg-black/50 hover:bg-black/70 border-white/20"
                >
                  {flashlightOn ? (
                    <FlashlightOff className="w-4 h-4 text-white" />
                  ) : (
                    <Flashlight className="w-4 h-4 text-white" />
                  )}
                </Button>
              )}
              
              {availableCameras.length > 1 && (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={switchCamera}
                  className="h-8 w-8 p-0 bg-black/50 hover:bg-black/70 border-white/20"
                >
                  <RotateCcw className="w-4 h-4 text-white" />
                </Button>
              )}
            </div>
          )}
          
          {/* No permission or error state */}
          {!hasPermission && !isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80">
              <div className="text-center text-white p-4">
                <CameraOff className="w-12 h-12 mx-auto mb-2 text-red-500" />
                <p className="font-medium">Kein Kamera-Zugriff</p>
                <p className="text-sm text-gray-300 mt-1">
                  Bitte erlauben Sie den Zugriff auf Ihre Kamera
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* Scan timeout progress */}
        {settings.scanTimeout > 0 && isScanning && (
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-gray-500">
              <span>Scan-Timeout</span>
              <span>{Math.round((settings.scanTimeout * (100 - scanProgress)) / 100)}s</span>
            </div>
            <Progress value={scanProgress} className="h-1" />
          </div>
        )}

        {/* Instructions */}
        <div className="text-center text-sm text-gray-600">
          <p>Halten Sie die Kamera über einen QR-Code, um ihn zu scannen</p>
          {error && (
            <p className="text-red-500 mt-1">
              Falls die Kamera nicht funktioniert, können Sie den Code auch manuell eingeben
            </p>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            onClick={() => {
              stopScanning();
              onCancel();
            }}
            className="flex-1"
          >
            Abbrechen
          </Button>
          
          {(error || !hasPermission) && !isLoading && (
            <Button
              onClick={() => {
                stopScanning();
                onCancel();
              }}
              className="flex-1 gap-2"
            >
              <Keyboard className="w-4 h-4" />
              Manuell eingeben
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}