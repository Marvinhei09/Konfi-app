import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, Tablet, Monitor, Wifi, WifiOff, 
  Compass, Cpu, Battery, BatteryCharging, 
  Thermometer, Gauge, Vibrate, Camera
} from 'lucide-react';

interface DeviceInfoProps {
  className?: string;
}

export function DeviceInfo({ className }: DeviceInfoProps) {
  const [deviceInfo, setDeviceInfo] = useState({
    type: 'unknown',
    orientation: 'unknown',
    online: navigator.onLine,
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    pixelRatio: window.devicePixelRatio,
    touchPoints: navigator.maxTouchPoints,
    memory: (navigator as any).deviceMemory,
    hasCamera: false,
    hasBattery: false,
    batteryLevel: null as number | null,
    batteryCharging: false,
    hasVibration: 'vibrate' in navigator,
    hasOrientation: 'DeviceOrientationEvent' in window,
    hasGeolocation: 'geolocation' in navigator,
  });

  useEffect(() => {
    // Detect device type
    const width = window.innerWidth;
    let deviceType = 'unknown';
    
    if (width < 768) {
      deviceType = 'mobile';
    } else if (width < 1024) {
      deviceType = 'tablet';
    } else {
      deviceType = 'desktop';
    }
    
    // Detect orientation
    const orientation = width > window.innerHeight ? 'landscape' : 'portrait';
    
    // Check for camera
    const hasCamera = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    
    // Update device info
    setDeviceInfo(prev => ({
      ...prev,
      type: deviceType,
      orientation,
      hasCamera
    }));
    
    // Check for battery
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setDeviceInfo(prev => ({
          ...prev,
          hasBattery: true,
          batteryLevel: battery.level * 100,
          batteryCharging: battery.charging
        }));
        
        // Battery status change listeners
        battery.addEventListener('levelchange', () => {
          setDeviceInfo(prev => ({
            ...prev,
            batteryLevel: battery.level * 100
          }));
        });
        
        battery.addEventListener('chargingchange', () => {
          setDeviceInfo(prev => ({
            ...prev,
            batteryCharging: battery.charging
          }));
        });
      });
    }
    
    // Online status listener
    const handleOnlineStatusChange = () => {
      setDeviceInfo(prev => ({
        ...prev,
        online: navigator.onLine
      }));
    };
    
    window.addEventListener('online', handleOnlineStatusChange);
    window.addEventListener('offline', handleOnlineStatusChange);
    
    // Orientation change listener
    const handleOrientationChange = () => {
      const newOrientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
      setDeviceInfo(prev => ({
        ...prev,
        orientation: newOrientation
      }));
    };
    
    window.addEventListener('resize', handleOrientationChange);
    
    return () => {
      window.removeEventListener('online', handleOnlineStatusChange);
      window.removeEventListener('offline', handleOnlineStatusChange);
      window.removeEventListener('resize', handleOrientationChange);
    };
  }, []);

  const getDeviceIcon = () => {
    switch (deviceInfo.type) {
      case 'mobile': return <Smartphone className="w-5 h-5" />;
      case 'tablet': return <Tablet className="w-5 h-5" />;
      case 'desktop': return <Monitor className="w-5 h-5" />;
      default: return <Cpu className="w-5 h-5" />;
    }
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getDeviceIcon()}
          Geräte-Informationen
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2">
            {getDeviceIcon()}
            <span className="text-sm font-medium">
              {deviceInfo.type.charAt(0).toUpperCase() + deviceInfo.type.slice(1)}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            {deviceInfo.online ? (
              <Wifi className="w-4 h-4 text-green-500" />
            ) : (
              <WifiOff className="w-4 h-4 text-red-500" />
            )}
            <span className="text-sm font-medium">
              {deviceInfo.online ? 'Online' : 'Offline'}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4" />
            <span className="text-sm font-medium">
              {deviceInfo.orientation.charAt(0).toUpperCase() + deviceInfo.orientation.slice(1)}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4" />
            <span className="text-sm font-medium">
              Kamera: {deviceInfo.hasCamera ? 'Verfügbar' : 'Nicht verfügbar'}
            </span>
          </div>
          
          {deviceInfo.hasBattery && deviceInfo.batteryLevel !== null && (
            <div className="flex items-center gap-2">
              {deviceInfo.batteryCharging ? (
                <BatteryCharging className="w-4 h-4 text-green-500" />
              ) : (
                <Battery className="w-4 h-4" />
              )}
              <span className="text-sm font-medium">
                Akku: {Math.round(deviceInfo.batteryLevel)}%
              </span>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <Vibrate className="w-4 h-4" />
            <span className="text-sm font-medium">
              Vibration: {deviceInfo.hasVibration ? 'Ja' : 'Nein'}
            </span>
          </div>
        </div>
        
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Bildschirm</h4>
          <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
            <div>Auflösung: {deviceInfo.screenWidth}x{deviceInfo.screenHeight}</div>
            <div>Pixel Ratio: {deviceInfo.pixelRatio}</div>
            <div>Touchpoints: {deviceInfo.touchPoints}</div>
            {deviceInfo.memory && <div>Gerätespeicher: {deviceInfo.memory}GB</div>}
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1">
          <Badge variant="outline" className="text-xs">
            {deviceInfo.platform}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {deviceInfo.language}
          </Badge>
          {deviceInfo.hasGeolocation && (
            <Badge variant="outline" className="text-xs">
              GPS
            </Badge>
          )}
          {deviceInfo.hasOrientation && (
            <Badge variant="outline" className="text-xs">
              Gyroscope
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}