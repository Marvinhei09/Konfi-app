import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { QrCode, Camera, Copy, CheckCircle, ExternalLink } from 'lucide-react';
import { useState } from 'react';

interface ScanResultProps {
  result: string | null;
  onScanAgain: () => void;
  onHome: () => void;
}

export function ScanResult({ result, onScanAgain, onHome }: ScanResultProps) {
  const [copied, setCopied] = useState(false);

  if (!result) {
    return (
      <Card className="max-w-md mx-auto">
        <CardContent className="p-6 text-center">
          <p className="text-gray-600">Kein Scan-Ergebnis verfügbar</p>
          <Button onClick={onHome} className="mt-4">
            Zurück zur Startseite
          </Button>
        </CardContent>
      </Card>
    );
  }

  const isUrl = result.startsWith('http://') || result.startsWith('https://');
  
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };
  
  const handleOpenUrl = () => {
    if (isUrl) {
      window.open(result, '_blank');
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="w-5 h-5" />
          Scan-Ergebnis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-gray-50 rounded-lg border">
          <div className="flex justify-between items-start">
            <div className="font-mono text-sm break-all">
              {result}
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleCopy}
              className="h-8 w-8 p-0 ml-2 shrink-0"
            >
              {copied ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
        
        {isUrl && (
          <Button 
            onClick={handleOpenUrl}
            className="w-full gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            Link öffnen
          </Button>
        )}
        
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            onClick={onHome}
            className="flex-1"
          >
            Zurück
          </Button>
          <Button
            onClick={onScanAgain}
            className="flex-1 gap-2"
          >
            <Camera className="w-4 h-4" />
            Erneut scannen
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}