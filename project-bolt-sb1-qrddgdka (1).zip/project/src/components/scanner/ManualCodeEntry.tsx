import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Keyboard, Send, AlertCircle, X } from 'lucide-react';

interface ManualCodeEntryProps {
  onSubmit: (code: string) => void;
  onCancel: () => void;
}

export function ManualCodeEntry({ onSubmit, onCancel }: ManualCodeEntryProps) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!code.trim()) {
      setError('Bitte geben Sie einen Code ein');
      return;
    }
    
    // Basic validation - you can add more specific validation based on your QR code format
    if (code.trim().length < 3) {
      setError('Der eingegebene Code ist zu kurz');
      return;
    }
    
    onSubmit(code.trim());
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Keyboard className="w-5 h-5" />
            Manuelle Code-Eingabe
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
            className="h-8 w-8 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="code">QR-Code Inhalt</Label>
            <Input
              id="code"
              value={code}
              onChange={(e) => {
                setCode(e.target.value);
                setError('');
              }}
              placeholder="Geben Sie den QR-Code-Inhalt ein"
              className="font-mono"
            />
            <p className="text-xs text-gray-500">
              Geben Sie den Inhalt des QR-Codes ein, wenn die Kamera nicht funktioniert oder der Code beschädigt ist.
            </p>
          </div>
          
          <div className="flex gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="flex-1"
            >
              Abbrechen
            </Button>
            <Button
              type="submit"
              className="flex-1 gap-2"
            >
              <Send className="w-4 h-4" />
              Senden
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}