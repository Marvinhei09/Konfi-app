import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { QrCode, Plus, Scan, CheckCircle, Clock, MapPin, User, Calendar, Camera, Users } from 'lucide-react';
import { QRCodeGenerator } from './QRCodeGenerator';
import { CameraQRScanner } from './CameraQRScanner';
import { MultiSelectPassManager } from './MultiSelectPassManager';
import { activityRequirements } from '@/data/activities';
import type { KonfiPass, ActivitySignature, KonfiContact } from '@/types';

interface PassManagerProps {
  passes: KonfiPass[];
  onPassesChange: (passes: KonfiPass[]) => void;
  contacts: KonfiContact[];
}

export function PassManager({ passes, onPassesChange, contacts }: PassManagerProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedPass, setSelectedPass] = useState<KonfiPass | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  const [scanInput, setScanInput] = useState('');
  
  // Signature form state
  const [signatureForm, setSignatureForm] = useState({
    activityType: '' as 'konfirmationsunterricht' | 'gottesdienst' | 'kirchliche_aktivitaet' | '',
    activityTitle: '',
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().slice(0, 5),
    comments: '',
    location: ''
  });

  const generateQRCode = (username: string) => {
    const timestamp = Date.now();
    return `KONFI_${username.toUpperCase().replace('.', '_')}_2025_${timestamp.toString().slice(-6)}`;
  };

  const createPass = (konfiUsername: string) => {
    const newPass: KonfiPass = {
      id: Date.now().toString(),
      konfiUsername,
      qrCode: generateQRCode(konfiUsername),
      signatures: [],
      createdAt: new Date().toISOString(),
      isActive: true
    };

    onPassesChange([...passes, newPass]);
  };

  const addSignature = (passId: string) => {
    if (!signatureForm.activityType || !signatureForm.activityTitle) return;

    const newSignature: ActivitySignature = {
      id: Date.now().toString(),
      konfiUsername: selectedPass!.konfiUsername,
      activityType: signatureForm.activityType,
      activityTitle: signatureForm.activityTitle,
      date: signatureForm.date,
      time: signatureForm.time,
      adminSignature: 'Marvin.Heiligentag', // Current admin
      comments: signatureForm.comments || undefined,
      location: signatureForm.location || undefined
    };

    const updatedPasses = passes.map(pass => 
      pass.id === passId 
        ? { ...pass, signatures: [...pass.signatures, newSignature] }
        : pass
    );

    onPassesChange(updatedPasses);
    
    // Reset form
    setSignatureForm({
      activityType: '',
      activityTitle: '',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().slice(0, 5),
      comments: '',
      location: ''
    });
  };

  const handleScan = (qrCode: string) => {
    const foundPass = passes.find(pass => pass.qrCode === qrCode);
    if (foundPass) {
      setSelectedPass(foundPass);
      setShowScanner(false);
      setShowCameraScanner(false);
      setScanInput('');
      setActiveTab('sign');
    } else {
      alert('QR-Code nicht gefunden!');
    }
  };

  const handleManualScan = () => {
    handleScan(scanInput);
  };

  const getProgressStats = (pass: KonfiPass) => {
    const stats = activityRequirements.map(req => {
      const count = pass.signatures.filter(sig => sig.activityType === req.type).length;
      return {
        ...req,
        current: count,
        percentage: Math.min((count / req.required) * 100, 100)
      };
    });
    return stats;
  };

  const getActivityTypeLabel = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'Konfirmationsunterricht';
      case 'gottesdienst': return 'Gottesdienst';
      case 'kirchliche_aktivitaet': return 'Kirchliche Aktivität';
      default: return type;
    }
  };

  const getActivityTypeColor = (type: string) => {
    switch (type) {
      case 'konfirmationsunterricht': return 'bg-blue-500';
      case 'gottesdienst': return 'bg-green-500';
      case 'kirchliche_aktivitaet': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Digitaler Konfirmationspass</h2>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowCameraScanner(true)}
            className="gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
          >
            <Camera className="w-4 h-4" />
            Kamera scannen
          </Button>
          <Button 
            onClick={() => setShowScanner(true)}
            variant="outline"
            className="gap-2"
          >
            <Scan className="w-4 h-4" />
            Manuell eingeben
          </Button>
        </div>
      </div>

      {/* Camera QR Scanner */}
      <CameraQRScanner
        isOpen={showCameraScanner}
        onScanSuccess={handleScan}
        onClose={() => setShowCameraScanner(false)}
      />

      {/* Manual QR Scanner */}
      {showScanner && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scan className="w-5 h-5" />
              QR-Code manuell eingeben
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="scanInput">QR-Code eingeben</Label>
              <Input
                id="scanInput"
                value={scanInput}
                onChange={(e) => setScanInput(e.target.value)}
                placeholder="z.B. KONFI_TIM_HEILIGENTAG_2025_001"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleManualScan} disabled={!scanInput}>
                Scannen
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowScanner(false);
                  setScanInput('');
                }}
              >
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Übersicht</TabsTrigger>
          <TabsTrigger value="sign">Unterschreiben</TabsTrigger>
          <TabsTrigger value="multi-select">Mehrfachauswahl</TabsTrigger>
          <TabsTrigger value="manage">Verwalten</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {passes.map((pass) => {
              const contact = contacts.find(c => c.username === pass.konfiUsername);
              const stats = getProgressStats(pass);
              const totalProgress = stats.reduce((sum, stat) => sum + stat.percentage, 0) / stats.length;
              
              return (
                <Card key={pass.id} className="transition-all hover:shadow-lg">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold">
                            {contact ? `${contact.firstName} ${contact.lastName}` : pass.konfiUsername}
                          </h3>
                          <p className="text-sm text-gray-600">@{pass.konfiUsername}</p>
                        </div>
                      </div>
                      <Badge variant={pass.isActive ? "default" : "secondary"}>
                        {pass.isActive ? "Aktiv" : "Inaktiv"}
                      </Badge>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span>Gesamtfortschritt</span>
                        <span>{Math.round(totalProgress)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${totalProgress}%` }}
                        />
                      </div>
                    </div>

                    <div className="space-y-1 text-xs">
                      {stats.map((stat) => (
                        <div key={stat.type} className="flex justify-between">
                          <span>{stat.title}</span>
                          <span className={stat.current >= stat.required ? 'text-green-600 font-semibold' : 'text-gray-600'}>
                            {stat.current}/{stat.required}
                          </span>
                        </div>
                      ))}
                    </div>

                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="w-full mt-3"
                      onClick={() => {
                        setSelectedPass(pass);
                        setActiveTab('sign');
                      }}
                    >
                      Details anzeigen
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {passes.length === 0 && (
            <Card className="p-12 text-center bg-gray-50">
              <CardContent>
                <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Noch keine Konfirmationspässe erstellt.</p>
                <p className="text-sm text-gray-500">Erstellen Sie Pässe für alle Konfirmanden.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="sign" className="space-y-4">
          {selectedPass ? (
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="w-5 h-5" />
                    Konfirmationspass
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <QRCodeGenerator value={selectedPass.qrCode} size={150} />
                    <div className="mt-4">
                      <h3 className="font-semibold text-lg">
                        {contacts.find(c => c.username === selectedPass.konfiUsername)?.firstName} {' '}
                        {contacts.find(c => c.username === selectedPass.konfiUsername)?.lastName}
                      </h3>
                      <p className="text-gray-600">@{selectedPass.konfiUsername}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {getProgressStats(selectedPass).map((stat) => (
                      <div key={stat.type} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>{stat.title}</span>
                          <span className={stat.current >= stat.required ? 'text-green-600 font-semibold' : 'text-gray-600'}>
                            {stat.current}/{stat.required}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all ${getActivityTypeColor(stat.type)}`}
                            style={{ width: `${stat.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Neue Unterschrift hinzufügen</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="activityType">Art der Aktivität</Label>
                    <Select 
                      value={signatureForm.activityType} 
                      onValueChange={(value: any) => setSignatureForm({...signatureForm, activityType: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Aktivität auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="konfirmationsunterricht">Konfirmationsunterricht</SelectItem>
                        <SelectItem value="gottesdienst">Gottesdienst</SelectItem>
                        <SelectItem value="kirchliche_aktivitaet">Kirchliche Aktivität</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="activityTitle">Titel der Aktivität</Label>
                    <Input
                      id="activityTitle"
                      value={signatureForm.activityTitle}
                      onChange={(e) => setSignatureForm({...signatureForm, activityTitle: e.target.value})}
                      placeholder="z.B. Die Zehn Gebote, Sonntagsgottesdienst"
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label htmlFor="date">Datum</Label>
                      <Input
                        id="date"
                        type="date"
                        value={signatureForm.date}
                        onChange={(e) => setSignatureForm({...signatureForm, date: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="time">Uhrzeit</Label>
                      <Input
                        id="time"
                        type="time"
                        value={signatureForm.time}
                        onChange={(e) => setSignatureForm({...signatureForm, time: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="location">Ort (optional)</Label>
                    <Input
                      id="location"
                      value={signatureForm.location}
                      onChange={(e) => setSignatureForm({...signatureForm, location: e.target.value})}
                      placeholder="z.B. Gemeindehaus, Hauptkirche"
                    />
                  </div>

                  <div>
                    <Label htmlFor="comments">Kommentar (optional)</Label>
                    <Textarea
                      id="comments"
                      value={signatureForm.comments}
                      onChange={(e) => setSignatureForm({...signatureForm, comments: e.target.value})}
                      placeholder="Zusätzliche Bemerkungen..."
                      rows={3}
                    />
                  </div>

                  <Button 
                    onClick={() => addSignature(selectedPass.id)}
                    className="w-full gap-2"
                    disabled={!signatureForm.activityType || !signatureForm.activityTitle}
                  >
                    <CheckCircle className="w-4 h-4" />
                    Unterschrift hinzufügen
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="p-12 text-center bg-gray-50">
              <CardContent>
                <div className="space-y-4">
                  <Camera className="w-16 h-16 text-gray-400 mx-auto" />
                  <div>
                    <p className="text-gray-600 font-semibold">Scannen Sie einen QR-Code</p>
                    <p className="text-sm text-gray-500">Verwenden Sie die Kamera oder geben Sie den Code manuell ein</p>
                  </div>
                  <div className="flex gap-2 justify-center">
                    <Button 
                      onClick={() => setShowCameraScanner(true)}
                      className="gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      Kamera öffnen
                    </Button>
                    <Button 
                      onClick={() => setShowScanner(true)}
                      variant="outline"
                      className="gap-2"
                    >
                      <Scan className="w-4 h-4" />
                      Manuell eingeben
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {selectedPass && selectedPass.signatures.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Unterschriftenverlauf</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {selectedPass.signatures
                    .sort((a, b) => new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime())
                    .map((signature) => (
                      <Card key={signature.id} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <Badge 
                                variant="secondary" 
                                className={`${getActivityTypeColor(signature.activityType)} text-white`}
                              >
                                {getActivityTypeLabel(signature.activityType)}
                              </Badge>
                              <h4 className="font-semibold mt-1">{signature.activityTitle}</h4>
                            </div>
                            <div className="text-right text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {new Date(signature.date).toLocaleDateString('de-DE')}
                              </div>
                              <div className="flex items-center gap-1 mt-1">
                                <Clock className="w-3 h-3" />
                                {signature.time}
                              </div>
                            </div>
                          </div>
                          
                          <div className="text-sm text-gray-600 space-y-1">
                            {signature.location && (
                              <div className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                <span>{signature.location}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              <span>Unterschrieben von: {signature.adminSignature}</span>
                            </div>
                            {signature.comments && (
                              <p className="mt-2 p-2 bg-gray-50 rounded text-xs">
                                {signature.comments}
                              </p>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="multi-select" className="space-y-4">
          <MultiSelectPassManager
            passes={passes}
            onPassesChange={onPassesChange}
            contacts={contacts}
          />
        </TabsContent>

        <TabsContent value="manage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pässe verwalten</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Neue Pässe erstellen</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Erstellen Sie Konfirmationspässe für Konfirmanden, die noch keinen haben.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {contacts
                      .filter(contact => !passes.find(pass => pass.konfiUsername === contact.username))
                      .map((contact) => (
                        <Button
                          key={contact.id}
                          variant="outline"
                          size="sm"
                          onClick={() => createPass(contact.username)}
                          className="gap-2"
                        >
                          <Plus className="w-3 h-3" />
                          {contact.firstName} {contact.lastName}
                        </Button>
                      ))}
                  </div>
                  {contacts.filter(contact => !passes.find(pass => pass.konfiUsername === contact.username)).length === 0 && (
                    <p className="text-sm text-gray-500">Alle Konfirmanden haben bereits einen Pass.</p>
                  )}
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-2">Aktivitätsanforderungen</h3>
                  <div className="grid gap-3 md:grid-cols-3">
                    {activityRequirements.map((req) => (
                      <Card key={req.type} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <h4 className="font-semibold">{req.title}</h4>
                          <p className="text-2xl font-bold text-blue-600">{req.required}</p>
                          <p className="text-xs text-gray-600">{req.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}