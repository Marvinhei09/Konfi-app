import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Trophy, Crown, Medal, Star, TrendingUp, TrendingDown, 
  Minus, Edit, Save, X, Sparkles, Zap
} from 'lucide-react';
import type { User, RankingSettings } from '@/types';

interface RankingLeaderboardProps {
  users: User[];
  settings: RankingSettings;
  isAdminView?: boolean;
  onManualOverride?: (userId: string, newScore: number) => void;
}

export function RankingLeaderboard({ 
  users, 
  settings, 
  isAdminView = false, 
  onManualOverride 
}: RankingLeaderboardProps) {
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editScore, setEditScore] = useState<number>(0);

  const sortedUsers = [...users]
    .sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0))
    .slice(0, settings.maxDisplayCount);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Medal className="w-6 h-6 text-orange-600" />;
      default: return <Star className="w-5 h-5 text-blue-500" />;
    }
  };

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return {
          container: "bg-gradient-to-r from-yellow-50 via-yellow-100 to-yellow-50 border-2 border-yellow-300 shadow-lg transform hover:scale-105 transition-all duration-500",
          glow: "shadow-yellow-200",
          animation: "animate-pulse"
        };
      case 2:
        return {
          container: "bg-gradient-to-r from-gray-50 via-gray-100 to-gray-50 border-2 border-gray-300 shadow-md transform hover:scale-102 transition-all duration-500",
          glow: "shadow-gray-200",
          animation: ""
        };
      case 3:
        return {
          container: "bg-gradient-to-r from-orange-50 via-orange-100 to-orange-50 border-2 border-orange-300 shadow-md transform hover:scale-102 transition-all duration-500",
          glow: "shadow-orange-200",
          animation: ""
        };
      default:
        return {
          container: "bg-white border border-gray-200 hover:shadow-md transition-all duration-300",
          glow: "",
          animation: ""
        };
    }
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'same') => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-500" />;
      default: return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const handleEditStart = (user: User) => {
    setEditingUserId(user.id);
    setEditScore(user.totalScore || 0);
  };

  const handleEditSave = () => {
    if (editingUserId && onManualOverride) {
      onManualOverride(editingUserId, editScore);
      setEditingUserId(null);
    }
  };

  const handleEditCancel = () => {
    setEditingUserId(null);
    setEditScore(0);
  };

  const getInitials = (firstName?: string, lastName?: string, username?: string) => {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`.toUpperCase();
    }
    if (username) {
      const parts = username.split('.');
      if (parts.length >= 2) {
        return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
      }
      return username.slice(0, 2).toUpperCase();
    }
    return 'KU';
  };

  return (
    <div className="space-y-6">
      {/* Top 3 Podium */}
      <div className="grid gap-6 md:grid-cols-3">
        {sortedUsers.slice(0, 3).map((user, index) => {
          const rank = index + 1;
          const style = getRankStyle(rank);
          
          return (
            <Card 
              key={user.id} 
              className={`${style.container} ${style.glow} relative overflow-hidden`}
            >
              {/* Sparkle-Effekt für Platz 1 */}
              {rank === 1 && (
                <div className="absolute inset-0 pointer-events-none">
                  <Sparkles className="absolute top-2 right-2 w-4 h-4 text-yellow-400 animate-pulse" />
                  <Sparkles className="absolute bottom-2 left-2 w-3 h-3 text-yellow-400 animate-pulse delay-300" />
                  <Zap className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-yellow-400 opacity-20 animate-ping" />
                </div>
              )}
              
              <CardContent className="p-6 text-center relative z-10">
                <div className="mb-4">
                  <div className={`w-20 h-20 mx-auto mb-3 relative ${rank === 1 ? 'animate-bounce' : ''}`}>
                    {/* Graues Standard-Profilbild */}
                    <div className={`w-20 h-20 rounded-full bg-gray-400 flex items-center justify-center text-white font-bold text-xl border-4 ${
                      rank === 1 ? 'border-yellow-400' : 
                      rank === 2 ? 'border-gray-400' : 
                      'border-orange-400'
                    } shadow-lg`}>
                      {getInitials(user.firstName, user.lastName, user.username)}
                    </div>
                    
                    {/* Rang-Badge */}
                    <div className={`absolute -top-2 -right-2 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                      rank === 1 ? 'bg-yellow-500' : 
                      rank === 2 ? 'bg-gray-500' : 
                      'bg-orange-500'
                    } border-2 border-white shadow-lg`}>
                      {rank}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center gap-2 mb-2">
                    {getRankIcon(rank)}
                    <h3 className="font-bold text-lg">
                      {user.firstName && user.lastName 
                        ? `${user.firstName} ${user.lastName}` 
                        : user.username
                      }
                    </h3>
                  </div>
                  
                  <div className="space-y-1">
                    <Badge variant="outline" className="text-xs">
                      {user.role === 'konfi' ? user.konfiRole : user.role}
                    </Badge>
                    <p className="text-2xl font-bold text-gray-900">
                      {user.totalScore}%
                    </p>
                    <div className="flex items-center justify-center gap-1">
                      {getTrendIcon(user.trend || 'same')}
                      <span className="text-xs text-gray-600">
                        {user.previousRank && user.previousRank !== rank ? 
                          `von Platz ${user.previousRank}` : 
                          'Unverändert'
                        }
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Vollständige Rangliste */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            Vollständige Rangliste
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {sortedUsers.map((user, index) => {
              const rank = index + 1;
              const isEditing = editingUserId === user.id;
              
              return (
                <div 
                  key={user.id} 
                  className={`flex items-center gap-4 p-4 rounded-lg transition-all duration-500 ${
                    rank <= 3 ? 'bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200' : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  {/* Rang */}
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                    rank === 1 ? 'bg-yellow-500' : 
                    rank === 2 ? 'bg-gray-400' : 
                    rank === 3 ? 'bg-orange-600' : 
                    'bg-blue-500'
                  }`}>
                    {rank}
                  </div>

                  {/* Graues Standard-Profilbild */}
                  <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center text-white font-semibold border-2 border-white shadow">
                    {getInitials(user.firstName, user.lastName, user.username)}
                  </div>

                  {/* Benutzer-Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold">
                        {user.firstName && user.lastName 
                          ? `${user.firstName} ${user.lastName}` 
                          : user.username
                        }
                      </h4>
                      <Badge variant="outline" className="text-xs">
                        {user.role === 'konfi' ? user.konfiRole : user.role}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">@{user.username}</p>
                  </div>

                  {/* Punktzahl */}
                  <div className="text-center">
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          value={editScore}
                          onChange={(e) => setEditScore(parseInt(e.target.value))}
                          className="w-20 h-8 text-center"
                        />
                        <Button size="sm" onClick={handleEditSave} className="h-8 w-8 p-0">
                          <Save className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={handleEditCancel} className="h-8 w-8 p-0">
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <div>
                          <p className="text-xl font-bold">{user.totalScore}%</p>
                          <p className="text-xs text-gray-500">Gesamtpunkte</p>
                        </div>
                        {isAdminView && onManualOverride && (
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            onClick={() => handleEditStart(user)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Trend */}
                  <div className="flex items-center gap-2">
                    {getTrendIcon(user.trend || 'same')}
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {user.previousRank && user.previousRank !== rank ? 
                          `${user.previousRank} → ${rank}` : 
                          `Platz ${rank}`
                        }
                      </p>
                      <p className="text-xs text-gray-500">
                        {user.lastActive ? 
                          `Aktiv: ${new Date(user.lastActive).toLocaleDateString('de-DE')}` : 
                          'Nie aktiv'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {sortedUsers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Trophy className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Noch keine Ranking-Daten verfügbar</p>
              <p className="text-sm">Führen Sie eine Aktualisierung durch, um Rankings zu generieren</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}