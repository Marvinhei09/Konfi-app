import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Trophy, Crown, Medal, Star, Settings, Eye, EyeOff, 
  TrendingUp, TrendingDown, Minus, RefreshCw, Save,
  AlertCircle, CheckCircle, History, Users, Target, Award
} from 'lucide-react';
import { RankingLeaderboard } from './RankingLeaderboard';
import { AwardSystem } from './AwardSystem';
import { ProfileImageEditor } from './ProfileImageEditor';
import type { User, RankingSettings, RankingAuditLog, RankingCriteria } from '@/types';

interface RankingDashboardProps {
  users: User[];
  onUsersChange: (users: User[]) => void;
  currentUser: User;
  isAdminView?: boolean;
}

export function RankingDashboard({ users, onUsersChange, currentUser, isAdminView = false }: RankingDashboardProps) {
  const [activeTab, setActiveTab] = useState('leaderboard');
  const [settings, setSettings] = useState<RankingSettings>({
    isPublicVisible: false, // Standardmäßig ausgeblendet für Konfirmanden
    updateInterval: 300,
    maxDisplayCount: 10,
    criteria: [
      { id: '1', name: 'Quiz-Leistung', weight: 40, isActive: true, description: 'Durchschnittliche Punktzahl in Quiz und Tests' },
      { id: '2', name: 'Anwesenheit', weight: 30, isActive: true, description: 'Regelmäßige Teilnahme am Konfirmationsunterricht' },
      { id: '3', name: 'Mitarbeit', weight: 20, isActive: true, description: 'Aktive Beteiligung und Engagement im Unterricht' },
      { id: '4', name: 'Lernplattform', weight: 10, isActive: true, description: 'Nutzung der digitalen Lernmaterialien' }
    ],
    lastUpdated: new Date().toISOString()
  });
  const [auditLog, setAuditLog] = useState<RankingAuditLog[]>([]);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showProfileEditor, setShowProfileEditor] = useState(false);

  // Automatische Ranking-Aktualisierung
  useEffect(() => {
    const interval = setInterval(() => {
      if (settings.isPublicVisible) {
        updateRankings();
      }
    }, settings.updateInterval * 1000);

    return () => clearInterval(interval);
  }, [settings.updateInterval, settings.isPublicVisible]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const calculateTotalScore = (user: User): number => {
    const activeCriteria = settings.criteria.filter(c => c.isActive);
    const totalWeight = activeCriteria.reduce((sum, c) => sum + c.weight, 0);
    
    if (totalWeight === 0) return 0;

    let weightedScore = 0;
    activeCriteria.forEach(criteria => {
      let score = 0;
      switch (criteria.name) {
        case 'Quiz-Leistung':
          score = user.quizScore || 0;
          break;
        case 'Anwesenheit':
          score = user.attendanceScore || 0;
          break;
        case 'Mitarbeit':
          score = user.participationScore || 0;
          break;
        case 'Lernplattform':
          score = Math.min((user.quizScore || 0) * 0.8, 100); // Simuliert Lernplattform-Score
          break;
      }
      weightedScore += (score * criteria.weight) / 100;
    });

    return Math.round((weightedScore / totalWeight) * 100);
  };

  const updateRankings = () => {
    setIsUpdating(true);
    
    // Simuliere Netzwerk-Latenz
    setTimeout(() => {
      const updatedUsers = users.map(user => ({
        ...user,
        totalScore: calculateTotalScore(user),
        lastActive: new Date().toISOString()
      }));

      // Sortiere nach Gesamtpunktzahl - nur Konfirmanden für das Ranking
      const konfirmanden = updatedUsers.filter(user => user.role === 'konfi');
      konfirmanden.sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0));

      // Weise Ränge nur an Konfirmanden zu
      const rankedUsers = updatedUsers.map(user => {
        if (user.role === 'konfi') {
          const konfiIndex = konfirmanden.findIndex(k => k.id === user.id);
          const newRank = konfiIndex + 1;
          const previousRank = user.rank || newRank;
          
          let trend: 'up' | 'down' | 'same' = 'same';
          if (newRank < previousRank) trend = 'up';
          else if (newRank > previousRank) trend = 'down';

          return {
            ...user,
            rank: newRank,
            previousRank,
            trend
          };
        }
        return user; // Admins und Teamer behalten ihre ursprünglichen Daten
      });

      onUsersChange(rankedUsers);
      
      // Audit-Log-Eintrag
      const logEntry: RankingAuditLog = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        action: 'score_update',
        adminUser: currentUser.username,
        details: 'Automatische Ranking-Aktualisierung durchgeführt (nur Konfirmanden)'
      };
      setAuditLog(prev => [logEntry, ...prev.slice(0, 49)]); // Behalte nur die letzten 50 Einträge

      setSettings(prev => ({ ...prev, lastUpdated: new Date().toISOString() }));
      setIsUpdating(false);
      showNotification('success', 'Rankings erfolgreich aktualisiert');
    }, 500);
  };

  const handleCriteriaChange = (criteriaId: string, field: 'weight' | 'isActive', value: number | boolean) => {
    const updatedCriteria = settings.criteria.map(c => 
      c.id === criteriaId ? { ...c, [field]: value } : c
    );

    // Validiere Gewichtungen
    const totalWeight = updatedCriteria.filter(c => c.isActive).reduce((sum, c) => sum + c.weight, 0);
    if (totalWeight > 100) {
      showNotification('error', 'Gesamtgewichtung darf 100% nicht überschreiten');
      return;
    }

    setSettings(prev => ({ ...prev, criteria: updatedCriteria }));
    
    // Audit-Log
    const logEntry: RankingAuditLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      action: 'criteria_change',
      adminUser: currentUser.username,
      details: `Bewertungskriterium "${settings.criteria.find(c => c.id === criteriaId)?.name}" geändert`,
      oldValue: settings.criteria.find(c => c.id === criteriaId)?.[field],
      newValue: value
    };
    setAuditLog(prev => [logEntry, ...prev]);
  };

  const togglePublicVisibility = () => {
    const newVisibility = !settings.isPublicVisible;
    setSettings(prev => ({ ...prev, isPublicVisible: newVisibility }));
    
    const logEntry: RankingAuditLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      action: 'visibility_toggle',
      adminUser: currentUser.username,
      details: `Öffentliche Sichtbarkeit ${newVisibility ? 'aktiviert' : 'deaktiviert'}`
    };
    setAuditLog(prev => [logEntry, ...prev]);
    
    showNotification('success', `Ranking ist jetzt ${newVisibility ? 'öffentlich sichtbar' : 'ausgeblendet'}`);
  };

  const handleManualOverride = (userId: string, newScore: number) => {
    const updatedUsers = users.map(user => 
      user.id === userId ? { ...user, totalScore: newScore } : user
    );
    
    onUsersChange(updatedUsers);
    
    const logEntry: RankingAuditLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      action: 'manual_override',
      adminUser: currentUser.username,
      details: 'Manuelle Punktzahl-Anpassung',
      affectedUser: users.find(u => u.id === userId)?.username,
      newValue: newScore
    };
    setAuditLog(prev => [logEntry, ...prev]);
    
    showNotification('success', 'Punktzahl manuell angepasst');
  };

  const getTopPerformers = () => {
    // Nur Konfirmanden für das Ranking berücksichtigen
    const konfirmanden = users.filter(u => u.role === 'konfi');
    const sortedUsers = [...konfirmanden].sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0));
    
    return {
      overall: sortedUsers.slice(0, 3),
      ku4: sortedUsers.filter(u => u.konfiRole === 'KU4').slice(0, 3),
      kuz: sortedUsers.filter(u => u.konfiRole === 'KUZ').slice(0, 3),
      ku8: sortedUsers.filter(u => u.konfiRole === 'KU8').slice(0, 3)
    };
  };

  const topPerformers = getTopPerformers();
  const totalWeight = settings.criteria.filter(c => c.isActive).reduce((sum, c) => sum + c.weight, 0);

  // Für Konfirmanden: Zeige Ranking nur wenn Admin es freigeschaltet hat
  const canViewRanking = isAdminView || (currentUser.role === 'konfi' && settings.isPublicVisible);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Trophy className="w-8 h-8 text-yellow-500" />
            {isAdminView ? 'Ranking-System' : 'Meine Leistung'}
          </h2>
          <p className="text-gray-600 mt-1">
            {isAdminView 
              ? 'Dynamische Leistungsbewertung mit rollenbasierten Rankings'
              : 'Verfolgen Sie Ihren Fortschritt und Ihre Leistung'
            }
          </p>
        </div>
        {isAdminView && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Label htmlFor="visibility-toggle">Für Konfis sichtbar</Label>
              <Switch
                id="visibility-toggle"
                checked={settings.isPublicVisible}
                onCheckedChange={togglePublicVisibility}
              />
              {settings.isPublicVisible ? (
                <Eye className="w-4 h-4 text-green-600" />
              ) : (
                <EyeOff className="w-4 h-4 text-red-600" />
              )}
            </div>
            <Button
              onClick={updateRankings}
              disabled={isUpdating}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Aktualisiere...' : 'Aktualisieren'}
            </Button>
          </div>
        )}
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          {notification.type === 'error' ? (
            <AlertCircle className="h-4 w-4" />
          ) : (
            <CheckCircle className="h-4 w-4" />
          )}
          <AlertDescription>{notification.message}</AlertDescription>
        </Alert>
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className={`grid w-full ${isAdminView ? 'grid-cols-5' : 'grid-cols-2'}`}>
          <TabsTrigger value="leaderboard" className="gap-2">
            <Trophy className="w-4 h-4" />
            {isAdminView ? 'Rangliste' : 'Meine Position'}
          </TabsTrigger>
          <TabsTrigger value="awards" className="gap-2">
            <Award className="w-4 h-4" />
            Auszeichnungen
          </TabsTrigger>
          {isAdminView && (
            <>
              <TabsTrigger value="categories" className="gap-2">
                <Medal className="w-4 h-4" />
                Kategorien
              </TabsTrigger>
              <TabsTrigger value="admin" className="gap-2">
                <Settings className="w-4 h-4" />
                Verwaltung
              </TabsTrigger>
              <TabsTrigger value="audit" className="gap-2">
                <History className="w-4 h-4" />
                Protokoll
              </TabsTrigger>
            </>
          )}
        </TabsList>

        {/* Rangliste */}
        <TabsContent value="leaderboard" className="space-y-6">
          {canViewRanking ? (
            <RankingLeaderboard
              users={users.filter(u => u.role === 'konfi')} // Nur Konfirmanden anzeigen
              settings={settings}
              isAdminView={isAdminView}
              onManualOverride={handleManualOverride}
            />
          ) : (
            <Card className="p-12 text-center bg-gray-50">
              <CardContent>
                <EyeOff className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Das Ranking ist derzeit nicht für Konfirmanden sichtbar.</p>
                <p className="text-sm text-gray-500">
                  Ihr Administrator kann die Sichtbarkeit in den Einstellungen aktivieren.
                </p>
                {currentUser.rank && (
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <p className="text-lg font-semibold text-blue-800">
                      Ihre aktuelle Position: Platz {currentUser.rank}
                    </p>
                    <p className="text-sm text-blue-600">
                      Gesamtpunktzahl: {currentUser.totalScore}%
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Auszeichnungen */}
        <TabsContent value="awards" className="space-y-6">
          <AwardSystem
            users={users}
            onUsersChange={onUsersChange}
            isAdminView={isAdminView}
          />
        </TabsContent>

        {/* Kategorien - nur für Admins */}
        {isAdminView && (
          <TabsContent value="categories" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Gesamt-Ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-yellow-500" />
                    Gesamt-Ranking (nur Konfirmanden)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topPerformers.overall.map((user, index) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-yellow-50 to-orange-50">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                          index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-600'
                        }`}>
                          {index + 1}
                        </div>
                        {user.profileImage ? (
                          <img
                            src={user.profileImage}
                            alt={`${user.firstName} ${user.lastName}`}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </div>
                        )}
                        <div className="flex-1">
                          <p className="font-semibold">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-gray-600">{user.totalScore}% Punkte</p>
                        </div>
                        {user.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-500" />}
                        {user.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-500" />}
                        {user.trend === 'same' && <Minus className="w-4 h-4 text-gray-400" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* KU4 Ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-blue-500" />
                    KU4 - 4. Klasse
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topPerformers.ku4.length > 0 ? topPerformers.ku4.map((user, index) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg bg-blue-50">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                          index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-600'
                        }`}>
                          {index + 1}
                        </div>
                        {user.profileImage ? (
                          <img
                            src={user.profileImage}
                            alt={`${user.firstName} ${user.lastName}`}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-semibold">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </div>
                        )}
                        <div className="flex-1">
                          <p className="font-medium text-sm">{user.firstName} {user.lastName}</p>
                          <p className="text-xs text-gray-600">{user.totalScore}%</p>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-sm">Keine KU4-Teilnehmer</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* KUZ Ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-green-500" />
                    KUZ - Zwischenjahr
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topPerformers.kuz.length > 0 ? topPerformers.kuz.map((user, index) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg bg-green-50">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                          index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-600'
                        }`}>
                          {index + 1}
                        </div>
                        {user.profileImage ? (
                          <img
                            src={user.profileImage}
                            alt={`${user.firstName} ${user.lastName}`}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white text-sm font-semibold">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </div>
                        )}
                        <div className="flex-1">
                          <p className="font-medium text-sm">{user.firstName} {user.lastName}</p>
                          <p className="text-xs text-gray-600">{user.totalScore}%</p>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-sm">Keine KUZ-Teilnehmer</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* KU8 Ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-red-500" />
                    KU8 - 8. Klasse
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topPerformers.ku8.length > 0 ? topPerformers.ku8.map((user, index) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg bg-red-50">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                          index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-600'
                        }`}>
                          {index + 1}
                        </div>
                        {user.profileImage ? (
                          <img
                            src={user.profileImage}
                            alt={`${user.firstName} ${user.lastName}`}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center text-white text-sm font-semibold">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </div>
                        )}
                        <div className="flex-1">
                          <p className="font-medium text-sm">{user.firstName} {user.lastName}</p>
                          <p className="text-xs text-gray-600">{user.totalScore}%</p>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-sm">Keine KU8-Teilnehmer</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        )}

        {/* Admin-Verwaltung */}
        {isAdminView && (
          <TabsContent value="admin" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Bewertungskriterien */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Bewertungskriterien
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {settings.criteria.map((criteria) => (
                    <div key={criteria.id} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold">{criteria.name}</h4>
                          <p className="text-sm text-gray-600">{criteria.description}</p>
                        </div>
                        <Switch
                          checked={criteria.isActive}
                          onCheckedChange={(checked) => handleCriteriaChange(criteria.id, 'isActive', checked)}
                        />
                      </div>
                      {criteria.isActive && (
                        <div>
                          <Label htmlFor={`weight-${criteria.id}`}>
                            Gewichtung: {criteria.weight}%
                          </Label>
                          <Input
                            id={`weight-${criteria.id}`}
                            type="range"
                            min="0"
                            max="100"
                            value={criteria.weight}
                            onChange={(e) => handleCriteriaChange(criteria.id, 'weight', parseInt(e.target.value))}
                            className="mt-2"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                  
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Gesamtgewichtung:</span>
                      <Badge variant={totalWeight === 100 ? "default" : totalWeight > 100 ? "destructive" : "secondary"}>
                        {totalWeight}%
                      </Badge>
                    </div>
                    {totalWeight !== 100 && (
                      <p className="text-sm text-orange-600 mt-1">
                        Empfohlen: Gesamtgewichtung sollte 100% betragen
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* System-Einstellungen */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    System-Einstellungen
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="update-interval">
                      Aktualisierungsintervall (Sekunden)
                    </Label>
                    <Input
                      id="update-interval"
                      type="number"
                      min="60"
                      max="3600"
                      value={settings.updateInterval}
                      onChange={(e) => setSettings(prev => ({ 
                        ...prev, 
                        updateInterval: parseInt(e.target.value) 
                      }))}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="max-display">
                      Maximale Anzeige (Anzahl Benutzer)
                    </Label>
                    <Input
                      id="max-display"
                      type="number"
                      min="3"
                      max="50"
                      value={settings.maxDisplayCount}
                      onChange={(e) => setSettings(prev => ({ 
                        ...prev, 
                        maxDisplayCount: parseInt(e.target.value) 
                      }))}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Sichtbarkeit für Konfirmanden</Label>
                      <p className="text-sm text-gray-600">
                        Ranking für Konfirmanden anzeigen
                      </p>
                    </div>
                    <Switch
                      checked={settings.isPublicVisible}
                      onCheckedChange={togglePublicVisibility}
                    />
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-sm text-gray-600">
                      Letzte Aktualisierung: {new Date(settings.lastUpdated).toLocaleString('de-DE')}
                    </p>
                  </div>

                  <Button onClick={updateRankings} className="w-full gap-2">
                    <Save className="w-4 h-4" />
                    Einstellungen speichern
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        )}

        {/* Audit-Protokoll */}
        {isAdminView && (
          <TabsContent value="audit" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Audit-Protokoll
                </CardTitle>
              </CardHeader>
              <CardContent>
                {auditLog.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <History className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Noch keine Protokolleinträge vorhanden</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {auditLog.map((entry) => (
                      <div key={entry.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <Badge variant="outline" className="mb-1">
                              {entry.action === 'score_update' && 'Punktzahl-Update'}
                              {entry.action === 'criteria_change' && 'Kriterien-Änderung'}
                              {entry.action === 'visibility_toggle' && 'Sichtbarkeits-Änderung'}
                              {entry.action === 'manual_override' && 'Manuelle Anpassung'}
                            </Badge>
                            <p className="font-medium">{entry.details}</p>
                            {entry.affectedUser && (
                              <p className="text-sm text-gray-600">
                                Betroffener Benutzer: {entry.affectedUser}
                              </p>
                            )}
                          </div>
                          <div className="text-right text-sm text-gray-500">
                            <p>{new Date(entry.timestamp).toLocaleDateString('de-DE')}</p>
                            <p>{new Date(entry.timestamp).toLocaleTimeString('de-DE')}</p>
                          </div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">von {entry.adminUser}</span>
                          {entry.oldValue !== undefined && entry.newValue !== undefined && (
                            <span className="text-gray-600">
                              {entry.oldValue} → {entry.newValue}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      {/* Profilbild-Editor Modal */}
      {showProfileEditor && (
        <ProfileImageEditor
          user={currentUser}
          onSave={(updatedUser) => {
            const updatedUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u);
            onUsersChange(updatedUsers);
            setShowProfileEditor(false);
            showNotification('success', 'Profilbild erfolgreich aktualisiert');
          }}
          onClose={() => setShowProfileEditor(false)}
        />
      )}
    </div>
  );
}