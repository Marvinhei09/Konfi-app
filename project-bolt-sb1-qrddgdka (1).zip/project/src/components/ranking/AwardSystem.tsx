import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Crown, Medal, Award, Trophy, Star, Calendar, Settings, 
  Save, X, Plus, Trash2, Eye, EyeOff, CheckCircle
} from 'lucide-react';
import type { User } from '@/types';

interface AwardEntry {
  id: string;
  userId: string;
  rank: number;
  category: 'KU4' | 'KUZ' | 'KU8' | 'overall';
  awardType: 'gold' | 'silver' | 'bronze';
  displayDays: number;
  awardedAt: string;
  expiresAt: string;
  isActive: boolean;
}

interface AwardSystemProps {
  users: User[];
  onUsersChange: (users: User[]) => void;
  isAdminView?: boolean;
}

export function AwardSystem({ users, onUsersChange, isAdminView = false }: AwardSystemProps) {
  const [awards, setAwards] = useState<AwardEntry[]>([]);
  const [showAwardForm, setShowAwardForm] = useState(false);
  const [defaultDisplayDays, setDefaultDisplayDays] = useState(30);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);

  const [awardForm, setAwardForm] = useState({
    category: 'overall' as 'KU4' | 'KUZ' | 'KU8' | 'overall',
    displayDays: 30
  });

  useEffect(() => {
    // Automatische Bereinigung abgelaufener Auszeichnungen
    const cleanupExpiredAwards = () => {
      const now = new Date();
      setAwards(prev => prev.filter(award => new Date(award.expiresAt) > now));
    };

    const interval = setInterval(cleanupExpiredAwards, 60000); // Jede Minute prüfen
    return () => clearInterval(interval);
  }, []);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const getTopPerformers = (category: 'KU4' | 'KUZ' | 'KU8' | 'overall') => {
    let filteredUsers = users;
    
    if (category !== 'overall') {
      filteredUsers = users.filter(user => user.konfiRole === category);
    } else {
      // Für Overall-Ranking nur Konfirmanden, keine Admins/Teamer
      filteredUsers = users.filter(user => user.role === 'konfi');
    }

    return filteredUsers
      .sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0))
      .slice(0, 3);
  };

  const createAwards = () => {
    const topPerformers = getTopPerformers(awardForm.category);
    const now = new Date();
    const expiresAt = new Date(now.getTime() + awardForm.displayDays * 24 * 60 * 60 * 1000);

    // Entferne bestehende Auszeichnungen für diese Kategorie
    setAwards(prev => prev.filter(award => award.category !== awardForm.category));

    const newAwards: AwardEntry[] = topPerformers.map((user, index) => ({
      id: `${Date.now()}_${user.id}_${index}`,
      userId: user.id,
      rank: index + 1,
      category: awardForm.category,
      awardType: index === 0 ? 'gold' : index === 1 ? 'silver' : 'bronze',
      displayDays: awardForm.displayDays,
      awardedAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      isActive: true
    }));

    setAwards(prev => [...prev, ...newAwards]);
    setShowAwardForm(false);
    
    showNotification('success', 
      `Auszeichnungen für ${awardForm.category === 'overall' ? 'Gesamt-Ranking' : awardForm.category} erstellt! ` +
      `Gültig für ${awardForm.displayDays} Tage.`
    );
  };

  const removeAward = (awardId: string) => {
    setAwards(prev => prev.filter(award => award.id !== awardId));
    showNotification('success', 'Auszeichnung entfernt');
  };

  const toggleAwardVisibility = (awardId: string) => {
    setAwards(prev => prev.map(award => 
      award.id === awardId ? { ...award, isActive: !award.isActive } : award
    ));
  };

  const getAwardIcon = (awardType: 'gold' | 'silver' | 'bronze', size: 'sm' | 'md' | 'lg' = 'md') => {
    const sizeClass = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-8 h-8' : 'w-6 h-6';
    
    switch (awardType) {
      case 'gold':
        return <Crown className={`${sizeClass} text-yellow-500`} />;
      case 'silver':
        return <Medal className={`${sizeClass} text-gray-400`} />;
      case 'bronze':
        return <Medal className={`${sizeClass} text-orange-600`} />;
    }
  };

  const getAwardLabel = (awardType: 'gold' | 'silver' | 'bronze') => {
    switch (awardType) {
      case 'gold': return 'Goldene Krone';
      case 'silver': return 'Silberne Medaille';
      case 'bronze': return 'Bronze-Medaille';
    }
  };

  const getCategoryLabel = (category: 'KU4' | 'KUZ' | 'KU8' | 'overall') => {
    switch (category) {
      case 'KU4': return 'KU4 - 4. Klasse';
      case 'KUZ': return 'KUZ - Zwischenjahr';
      case 'KU8': return 'KU8 - 8. Klasse';
      case 'overall': return 'Gesamt-Ranking';
    }
  };

  const getActiveAwardsForUser = (userId: string) => {
    return awards.filter(award => 
      award.userId === userId && 
      award.isActive && 
      new Date(award.expiresAt) > new Date()
    );
  };

  const activeAwards = awards.filter(award => 
    award.isActive && new Date(award.expiresAt) > new Date()
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-500" />
            Auszeichnungssystem
          </h2>
          <p className="text-gray-600 text-sm mt-1">
            Verwalten Sie Auszeichnungen für die besten Leistungen in jedem Jahrgang
          </p>
        </div>
        {isAdminView && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Label htmlFor="default-days">Standard-Anzeigedauer (Tage):</Label>
              <Input
                id="default-days"
                type="number"
                min="1"
                max="365"
                value={defaultDisplayDays}
                onChange={(e) => setDefaultDisplayDays(parseInt(e.target.value))}
                className="w-20"
              />
            </div>
            <Button 
              onClick={() => setShowAwardForm(true)}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Auszeichnungen vergeben
            </Button>
          </div>
        )}
      </div>

      {/* Notification */}
      {notification && (
        <Alert variant={notification.type === 'error' ? 'destructive' : 'default'}>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>{notification.message}</AlertDescription>
        </Alert>
      )}

      {/* Award Creation Form */}
      {showAwardForm && isAdminView && (
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Neue Auszeichnungen vergeben
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="category">Kategorie</Label>
                <select
                  id="category"
                  value={awardForm.category}
                  onChange={(e) => setAwardForm({...awardForm, category: e.target.value as any})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
                >
                  <option value="overall">Gesamt-Ranking (nur Konfirmanden)</option>
                  <option value="KU4">KU4 - 4. Klasse</option>
                  <option value="KUZ">KUZ - Zwischenjahr</option>
                  <option value="KU8">KU8 - 8. Klasse</option>
                </select>
              </div>

              <div>
                <Label htmlFor="displayDays">Anzeigedauer (Tage)</Label>
                <Input
                  id="displayDays"
                  type="number"
                  min="1"
                  max="365"
                  value={awardForm.displayDays}
                  onChange={(e) => setAwardForm({...awardForm, displayDays: parseInt(e.target.value)})}
                />
              </div>
            </div>

            <div className="p-4 bg-white rounded-lg border">
              <h4 className="font-semibold mb-3">Vorschau der Auszeichnungen:</h4>
              <div className="space-y-2">
                {getTopPerformers(awardForm.category).map((user, index) => (
                  <div key={user.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                    {getAwardIcon(index === 0 ? 'gold' : index === 1 ? 'silver' : 'bronze')}
                    <span className="font-medium">{user.firstName} {user.lastName}</span>
                    <Badge variant="outline">{user.totalScore}% Punkte</Badge>
                    <span className="text-sm text-gray-600">
                      {getAwardLabel(index === 0 ? 'gold' : index === 1 ? 'silver' : 'bronze')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={createAwards} className="gap-2">
                <Save className="w-4 h-4" />
                Auszeichnungen vergeben
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowAwardForm(false)}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                Abbrechen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active Awards Display */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {['overall', 'KU4', 'KUZ', 'KU8'].map(category => {
          const categoryAwards = activeAwards.filter(award => award.category === category);
          
          return (
            <Card key={category} className="border-l-4 border-l-yellow-500">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  {getCategoryLabel(category as any)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {categoryAwards.length === 0 ? (
                  <p className="text-gray-500 text-sm">Keine aktiven Auszeichnungen</p>
                ) : (
                  <div className="space-y-3">
                    {categoryAwards
                      .sort((a, b) => a.rank - b.rank)
                      .map((award) => {
                        const user = users.find(u => u.id === award.userId);
                        if (!user) return null;

                        const daysLeft = Math.ceil(
                          (new Date(award.expiresAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                        );

                        return (
                          <div 
                            key={award.id} 
                            className={`p-3 rounded-lg border-2 transition-all ${
                              award.awardType === 'gold' ? 'bg-yellow-50 border-yellow-300' :
                              award.awardType === 'silver' ? 'bg-gray-50 border-gray-300' :
                              'bg-orange-50 border-orange-300'
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-2">
                              {getAwardIcon(award.awardType)}
                              <span className="font-semibold text-sm">
                                {user.firstName} {user.lastName}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                Platz {award.rank}
                              </Badge>
                            </div>
                            
                            <div className="text-xs text-gray-600 space-y-1">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                <span>Noch {daysLeft} Tage</span>
                              </div>
                              <p>{getAwardLabel(award.awardType)}</p>
                            </div>

                            {isAdminView && (
                              <div className="flex gap-1 mt-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => toggleAwardVisibility(award.id)}
                                  className="h-6 w-6 p-0"
                                >
                                  {award.isActive ? (
                                    <Eye className="w-3 h-3" />
                                  ) : (
                                    <EyeOff className="w-3 h-3" />
                                  )}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => removeAward(award.id)}
                                  className="h-6 w-6 p-0 text-red-500"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Award Statistics */}
      {isAdminView && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Auszeichnungs-Statistiken
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="text-center p-4 bg-yellow-50 rounded-lg">
                <div className="text-2xl font-bold text-yellow-600">
                  {activeAwards.filter(a => a.awardType === 'gold').length}
                </div>
                <div className="text-sm text-gray-600">Goldene Kronen</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-600">
                  {activeAwards.filter(a => a.awardType === 'silver').length}
                </div>
                <div className="text-sm text-gray-600">Silberne Medaillen</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">
                  {activeAwards.filter(a => a.awardType === 'bronze').length}
                </div>
                <div className="text-sm text-gray-600">Bronze-Medaillen</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{activeAwards.length}</div>
                <div className="text-sm text-gray-600">Gesamt aktiv</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}