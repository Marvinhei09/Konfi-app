import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Play, ArrowLeft, Lock, Check, ListOrdered } from 'lucide-react';
import type { Question, User } from '@/types';

interface CategorySelectorProps {
  questions: Question[];
  user: User;
  onCategorySelect: (category: string, questions: Question[]) => void;
  onBack: () => void;
}

export function CategorySelector({ questions, user, onCategorySelect, onBack }: CategorySelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'all' | 'multiple-choice' | 'true-false' | 'sequence'>('all');

  // Filter questions based on user's konfi role
  const availableQuestions = questions.filter(question => {
    if (user.role === 'admin') return true;
    if (!question.allowedRoles) return true;
    return question.allowedRoles.includes(user.konfiRole!);
  });

  // Filter by question type
  const filteredQuestions = activeTab === 'all' 
    ? availableQuestions 
    : availableQuestions.filter(q => {
        if (activeTab === 'multiple-choice') return !q.type || q.type === 'multiple-choice';
        return q.type === activeTab;
      });

  // Get unique categories with question counts
  const categories = filteredQuestions.reduce((acc, question) => {
    const category = question.topic;
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category]++;
    return acc;
  }, {} as Record<string, number>);

  const categoryEntries = Object.entries(categories).sort(([a], [b]) => a.localeCompare(b));

  const handleStartQuiz = () => {
    if (!selectedCategory) return;
    
    const categoryQuestions = filteredQuestions.filter(q => q.topic === selectedCategory);
    onCategorySelect(selectedCategory, categoryQuestions);
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'grundwissen':
        return '📚';
      case 'bibel':
        return '📖';
      case 'gebote':
        return '⚖️';
      case 'jesus':
        return '✝️';
      case 'kirche':
        return '⛪';
      case 'glaube':
        return '🙏';
      default:
        return '❓';
    }
  };

  const getCategoryDescription = (category: string) => {
    switch (category.toLowerCase()) {
      case 'grundwissen':
        return 'Grundlegendes Wissen über das Christentum';
      case 'bibel':
        return 'Fragen zur Heiligen Schrift';
      case 'gebote':
        return 'Die Zehn Gebote und christliche Ethik';
      case 'jesus':
        return 'Leben und Lehre Jesu Christi';
      case 'kirche':
        return 'Kirchengeschichte und Gemeindeleben';
      case 'glaube':
        return 'Glaubensinhalte und Spiritualität';
      default:
        return 'Verschiedene Themen';
    }
  };

  const getQuestionTypeCount = (category: string, type?: string) => {
    return filteredQuestions.filter(q => 
      q.topic === category && 
      (type === 'multiple-choice' 
        ? (!q.type || q.type === 'multiple-choice')
        : q.type === type)
    ).length;
  };

  const isCategoryAvailable = (category: string) => {
    return categories[category] > 0;
  };

  // Show all categories, but mark unavailable ones
  const allCategories = questions.reduce((acc, question) => {
    const category = question.topic;
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category]++;
    return acc;
  }, {} as Record<string, number>);

  const allCategoryEntries = Object.entries(allCategories).sort(([a], [b]) => a.localeCompare(b));

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          onClick={onBack}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Zurück
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quiz-Kategorie wählen</h1>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-gray-600">Wählen Sie ein Thema für Ihr Quiz aus</p>
            {user.role === 'konfi' && (
              <Badge variant="outline">
                Ihre Rolle: {user.konfiRole}
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Fragetyp-Tabs */}
      <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all" className="gap-2">
            Alle Typen
          </TabsTrigger>
          <TabsTrigger value="multiple-choice" className="gap-2">
            <BookOpen className="w-4 h-4" />
            Multiple-Choice
          </TabsTrigger>
          <TabsTrigger value="true-false" className="gap-2">
            <Check className="w-4 h-4" />
            Wahr/Falsch
          </TabsTrigger>
          <TabsTrigger value="sequence" className="gap-2">
            <ListOrdered className="w-4 h-4" />
            Sequenz
          </TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {allCategoryEntries.map(([category, totalCount]) => {
          const available = isCategoryAvailable(category);
          const availableCount = categories[category] || 0;
          
          // Zähle Fragen nach Typ
          const mcCount = getQuestionTypeCount(category, 'multiple-choice');
          const tfCount = getQuestionTypeCount(category, 'true-false');
          const seqCount = getQuestionTypeCount(category, 'sequence');
          
          return (
            <Card 
              key={category}
              className={`transition-all border-2 ${
                !available 
                  ? 'border-gray-200 bg-gray-50 opacity-60' 
                  : selectedCategory === category 
                    ? 'border-blue-500 bg-blue-50 cursor-pointer hover:shadow-lg' 
                    : 'border-gray-200 hover:border-blue-300 cursor-pointer hover:shadow-lg'
              }`}
              onClick={() => available && setSelectedCategory(category)}
            >
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <div className="text-4xl mb-2">
                    {available ? getCategoryIcon(category) : <Lock className="w-10 h-10 mx-auto text-gray-400" />}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">{category}</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {getCategoryDescription(category)}
                    </p>
                    <div className="space-y-2">
                      {available ? (
                        <div className="space-y-1">
                          <Badge variant="secondary" className="text-xs">
                            {availableCount} {availableCount === 1 ? 'Frage' : 'Fragen'} verfügbar
                          </Badge>
                          
                          {/* Fragetyp-Badges */}
                          <div className="flex flex-wrap gap-1 justify-center mt-2">
                            {mcCount > 0 && (
                              <Badge variant="outline" className="text-xs gap-1">
                                <BookOpen className="w-3 h-3" />
                                {mcCount}
                              </Badge>
                            )}
                            {tfCount > 0 && (
                              <Badge variant="outline" className="text-xs gap-1">
                                <Check className="w-3 h-3" />
                                {tfCount}
                              </Badge>
                            )}
                            {seqCount > 0 && (
                              <Badge variant="outline" className="text-xs gap-1">
                                <ListOrdered className="w-3 h-3" />
                                {seqCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <Badge variant="destructive" className="text-xs">
                            <Lock className="w-3 h-3 mr-1" />
                            Nicht verfügbar
                          </Badge>
                        </div>
                      )}
                    </div>
                  </div>
                  {selectedCategory === category && available && (
                    <div className="pt-2">
                      <div className="w-6 h-6 bg-blue-500 rounded-full mx-auto flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {categoryEntries.length === 0 && (
        <Card className="p-12 text-center bg-gray-50">
          <CardContent>
            <Lock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Keine Fragen für Ihre Rolle verfügbar.</p>
            <p className="text-sm text-gray-500">
              Wenden Sie sich an Ihren Administrator oder warten Sie auf weitere Freischaltungen.
            </p>
          </CardContent>
        </Card>
      )}

      {selectedCategory && (
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-2xl">{getCategoryIcon(selectedCategory)}</span>
              Quiz starten: {selectedCategory}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-700">
                  Sie haben <strong>{selectedCategory}</strong> ausgewählt
                </p>
                <p className="text-sm text-gray-600">
                  {categories[selectedCategory]} {categories[selectedCategory] === 1 ? 'Frage' : 'Fragen'} verfügbar
                </p>
                
                {/* Fragetyp-Übersicht */}
                <div className="flex gap-2 mt-2">
                  {getQuestionTypeCount(selectedCategory, 'multiple-choice') > 0 && (
                    <Badge variant="outline" className="gap-1">
                      <BookOpen className="w-3 h-3" />
                      Multiple-Choice: {getQuestionTypeCount(selectedCategory, 'multiple-choice')}
                    </Badge>
                  )}
                  {getQuestionTypeCount(selectedCategory, 'true-false') > 0 && (
                    <Badge variant="outline" className="gap-1">
                      <Check className="w-3 h-3" />
                      Wahr/Falsch: {getQuestionTypeCount(selectedCategory, 'true-false')}
                    </Badge>
                  )}
                  {getQuestionTypeCount(selectedCategory, 'sequence') > 0 && (
                    <Badge variant="outline" className="gap-1">
                      <ListOrdered className="w-3 h-3" />
                      Sequenz: {getQuestionTypeCount(selectedCategory, 'sequence')}
                    </Badge>
                  )}
                </div>
              </div>
              <Button 
                onClick={handleStartQuiz}
                className="gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                size="lg"
              >
                <Play className="w-5 h-5" />
                Quiz starten
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}